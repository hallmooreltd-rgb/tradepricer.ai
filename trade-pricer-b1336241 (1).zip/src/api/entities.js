import { base44 } from './base44Client';


export const Company = base44.entities.Company;

export const Customer = base44.entities.Customer;

export const Job = base44.entities.Job;

export const Certificate = base44.entities.Certificate;

export const Photo = base44.entities.Photo;

export const Reminder = base44.entities.Reminder;

export const Quote = base44.entities.Quote;

export const Lead = base44.entities.Lead;

export const PriceItem = base44.entities.PriceItem;

export const Assembly = base44.entities.Assembly;

export const Task = base44.entities.Task;

export const Timesheet = base44.entities.Timesheet;

export const Expense = base44.entities.Expense;

export const Payment = base44.entities.Payment;

export const Invoice = base44.entities.Invoice;

export const Variation = base44.entities.Variation;

export const Invitation = base44.entities.Invitation;

export const SiteDiary = base44.entities.SiteDiary;

export const Staff = base44.entities.Staff;



// auth sdk:
export const User = base44.auth;