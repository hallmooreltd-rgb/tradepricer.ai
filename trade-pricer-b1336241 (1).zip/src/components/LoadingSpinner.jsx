import React from 'react';
import { Loader2 } from 'lucide-react';

export default function LoadingSpinner({ 
  text = "Loading...", 
  size = "default",
  className = "" 
}) {
  const sizeClasses = {
    sm: "w-4 h-4",
    default: "w-5 h-5", 
    lg: "w-8 h-8"
  };

  return (
    <div className={`flex items-center justify-center p-8 ${className}`}>
      <div className="flex items-center gap-3 text-gray-600">
        <Loader2 className={`${sizeClasses[size]} animate-spin`} />
        <span className="text-sm">{text}</span>
      </div>
    </div>
  );
}