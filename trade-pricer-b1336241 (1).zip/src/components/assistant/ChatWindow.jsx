import React, { useState, useEffect, useRef } from 'react';
import { agentSDK } from '@/agents';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Loader2, Send, Bot } from 'lucide-react';
import MessageBubble from './MessageBubble';

export default function ChatWindow({ conversationId }) {
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');
    const [conversation, setConversation] = useState(null);
    const [loading, setLoading] = useState(false);
    const messagesEndRef = useRef(null);

    useEffect(() => {
        if (!conversationId) {
            setMessages([]);
            setConversation(null);
            return;
        }

        setLoading(true);
        
        const unsubscribe = agentSDK.subscribeToConversation(conversationId, (data) => {
            setConversation(data);
            setMessages(data.messages || []);
            setLoading(false);
        });

        return () => unsubscribe();
    }, [conversationId]);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!input.trim() || !conversation) return;

        const messageContent = input;
        setInput('');

        try {
            await agentSDK.addMessage(conversation, {
                role: 'user',
                content: messageContent,
            });
        } catch (error) {
            console.error('Failed to send message:', error);
            // Restore input on error
            setInput(messageContent);
        }
    };

    if (!conversationId) {
        return (
            <div className="flex-1 flex items-center justify-center text-gray-500">
                <div className="text-center">
                    <Bot className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                    <p>Select a conversation or start a new one.</p>
                </div>
            </div>
        );
    }
    
    if (loading) {
        return (
             <div className="flex-1 flex items-center justify-center text-gray-500">
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Loading conversation...
            </div>
        );
    }

    return (
        <div className="flex-1 flex flex-col h-full bg-white">
            <div className="border-b border-gray-200 p-4">
                <h2 className="text-lg font-semibold text-gray-900">AI Assistant</h2>
                <p className="text-sm text-gray-500">Ask me anything about your jobs, customers, quotes, and invoices.</p>
            </div>
            
            <div className="flex-1 p-6 space-y-6 overflow-y-auto">
                {messages.length === 0 && (
                    <div className="text-center text-gray-500 mt-12">
                        <Bot className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                        <p className="text-lg font-medium mb-2">Welcome to your AI Assistant!</p>
                        <p>I can help you manage your business. Try asking:</p>
                        <div className="mt-4 space-y-2 text-sm">
                            <p>• "Show me my active jobs"</p>
                            <p>• "Create a new customer"</p>
                            <p>• "Find quotes from this month"</p>
                            <p>• "What invoices are overdue?"</p>
                        </div>
                    </div>
                )}
                
                {messages.map((message, index) => (
                    <MessageBubble key={index} message={message} />
                ))}
                <div ref={messagesEndRef} />
            </div>
            
            <div className="p-4 border-t border-gray-200">
                <form onSubmit={handleSubmit} className="flex gap-4">
                    <Input
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="Ask about customers, jobs, or quotes..."
                        autoComplete="off"
                        className="flex-1"
                    />
                    <Button type="submit" disabled={!input.trim()}>
                        <Send className="w-4 h-4" />
                    </Button>
                </form>
            </div>
        </div>
    );
}