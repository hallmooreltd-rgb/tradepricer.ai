import React from 'react';
import { Button } from '@/components/ui/button';
import { Plus, MessageSquare } from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';

export default function ConversationList({ conversations, selectedConversationId, onSelect, onCreate }) {
    return (
        <div className="w-72 border-r border-gray-200 flex flex-col">
            <div className="p-4 border-b border-gray-200">
                <Button onClick={onCreate} className="w-full">
                    <Plus className="w-4 h-4 mr-2" />
                    New Chat
                </Button>
            </div>
            <div className="flex-1 overflow-y-auto p-2 space-y-1">
                {conversations.map(conv => (
                    <button
                        key={conv.id}
                        onClick={() => onSelect(conv.id)}
                        className={cn(
                            "w-full text-left px-3 py-2 rounded-lg transition-colors flex items-start gap-3",
                            selectedConversationId === conv.id 
                                ? "bg-blue-100 text-blue-800" 
                                : "hover:bg-gray-100"
                        )}
                    >
                        <MessageSquare className="w-4 h-4 mt-1 flex-shrink-0 text-gray-500" />
                        <div className="flex-1">
                             <p className="text-sm font-medium truncate">
                                {conv.metadata?.name || `Chat from ${formatDistanceToNow(new Date(conv.created_date))} ago`}
                            </p>
                            <p className="text-xs text-gray-500">
                                {formatDistanceToNow(new Date(conv.updated_date))} ago
                            </p>
                        </div>
                    </button>
                ))}
            </div>
        </div>
    );
}