
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Sparkles, X, ChevronRight, MessageCircle, Lightbulb, CheckCircle, ArrowRight, ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
import { agentSDK } from '@/agents';
import { User, Company } from '@/api/entities';
import { ENTITLEMENTS } from '../billing/plans';

export default function FloatingAIAssistant({ currentPage, contextData = {} }) {
  const [suggestions, setSuggestions] = useState([]);
  const [isDismissed, setIsDismissed] = useState(false);
  const [isOpen, setIsOpen] = useState(false); // Controls bubble vs card view
  const [userPlan, setUserPlan] = useState('free');
  const [aiRunsUsed, setAiRunsUsed] = useState(0);
  const [aiRunsLimit, setAiRunsLimit] = useState(3);

  useEffect(() => {
    const loadUserData = async () => {
      try {
        const user = await User.me();
        if (user?.company_id) {
          const companies = await Company.filter({ id: user.company_id });
          const company = companies[0];
          if (company) {
            const plan = company.plan_tier || 'free';
            setUserPlan(plan);
            const entitlements = ENTITLEMENTS[plan];
            setAiRunsLimit(entitlements.caps.ai_runs_pm);
            setAiRunsUsed(company.usage?.ai_runs || 0);
          }
        }
      } catch (error) {
        console.error('Failed to load user data:', error);
      }
    };

    loadUserData();
  }, []);

  useEffect(() => {
    const generateSuggestions = async () => {
      if (isDismissed) return;

      const contextualSuggestions = await getContextualSuggestions(currentPage, contextData, userPlan, aiRunsUsed, aiRunsLimit);
      
      setSuggestions(contextualSuggestions);
    };

    generateSuggestions();
  }, [currentPage, contextData, isDismissed, userPlan, aiRunsUsed, aiRunsLimit]);

  const handleDismiss = () => {
    setIsDismissed(true);
    setIsOpen(false); // Also close the card if it's open
  };

  const handleAIChat = async () => {
    const contextMessage = `I'm currently on the ${currentPage} page. Can you help me with suggestions for what to do next?`;
    
    try {
      const convs = await agentSDK.listConversations({ agent_name: 'manager' });
      let conversation = convs?.[0];
      
      if (!conversation) {
        conversation = await agentSDK.createConversation({
          agent_name: 'manager',
          metadata: { name: 'Contextual Help' }
        });
      }

      await agentSDK.addMessage(conversation, {
        role: 'user',
        content: contextMessage
      });

      window.location.href = createPageUrl('Assistant');
    } catch (error) {
      console.error('Failed to start AI chat:', error);
    }
  };

  if (suggestions.length === 0 || isDismissed) {
    return null;
  }

  const primarySuggestion = suggestions[0];

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            key="ai-bubble"
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.2 }}
          >
            <Button
              onClick={() => setIsOpen(true)}
              className="h-12 rounded-full shadow-lg bg-blue-600 hover:bg-blue-700 text-white pl-4 pr-5 text-sm font-semibold"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              AI Assistant
              <Badge variant="secondary" className="ml-2 bg-white text-blue-700">
                {suggestions.length}
              </Badge>
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            key="ai-card"
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="max-w-sm w-full"
          >
            <Card className="shadow-xl border-0 bg-gradient-to-br from-blue-600 to-indigo-700 text-white overflow-hidden">
              <CardHeader className="p-4 flex flex-row items-start justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-sm">AI Assistant</div>
                    <div className="text-xs text-white/80">{suggestions.length} suggestion{suggestions.length === 1 ? '' : 's'}</div>
                  </div>
                </div>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsOpen(false)}
                    className="text-white/80 hover:text-white hover:bg-white/20 h-6 w-6 p-0"
                  >
                    <ChevronDown className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleDismiss}
                    className="text-white/80 hover:text-white hover:bg-white/20 h-6 w-6 p-0"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                {/* Primary Suggestion */}
                <div className="bg-white/10 rounded-lg p-3 mb-3">
                  <div className="flex items-start gap-2 mb-2">
                    {primarySuggestion.icon && <primarySuggestion.icon className="w-4 h-4 mt-0.5 flex-shrink-0" />}
                    <div className="text-sm font-medium">{primarySuggestion.title}</div>
                  </div>
                  <div className="text-xs text-white/90 mb-3">
                    {primarySuggestion.description}
                  </div>
                  {primarySuggestion.action && (
                    <Link to={primarySuggestion.action.url}>
                      <Button size="sm" className="w-full bg-white text-blue-700 hover:bg-white/90">
                        {primarySuggestion.action.label}
                        <ArrowRight className="w-3 h-3 ml-1" />
                      </Button>
                    </Link>
                  )}
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleAIChat}
                  className="w-full text-white bg-white/10 hover:bg-white/20 border-white/20 hover:text-white"
                  disabled={aiRunsUsed >= aiRunsLimit}
                >
                  <MessageCircle className="w-3 h-3 mr-2" />
                  Ask AI for more suggestions
                  {aiRunsUsed >= aiRunsLimit && userPlan === 'free' && (
                    <Badge variant="secondary" className="ml-2 text-xs">Pro</Badge>
                  )}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// Smart contextual suggestions based on current page and data
async function getContextualSuggestions(currentPage, contextData = {}, userPlan, aiRunsUsed, aiRunsLimit) {
  const suggestions = [];
  const { company, jobs = [], customers = [], quotes = [], certificates = [] } = contextData;

  // Only show upgrade prompts when user is actually out of AI runs
  if (aiRunsUsed >= aiRunsLimit) {
    return [{
      type: 'upgrade',
      title: 'AI Suggestions Limit Reached',
      description: `You've used ${aiRunsUsed}/${aiRunsLimit} AI suggestions this month. Upgrade to get more intelligent help.`,
      icon: Sparkles,
      action: { label: 'Upgrade Plan', url: createPageUrl('Billing') }
    }];
  }

  // Dashboard-specific suggestions
  if (currentPage === 'Dashboard') {
    // No customers yet
    if (customers.length === 0) {
      suggestions.push({
        type: 'action',
        title: 'Add Your First Customer',
        description: 'Start building your customer database to create quotes and jobs efficiently.',
        icon: CheckCircle,
        action: { label: 'Add Customer', url: createPageUrl('NewCustomer') }
      });
    }
    
    // No jobs scheduled this week
    const thisWeekJobs = jobs.filter(job => {
      if (!job.scheduled_date) return false;
      const jobDate = new Date(job.scheduled_date);
      const today = new Date();
      today.setHours(0, 0, 0, 0); // Normalize today to start of day
      const weekFromNow = new Date(today);
      weekFromNow.setDate(today.getDate() + 7);
      weekFromNow.setHours(23, 59, 59, 999); // Normalize weekFromNow to end of day
      return jobDate >= today && jobDate <= weekFromNow;
    });
    
    if (jobs.length > 0 && thisWeekJobs.length === 0) {
      suggestions.push({
        type: 'action',
        title: 'Schedule This Week\'s Jobs',
        description: 'You have jobs that need scheduling. Plan your week ahead for better efficiency.',
        icon: CheckCircle,
        action: { label: 'View Jobs', url: createPageUrl('Jobs') }
      });
    }

    // Pending quotes to follow up
    const pendingQuotes = quotes.filter(q => q.status === 'sent');
    if (pendingQuotes.length > 0) {
      suggestions.push({
        type: 'action',
        title: `Follow Up on ${pendingQuotes.length} Pending Quote${pendingQuotes.length === 1 ? '' : 's'}`,
        description: 'Stay on top of your sales pipeline by following up with customers.',
        icon: CheckCircle,
        action: { label: 'View Quotes', url: createPageUrl('Quotes') }
      });
    }
  }

  // Jobs page suggestions
  if (currentPage === 'Jobs') {
    const draftJobs = jobs.filter(j => j.status === 'draft');
    if (draftJobs.length > 0) {
      suggestions.push({
        type: 'action',
        title: `Schedule ${draftJobs.length} Draft Job${draftJobs.length === 1 ? '' : 's'}`,
        description: 'Draft jobs need dates and details. Complete them to start work.',
        icon: CheckCircle,
        action: { label: 'View First Job', url: createPageUrl(`Job?id=${draftJobs[0].id}`) }
      });
    }

    if (jobs.length === 0) {
      suggestions.push({
        type: 'action',
        title: 'Create Your First Job',
        description: 'Jobs help you track work, schedule appointments, and manage certificates.',
        icon: CheckCircle,
        action: { label: 'New Job', url: createPageUrl('NewJob') }
      });
    }
  }

  // Quotes page suggestions  
  if (currentPage === 'Quotes') {
    if (quotes.length === 0) {
      suggestions.push({
        type: 'action',
        title: 'Create Your First Quote',
        description: 'Use AI to generate professional quotes quickly and win more business.',
        icon: CheckCircle,
        action: { label: 'AI Quote Generator', url: createPageUrl('AiQuoteEditor') }
      });
    }

    const expiredQuotes = quotes.filter(q => {
      if (!q.expiry_date || q.status !== 'sent') return false;
      return new Date(q.expiry_date) < new Date();
    });

    if (expiredQuotes.length > 0) {
      suggestions.push({
        type: 'action',
        title: `${expiredQuotes.length} Quote${expiredQuotes.length === 1 ? ' Has' : 's Have'} Expired`,
        description: 'Follow up with customers or extend expiry dates to keep opportunities alive.',
        icon: CheckCircle,
        action: { label: 'View Quotes', url: createPageUrl('Quotes') }
      });
    }
  }

  // Customers page suggestions
  if (currentPage === 'Customers') {
    if (customers.length === 0) {
      suggestions.push({
        type: 'action',
        title: 'Add Your First Customer',
        description: 'Build your customer database to create quotes, jobs, and certificates.',
        icon: CheckCircle,
        action: { label: 'Add Customer', url: createPageUrl('NewCustomer') }
      });
    }

    // Customers without recent activity - This logic might need refinement based on what "recent activity" means.
    // For now, it suggests if there are customers but total jobs are less than total customers,
    // implying some customers might not have associated jobs.
    if (customers.length > 0 && jobs.length < customers.length) {
      suggestions.push({
        type: 'action',
        title: 'Create Jobs for Existing Customers',
        description: 'You have customers who haven\'t had recent work. Reach out for repeat business.',
        icon: CheckCircle,
        action: { label: 'Create Job', url: createPageUrl('NewJob') }
      });
    }
  }

  // Certificates page suggestions
  if (currentPage === 'Certificates') {
    const completedJobs = jobs.filter(j => j.status === 'completed');
    const jobsNeedingCerts = completedJobs.filter(job => {
      return !certificates.some(cert => cert.job_id === job.id);
    });

    if (jobsNeedingCerts.length > 0) {
      suggestions.push({
        type: 'action',
        title: `${jobsNeedingCerts.length} Completed Job${jobsNeedingCerts.length === 1 ? ' Needs' : 's Need'} Certificates`,
        description: 'Issue certificates for completed work to ensure compliance and customer satisfaction.',
        icon: CheckCircle,
        action: { label: 'Issue Certificate', url: createPageUrl('NewCertificate') }
      });
    }

    if (certificates.length === 0) {
      suggestions.push({
        type: 'action',
        title: 'Issue Your First Certificate',
        description: 'Certificates provide legal compliance documentation for completed work.',
        icon: CheckCircle,
        action: { label: 'New Certificate', url: createPageUrl('NewCertificate') }
      });
    }
  }

  // Settings page suggestions
  if (currentPage === 'Settings') {
    if (!company?.logo_url) {
      suggestions.push({
        type: 'action',
        title: 'Add Your Company Logo',
        description: 'A logo makes your quotes and certificates look more professional.',
        icon: CheckCircle,
        action: { label: 'Company Settings', url: createPageUrl('Settings') }
      });
    }

    if (!company?.phone || !company?.address_line1) {
      suggestions.push({
        type: 'action',
        title: 'Complete Company Profile',
        description: 'Add contact details and address for professional documentation.',
        icon: CheckCircle,
        action: { label: 'Company Profile', url: createPageUrl('Settings') }
      });
    }
  }

  // General suggestions that apply everywhere
  if (suggestions.length === 0) {
    // If no specific suggestions, provide general guidance
    if (customers.length === 0) {
      suggestions.push({
        type: 'action',
        title: 'Start with Your First Customer',
        description: 'Every successful business starts with great customer relationships.',
        icon: CheckCircle,
        action: { label: 'Add Customer', url: createPageUrl('NewCustomer') }
      });
    } else if (quotes.length === 0) {
      suggestions.push({
        type: 'action',
        title: 'Create Your First Quote',
        description: 'AI-powered quotes help you win more business with professional pricing.',
        icon: CheckCircle,
        action: { label: 'AI Quote Generator', url: createPageUrl('AiQuoteEditor') }
      });
    } else {
      suggestions.push({
        type: 'action',
        title: 'Check Your Dashboard',
        description: 'See an overview of your business activity and upcoming tasks.',
        icon: CheckCircle,
        action: { label: 'View Dashboard', url: createPageUrl('Dashboard') }
      });
    }
  }

  return suggestions.slice(0, 3); // Return max 3 suggestions
}
