import React, { useState } from 'react';
import { Company } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Building, Loader2 } from 'lucide-react';

export default function CompanySetup({ onComplete }) {
  const [companyName, setCompanyName] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!companyName.trim()) {
      setError('Please enter a company name.');
      return;
    }
    setError('');
    setSaving(true);
    try {
      // 1. Create the company
      const newCompany = await Company.create({ name: companyName.trim() });
      
      // 2. Associate the company with the current user
      if (newCompany && newCompany.id) {
        await User.updateMyUserData({ company_id: newCompany.id });
      } else {
        throw new Error("Company creation failed, please try again.");
      }

      // 3. Signal completion to reload the app
      onComplete();

    } catch (err) {
      console.error('Company setup failed:', err);
      setError(err.message || 'An unexpected error occurred. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <form onSubmit={handleSubmit}>
          <CardHeader className="text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-blue-100 rounded-full flex items-center justify-center">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/b12f0cf12_tradepricer_logo_transparent.png" 
                alt="TradePricer Logo" 
                className="w-12 h-12" 
              />
            </div>
            <CardTitle className="text-2xl">Welcome to TradePricer!</CardTitle>
            <CardDescription>Let's get your company set up. What is the name of your business?</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="company-name">Company Name</Label>
              <Input
                id="company-name"
                placeholder="e.g., Smith & Sons Plumbing"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                disabled={saving}
                required
              />
            </div>
            {error && <p className="text-sm text-red-600">{error}</p>}
          </CardContent>
          <CardFooter>
            <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={saving}>
              {saving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating Company...
                </>
              ) : (
                'Save and Continue'
              )}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}