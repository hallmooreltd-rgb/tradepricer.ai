import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { X } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function UpsellModal({ open, onClose, title, body, ctaPlan = "pro" }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
      <Card className="w-full max-w-lg">
        <CardContent className="p-6 space-y-4">
          <div className="flex items-start justify-between">
            <div className="text-xl font-semibold">{title}</div>
            <button onClick={onClose} aria-label="Close"><X className="w-5 h-5" /></button>
          </div>
          <p className="text-gray-700">{body}</p>
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button asChild className="bg-blue-600 hover:bg-blue-700">
              <a href={createPageUrl(`Billing?plan=${ctaPlan}`)}>Upgrade now</a>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}