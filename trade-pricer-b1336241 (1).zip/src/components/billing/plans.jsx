
export const PLAN_LABELS = {
  free: "Free",
  pro: "Pro",
  premium: "Premium",
};

export const ENTITLEMENTS = {
  free: {
    users_included: 1,
    caps: { active_jobs: 3, quotes_pm: 10, invoices_pm: 10, certs_pm: 3, variations_pm: 3, reminders_pm: 30, ai_runs_pm: 3, storage_gb: 1, sms_pm: 0 },
    features: { watermark: true, portal_custom_domain: false, payments: false, integrations_live_sync: false },
  },
  pro: {
    users_included: 3,
    caps: { active_jobs: Infinity, quotes_pm: Infinity, invoices_pm: Infinity, certs_pm: 30, variations_pm: Infinity, reminders_pm: 200, ai_runs_pm: 100, storage_gb: 50, sms_pm: 0 },
    features: { watermark: false, portal_custom_domain: false, payments: true, integrations_live_sync: false },
    // NOTE: Switched from import.meta.env to support the platform environment.
    // Ensure your Stripe Price IDs are configured as environment variables.
    price_month: "price_1PJbLeF8ZfsVzQ4kFAKE_ID_PRO_MONTH",
    price_year: "price_1PJbLeF8ZfsVzQ4kFAKE_ID_PRO_YEAR",
  },
  premium: {
    users_included: 10,
    caps: { active_jobs: Infinity, quotes_pm: Infinity, invoices_pm: Infinity, certs_pm: Infinity, variations_pm: Infinity, reminders_pm: 1000, ai_runs_pm: 500, storage_gb: 200, sms_pm: 100 },
    features: { watermark: false, portal_custom_domain: true, payments: true, integrations_live_sync: true },
    // NOTE: Switched from import.meta.env to support the platform environment.
    // Ensure your Stripe Price IDs are configured as environment variables.
    price_month: "price_1PJbLeF8ZfsVzQ4kFAKE_ID_PREMIUM_MONTH",
    price_year: "price_1PJbLeF8ZfsVzQ4kFAKE_ID_PREMIUM_YEAR",
  },
};
