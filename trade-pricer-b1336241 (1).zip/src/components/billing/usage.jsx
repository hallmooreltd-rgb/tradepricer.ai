import { ENTITLEMENTS } from "./plans";
import { format } from "date-fns";
import { Company } from "@/api/entities";

const capMap = {
  quotes_pm: "quotes",
  invoices_pm: "invoices",
  certs_pm: "certificates",
  variations_pm: "variations",
  reminders_pm: "reminders",
  ai_runs_pm: "ai_runs",
  active_jobs: "active_jobs",
  storage_gb: "storage_bytes",
  sms_pm: "sms",
};

export function ensureUsageMonth(company) {
  const ym = format(new Date(), "yyyy-MM");
  if (company.usage_ym !== ym) {
    company.usage_ym = ym;
    company.usage = {
      quotes: 0,
      invoices: 0,
      certificates: 0,
      variations: 0,
      reminders: 0,
      ai_runs: 0,
      active_jobs: Number(company.usage?.active_jobs || 0),
      storage_bytes: Number(company.usage?.storage_bytes || 0),
      sms: 0,
    };
  }
  return company;
}

export function canUse(company, feature, delta = 1) {
  const tier = company.plan_tier || "free";
  const caps = ENTITLEMENTS[tier].caps;
  const cap = caps[feature];
  if (cap === Infinity) return true;

  const key = capMap[feature];
  const current = Number(company.usage?.[key] || 0);

  if (feature === "storage_gb") {
    const gb = (current || 0) / (1024 ** 3);
    return gb + (delta / (1024 ** 3)) <= Number(caps.storage_gb);
  }

  return current + delta <= Number(cap);
}

export async function bumpUsage(company, feature, delta = 1) {
  const key = capMap[feature];
  company.usage = company.usage || {};
  company.usage[key] = Number(company.usage[key] || 0) + delta;
  await Company.update(company.id, { usage: company.usage, usage_ym: company.usage_ym });
}

export function planFeatures(company) {
  const tier = company.plan_tier || "free";
  return ENTITLEMENTS[tier].features;
}