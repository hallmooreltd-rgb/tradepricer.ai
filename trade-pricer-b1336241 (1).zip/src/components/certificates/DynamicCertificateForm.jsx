import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { FileText, User } from "lucide-react";

export default function DynamicCertificateForm({ template, formData, onFormChange }) {
  const handleChange = (name, value) => {
    onFormChange({ ...formData, [name]: value });
  };
  
  const renderField = (field) => {
    const value = formData[field.name] ?? field.default ?? '';

    switch (field.type) {
      case "text":
      case "number":
        return <Input
          type={field.type}
          value={value}
          onChange={(e) => handleChange(field.name, e.target.value)}
          required={field.required}
        />;
      case "long_text":
        return <Textarea
          value={value}
          onChange={(e) => handleChange(field.name, e.target.value)}
          required={field.required}
          rows={3}
        />;
      case "enum":
        return (
          <Select value={value} onValueChange={(val) => handleChange(field.name, val)} required={field.required}>
            <SelectTrigger>
              <SelectValue placeholder={`Select ${field.label.toLowerCase()}`} />
            </SelectTrigger>
            <SelectContent>
              {field.options.map(option => (
                <SelectItem key={option} value={option}>
                  {option.charAt(0).toUpperCase() + option.slice(1).replace(/_/g, ' ')}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );
      case "boolean":
        return (
          <div className="flex items-center gap-2 pt-2">
            <Checkbox
              id={field.name}
              checked={!!value}
              onCheckedChange={(checked) => handleChange(field.name, checked)}
            />
            <Label htmlFor={field.name} className="font-normal">Enable</Label>
          </div>
        );
      default:
        return null;
    }
  };

  const installerFields = [
    { name: "installer_name", label: "Installer Name", type: "text", required: true },
    { name: "installer_credential_type", label: "Credential Type", type: "enum", options: ["gas_safe", "niceic", "none"], required: true },
    { name: "installer_credential_id", label: "Credential ID", type: "text", required: formData.installer_credential_type && formData.installer_credential_type !== 'none' },
  ];

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><User className="w-5 h-5" />Installer Details</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {installerFields.map(field => (
            <div key={field.name} className="space-y-2">
              <Label htmlFor={field.name}>{field.label}{field.required && <span className="text-red-500">*</span>}</Label>
              {renderField(field)}
            </div>
          ))}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            {template.name}
          </CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {template.dynamic_fields.map(field => (
            <div key={field.name} className="space-y-2">
              <Label htmlFor={field.name}>{field.label}{field.required && <span className="text-red-500">*</span>}</Label>
              {renderField(field)}
            </div>
          ))}
        </CardContent>
      </Card>
    </>
  );
}