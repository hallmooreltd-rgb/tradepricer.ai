import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Trash2, Plus, AlertTriangle, Search } from "lucide-react";

const CODE_INFO = {
  C1: { label: "C1 - Danger present", colour: "bg-red-600", help: "Immediate risk. Make safe before leaving site." },
  C2: { label: "C2 - Potentially dangerous", colour: "bg-orange-500", help: "Urgent remedial action required." },
  FI: { label: "FI - Further investigation", colour: "bg-amber-500", help: "Investigation required without delay." },
  C3: { label: "C3 - Improvement recommended", colour: "bg-sky-600", help: "Not unsafe. Improvement advised." }
};

function severityOrder(code) {
  if (code === "C1") return 1;
  if (code === "C2") return 2;
  if (code === "FI") return 3;
  return 4; // C3
}

export default function ObservationsEditor({
  value,
  onChange
}) {
  const list = value || [];

  const addItem = () => {
    const next = [...list, { code: "C3", description: "" }];
    onChange(next);
  };

  const updateItem = (idx, patch) => {
    const next = list.slice();
    next[idx] = { ...next[idx], ...patch };
    onChange(next);
  };

  const removeItem = (idx) => {
    const next = list.slice();
    next.splice(idx, 1);
    onChange(next);
  };

  const sorted = list.slice().sort((a, b) => severityOrder(a.code) - severityOrder(b.code));

  const counts = Object.keys(CODE_INFO).reduce((acc, code) => {
    acc[code] = list.filter(obs => obs.code === code).length;
    return acc;
  }, {});

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-start">
        <div>
          <h4 className="font-medium mb-2">Observations and defects</h4>
          <div className="flex gap-3 text-xs">
            {Object.entries(CODE_INFO).map(([code, info]) => (
              <span key={code} className={`px-2 py-1 rounded text-white ${info.colour}`}>
                {code}: {counts[code] || 0}
              </span>
            ))}
          </div>
        </div>
        <Button type="button" onClick={addItem} size="sm">
          <Plus className="w-4 h-4 mr-2" />
          Add observation
        </Button>
      </div>

      <div className="space-y-3">
        {sorted.map((obs, idx) => {
          const originalIdx = list.findIndex(item => item === obs);
          const info = CODE_INFO[obs.code];
          
          return (
            <div key={originalIdx} className="border rounded-xl p-4 bg-white">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
                <div className="md:col-span-2">
                  <Label>Code</Label>
                  <Select 
                    value={obs.code} 
                    onValueChange={(code) => updateItem(originalIdx, { code })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(CODE_INFO).map(([code, info]) => (
                        <SelectItem key={code} value={code}>
                          <div className="flex items-center gap-2">
                            <div className={`w-3 h-3 rounded ${info.colour}`}></div>
                            {code}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-gray-500 mt-1">{info.help}</p>
                </div>

                <div className="md:col-span-6">
                  <Label>Description</Label>
                  <Textarea
                    rows={2}
                    value={obs.description}
                    onChange={(e) => updateItem(originalIdx, { description: e.target.value })}
                    placeholder="Describe the defect or observation"
                  />
                </div>

                <div className="md:col-span-2">
                  <Label>Location</Label>
                  <Input
                    value={obs.location || ""}
                    onChange={(e) => updateItem(originalIdx, { location: e.target.value })}
                    placeholder="e.g. Kitchen"
                  />
                </div>

                <div className="md:col-span-2 flex items-end">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => removeItem(originalIdx)}
                    className="w-full"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Remove
                  </Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {list.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          <AlertTriangle className="w-12 h-12 mx-auto mb-4 text-gray-300" />
          <p>No observations recorded yet.</p>
          <p className="text-sm">Add observations for any defects or improvements found.</p>
        </div>
      )}
    </div>
  );
}