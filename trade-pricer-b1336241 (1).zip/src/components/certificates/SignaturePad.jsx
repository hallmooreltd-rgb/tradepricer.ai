
import React, { useEffect, useRef, useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

export default function SignaturePad({
  label = "Signature",
  initialUrl,
  height = 180,
  penWidth = 2.5,
  onSignatureChange,
  upload,
}) {
  const wrapperRef = useRef(null);
  const canvasRef = useRef(null);
  const ctxRef = useRef(null);

  const [paths, setPaths] = useState([]);
  const [drawing, setDrawing] = useState(false);
  const [currentPath, setCurrentPath] = useState([]);
  const [exporting, setExporting] = useState(false);

  // Size the canvas to its container and scale for devicePixelRatio
  const setupCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    const wrapper = wrapperRef.current;
    if (!canvas || !wrapper) return;

    const dpr = Math.max(1, Math.floor(window.devicePixelRatio || 1));
    const cssWidth = wrapper.clientWidth;
    const cssHeight = height;

    canvas.style.width = `${cssWidth}px`;
    canvas.style.height = `${cssHeight}px`;
    canvas.width = cssWidth * dpr;
    canvas.height = cssHeight * dpr;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.scale(dpr, dpr);
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.lineWidth = penWidth;
    ctx.strokeStyle = "#111827"; // slate-900
    ctxRef.current = ctx;

    // light background so exported PNG is not transparent
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, cssWidth, cssHeight);

    // If we have an existing signature image, draw it
    if (initialUrl) {
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0, cssWidth, cssHeight);
      };
      img.src = initialUrl;
    } else {
      redraw(paths, ctx, cssWidth, cssHeight);
    }
  }, [height, penWidth, initialUrl, paths]);

  useEffect(() => {
    setupCanvas();
    const handleResize = () => setupCanvas();
    window.addEventListener("resize", handleResize, { passive: true });
    return () => window.removeEventListener("resize", handleResize);
  }, [setupCanvas]);

  const getPos = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  const startDraw = (e) => {
    const pos = getPos(e);
    setCurrentPath([pos]);
    setDrawing(true);
    // prevent scrolling while drawing on touch devices
    if (e.target.setPointerCapture) {
      e.target.setPointerCapture(e.pointerId);
    }
  };

  const moveDraw = (e) => {
    if (!drawing) return;
    const pos = getPos(e);
    setCurrentPath(prev => {
      const next = [...prev, pos];
      drawSegment(prev[prev.length - 1], pos);
      return next;
    });
  };

  const endDraw = () => {
    if (!drawing) return;
    setDrawing(false);
    if (currentPath.length > 0) {
      setPaths(prev => [...prev, currentPath]);
      setCurrentPath([]);
    }
    exportSignatureDebounced();
  };

  const drawSegment = (from, to) => {
    const ctx = ctxRef.current;
    if (!ctx || !from || !to) return;
    ctx.beginPath();
    ctx.moveTo(from.x, from.y);
    ctx.lineTo(to.x, to.y);
    ctx.stroke();
  };

  const redraw = (allPaths, ctx, w, h) => {
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = "#111827";
    ctx.lineWidth = penWidth;
    for (const path of allPaths) {
      if (path.length < 2) continue;
      ctx.beginPath();
      ctx.moveTo(path[0].x, path[0].y);
      for (let i = 1; i < path.length; i++) {
        ctx.lineTo(path[i].x, path[i].y);
      }
      ctx.stroke();
    }
  };

  const clear = () => {
    setPaths([]);
    setCurrentPath([]);
    setupCanvas();
    onSignatureChange(""); // cleared
  };

  const undo = () => {
    setPaths(prev => {
      const next = prev.slice(0, -1);
      const canvas = canvasRef.current;
      const ctx = ctxRef.current;
      if (canvas && ctx) {
        const w = canvas.clientWidth;
        const h = canvas.clientHeight;
        redraw(next, ctx, w, h);
      }
      exportSignatureDebounced(next);
      return next;
    });
  };

  const exportSignature = async (overridePaths) => {
    const canvas = canvasRef.current;
    const ctx = ctxRef.current;
    if (!canvas || !ctx) return;

    setExporting(true);

    // Compose to a white background to avoid transparency
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    const tmp = document.createElement("canvas");
    tmp.width = w;
    tmp.height = h;
    const tctx = tmp.getContext("2d");
    tctx.fillStyle = "#ffffff";
    tctx.fillRect(0, 0, w, h);

    // Draw current canvas content at 1:1 CSS pixels
    tctx.drawImage(canvas, 0, 0, w, h);

    const toUrl = async () =>
      new Promise((resolve) => {
        tmp.toBlob(async (blob) => {
          if (!blob) {
            resolve(tmp.toDataURL("image/png"));
            return;
          }
          if (upload) {
            try {
              // Convert blob to File object with proper metadata
              const timestamp = Date.now();
              const file = new File([blob], `signature-${timestamp}.png`, {
                type: 'image/png',
                lastModified: timestamp
              });
              const url = await upload(file);
              resolve(url);
            } catch (error) {
              console.error("Upload failed, using fallback:", error);
              // Fallback to object URL if upload fails
              resolve(URL.createObjectURL(blob));
            }
          } else {
            // data URL fallback
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result);
            reader.readAsDataURL(blob);
          }
        }, "image/png");
      });

    const url = await toUrl();
    onSignatureChange(url);
    setExporting(false);
  };

  // Debounce to avoid exporting too often
  let exportTimer;
  const exportSignatureDebounced = (overridePaths) => {
    if (exportTimer) window.clearTimeout(exportTimer);
    exportTimer = window.setTimeout(() => exportSignature(overridePaths), 250);
  };

  return (
    <div className="space-y-2">
      <Label className="block">{label}</Label>
      <div ref={wrapperRef} className="w-full border rounded-xl bg-white select-none">
        <canvas
          ref={canvasRef}
          className="w-full rounded-xl touch-none"
          style={{ height }}
          onPointerDown={startDraw}
          onPointerMove={moveDraw}
          onPointerUp={endDraw}
          onPointerLeave={endDraw}
        />
      </div>
      <div className="flex gap-2">
        <Button type="button" variant="secondary" onClick={undo} disabled={!paths.length || exporting}>
          Undo
        </Button>
        <Button type="button" variant="outline" onClick={clear} disabled={exporting}>
          Clear
        </Button>
      </div>
      <p className="text-xs text-gray-500">
        Sign with your finger or a stylus. Works on touch and mouse.
      </p>
    </div>
  );
}
