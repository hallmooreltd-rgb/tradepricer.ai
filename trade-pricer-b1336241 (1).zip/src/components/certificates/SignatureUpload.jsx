import React from 'react';
import { UploadFile } from "@/api/integrations";
import SignaturePad from "./SignaturePad";

export default function SignatureUpload({ label, onSignatureChange }) {
  const handleUpload = async (blob) => {
    try {
      const { file_url } = await UploadFile({ file: blob });
      return file_url;
    } catch (error) {
      console.error("Error uploading signature:", error);
      throw error;
    }
  };

  return (
    <SignaturePad
      label={label}
      height={150}
      onSignatureChange={onSignatureChange}
      upload={handleUpload}
    />
  );
}