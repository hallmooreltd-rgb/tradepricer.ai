
import React from 'react';

export const templates = {
  boiler_install: {
    key: "boiler_install",
    name: "Boiler Installation Certificate",
    dynamic_fields: [
      { name: "appliance_make", label: "Appliance Make", type: "text", required: true },
      { name: "appliance_model", label: "Appliance Model", type: "text", required: true },
      { name: "serial_number", label: "Serial Number", type: "text", required: true },
      { name: "location", label: "Installation Location", type: "text", required: true },
      { name: "inlet_working_pressure_mbar", label: "Inlet Working Pressure (mbar)", type: "number" },
      { name: "flue_type", label: "Flue Type", type: "enum", options: ["horizontal", "vertical", "none"] },
      { name: "flue_termination_ok", label: "Flue Termination OK", type: "boolean" },
      { name: "combustion_analysis", label: "Combustion Analysis", type: "long_text" },
      { name: "benchmark_completed", label: "Benchmark Completed", type: "boolean", required: true },
      { name: "warranty_years", label: "Warranty Years", type: "number" },
      { name: "notes", label: "Notes", type: "long_text" },
    ],
    reminder_rule: {
      create_reminder: true,
      reminder_type: "boiler_service_due",
      due_in_months: 12,
      message_template_key: "boiler_service_due",
    },
  },
  damp_report: {
    key: "damp_report",
    name: "Damp Proofing Report",
    dynamic_fields: [
      { name: "property_type", label: "Property Type", type: "enum", required: true, options: ["house", "flat", "bungalow", "commercial"] },
      { name: "construction_age", label: "Construction Age", type: "text" },
      { name: "moisture_readings", label: "Moisture Readings and Locations", type: "long_text" },
      { name: "cause_assessment", label: "Likely Cause", type: "long_text", required: true },
      { name: "recommended_treatment", label: "Recommended Treatment", type: "long_text", required: true },
      { name: "guarantee_offered", label: "Guarantee Offered", type: "boolean" },
      { name: "notes", label: "Notes", type: "long_text" },
    ],
    reminder_rule: {
      create_reminder: true,
      reminder_type: "damp_followup",
      due_in_months: 6,
      message_template_key: "general_followup",
    },
  },
  roof_inspection: {
    key: "roof_inspection",
    name: "Roofing Inspection Report",
    dynamic_fields: [
      { name: "roof_type", label: "Roof Type", type: "enum", required: true, options: ["pitched", "flat", "other"] },
      { name: "defects_found", label: "Defects Found", type: "long_text", required: true },
      { name: "photos_required", label: "Photos Required", type: "boolean", default: true },
      { name: "urgency", label: "Urgency", type: "enum", required: true, options: ["low", "medium", "high"] },
      { name: "recommendation", label: "Recommendation", type: "long_text", required: true },
      { name: "notes", label: "Notes", type: "long_text" },
    ],
    reminder_rule: {
      create_reminder: true,
      reminder_type: "roof_followup",
      due_in_months: 12,
      message_template_key: "general_followup",
    },
  },
  risk_assessment: {
    key: "risk_assessment",
    name: "Site Risk Assessment",
    dynamic_fields: [
      { name: "site_address", label: "Site Address", type: "text", required: true },
      { name: "task_description", label: "Task Description", type: "long_text", required: true },
      { name: "hazards", label: "Hazards Identified", type: "long_text", required: true },
      { name: "controls", label: "Control Measures", type: "long_text", required: true },
      { name: "ppe_required", label: "PPE Required", type: "text" },
      { name: "residual_risk", label: "Residual Risk", type: "enum", required: true, options: ["low", "medium", "high"] },
      { name: "notes", label: "Notes", type: "long_text" },
    ],
    reminder_rule: {
      create_reminder: false,
    },
  },
  electrical_condition_report: {
    key: "electrical_condition_report",
    name: "Electrical Installation Condition Report (EICR)",
    dynamic_fields: [
      // Site and purpose
      { name: "installation_address", label: "Installation address", type: "text", required: false },
      { name: "purpose_of_report", label: "Purpose of report", type: "enum", options: ["Periodic inspection", "Change of occupancy", "After alteration or addition", "Other"], required: true },
      { name: "installation_age_years", label: "Approximate age of installation (years)", type: "number", required: false },

      // Supply and earthing
      { name: "earthing_arrangement", label: "Earthing arrangement", type: "enum", options: ["TN-C-S", "TN-S", "TT", "Other"], required: true },
      { name: "supply_fuse_rating_amps", label: "Supply fuse rating (A)", type: "number", required: false },
      { name: "measured_ze_ohms", label: "Measured Ze (Ω)", type: "number", step: 0.01, required: false },

      // Consumer unit
      { name: "consumer_unit_make_model", label: "Consumer unit make and model", type: "text", required: false },
      { name: "rcd_protection_present", label: "RCD protection present", type: "boolean", required: false },

      // Outcome is derived from observations
      { name: "outcome", label: "Overall outcome", type: "enum", options: ["Satisfactory", "Unsatisfactory"], required: true },
      { name: "next_inspection_months", label: "Recommended next inspection in months", type: "number", required: false, default: 60 },

      // Observations list - implemented with a custom editor
      { name: "observations", label: "Observations", type: "repeater", required: false },
      { name: "notes", label: "Notes", type: "long_text", required: false }
    ],
    reminder_rule: {
      create_reminder: true,
      reminder_type: "electrical_followup",
      due_in_months: 60,
      message_template_key: "general_followup"
    }
  },
  customer_portal_qr_code: {
    key: "customer_portal_qr_code",
    name: "Secure Customer Portal",
    dynamic_fields: [
      { name: "customer_name", label: "Customer Name", type: "text", required: true },
      { name: "customer_email", label: "Customer Email", type: "text", required: true },
      { name: "customer_address", label: "Customer Address", type: "long_text", required: true },
      { name: "qr_code_link", label: "QR Code Link", type: "text", required: true },
      { name: "access_instructions", label: "Access Instructions", type: "long_text" },
      { name: "portal_features", label: "Portal Features", type: "long_text" },
      { name: "notes", label: "Notes", type: "long_text" },
    ],
    reminder_rule: {
      create_reminder: false,
    },
  },
};

export const getTemplate = (key) => templates[key];
