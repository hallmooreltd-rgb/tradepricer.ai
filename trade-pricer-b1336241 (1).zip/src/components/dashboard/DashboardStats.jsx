import * as React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Briefcase, Users, FileText, Bell
} from "lucide-react";
import {
  ResponsiveContainer, AreaChart, Area, LineChart, Line, BarChart, Bar, Tooltip
} from "recharts";

export default function DashboardStats({
  stats,
  trends = {}
}) {

  const cards = [
    {
      key: "jobs",
      label: "Jobs",
      value: stats.totalJobs,
      sub: `${stats.completedJobs} completed`,
      delta: stats.deltaJobs,
      icon: Briefcase,
      gradientFrom: "#2563EB", // blue-600
      gradientTo:   "#4F46E5", // indigo-600
      trend: trends.jobsTrend,
      chart: "area",
      url: createPageUrl("Jobs"),
    },
    {
      key: "customers",
      label: "Customers",
      value: stats.totalCustomers,
      sub: "Active contacts",
      delta: stats.deltaCustomers,
      icon: Users,
      gradientFrom: "#059669", // emerald-600
      gradientTo:   "#0EA5E9", // sky-500
      trend: trends.customersTrend,
      chart: "line",
      url: createPageUrl("Customers"),
    },
    {
      key: "certs",
      label: "Certificates",
      value: stats.certificatesIssued,
      sub: stats.deltaCertificates !== undefined ? "Change vs last period" : "Total issued",
      delta: stats.deltaCertificates,
      icon: FileText,
      gradientFrom: "#06B6D4", // cyan-500
      gradientTo:   "#7C3AED", // violet-600
      trend: trends.certificatesTrend,
      chart: "bar",
      url: createPageUrl("Certificates"),
    },
    {
      key: "reminders",
      label: "Reminders",
      value: stats.pendingReminders,
      sub: "Scheduled",
      delta: stats.deltaReminders,
      icon: Bell,
      gradientFrom: "#F59E0B", // amber-500
      gradientTo:   "#EF4444", // red-500
      trend: trends.remindersTrend,
      chart: "area",
      url: createPageUrl("Reminders"),
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
      {cards.map((c, i) => (
        <Link to={c.url} key={c.key}>
          <StatCard item={c} index={i} />
        </Link>
      ))}
    </div>
  );
}

/* ---------------- Card ---------------- */

function StatCard({ item, index }) {
  const Icon = item.icon;
  const hasTrend = Array.isArray(item.trend) && item.trend.length > 0;
  const data = (item.trend || []).map((v, i) => ({ x: i, y: v }));

  // a11y text for delta
  const deltaText =
    typeof item.delta === "number"
      ? `${item.delta >= 0 ? "Up" : "Down"} ${Math.abs(item.delta)} percent vs last period`
      : "";

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className="rounded-2xl border bg-white shadow-sm hover:shadow-lg transition-shadow duration-200 overflow-hidden h-full"
      aria-label={`${item.label} card ${deltaText}`}
    >
      <div className="p-4">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <div className="text-sm text-gray-500">{item.label}</div>
            <div className="text-2xl font-semibold text-gray-900 tracking-tight">
              {formatNumber(item.value)}
            </div>
            {item.sub ? <div className="text-sm text-gray-500">{item.sub}</div> : null}
            {typeof item.delta === "number" ? (
              <DeltaPill delta={item.delta} />
            ) : null}
          </div>
          <div
            className="h-10 w-10 rounded-xl text-white flex items-center justify-center"
            style={{ background: `linear-gradient(135deg, ${item.gradientFrom}, ${item.gradientTo})` }}
          >
            <Icon className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Sparkline */}
      {hasTrend ? (
        <div className="px-2 pb-2 pt-0 h-20">
          <ResponsiveContainer width="100%" height="100%">
            {item.chart === "area" ? (
              <AreaChart data={data} margin={{ top: 0, right: 8, left: 8, bottom: 0 }}>
                <defs>
                  <linearGradient id={`grad-${item.key}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={item.gradientFrom} stopOpacity={0.35} />
                    <stop offset="100%" stopColor={item.gradientTo} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <Tooltip content={<MiniTooltip label={item.label} />} />
                <Area type="monotone" dataKey="y" stroke={item.gradientFrom} strokeWidth={2} fill={`url(#grad-${item.key})`} />
              </AreaChart>
            ) : item.chart === "line" ? (
              <LineChart data={data} margin={{ top: 4, right: 8, left: 8, bottom: 0 }}>
                <Tooltip content={<MiniTooltip label={item.label} />} />
                <Line type="monotone" dataKey="y" stroke={item.gradientFrom} strokeWidth={2} dot={false} />
              </LineChart>
            ) : (
              <BarChart data={data} margin={{ top: 0, right: 8, left: 8, bottom: 0 }}>
                <Tooltip content={<MiniTooltip label={item.label} />} />
                <Bar dataKey="y" fill={item.gradientFrom} radius={[4,4,0,0]} />
              </BarChart>
            )}
          </ResponsiveContainer>
        </div>
      ) : null}
    </motion.div>
  );
}

/* ---------------- Bits & bobs ---------------- */

function DeltaPill({ delta }) {
  const up = delta >= 0;
  return (
    <div
      className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs mt-1 ${
        up ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-700"
      }`}
      aria-label={`Delta ${up ? "up" : "down"} ${Math.abs(delta)} percent`}
    >
      <span className="font-medium">{up ? "▲" : "▼"} {Math.abs(delta)}%</span>
      <span className="text-gray-500">vs last period</span>
    </div>
  );
}

function formatNumber(n) {
  if (typeof n === "string") return n;
  try { return new Intl.NumberFormat("en-GB").format(n); } catch { return String(n); }
}

/** Tiny tooltip for sparklines (kept minimal to avoid clutter) */
function MiniTooltip({ active, payload, label, labelPrefix = "" }) {
  if (!active || !payload?.length) return null;
  const v = payload[0].value;
  return (
    <div className="rounded-md border bg-white/95 px-2 py-1 text-xs text-gray-800 shadow">
      {labelPrefix}{label}: <b>{formatNumber(v)}</b>
    </div>
  );
}