import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Plus, FileText, Camera, FileBarChart, Receipt } from "lucide-react";

export default function QuickActions() {
  const navigate = useNavigate();
  return (
    <div className="flex flex-col sm:flex-row gap-3">
      <Link to={createPageUrl("NewJob")}>
        <Button size="sm" className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          New Job
        </Button>
      </Link>
      <Link to={createPageUrl("AiQuoteEditor")}>
        <Button variant="outline" size="sm" className="w-full sm:w-auto bg-white/10 hover:bg-white/20 text-white border-white/30">
          <FileBarChart className="w-4 h-4 mr-2" />
          New Quote
        </Button>
      </Link>
      <Link to={createPageUrl("NewInvoice")}>
        <Button variant="outline" size="sm" className="w-full sm:w-auto bg-white/10 hover:bg-white/20 text-white border-white/30">
          <Receipt className="w-4 h-4 mr-2" />
          New Invoice
        </Button>
      </Link>
      <Link to={createPageUrl("NewCertificate")}>
        <Button variant="outline" size="sm" className="w-full sm:w-auto bg-white/10 hover:bg-white/20 text-white border-white/30">
          <FileText className="w-4 h-4 mr-2" />
          New Certificate
        </Button>
      </Link>
      <Link to={createPageUrl("Photos")}>
        <Button variant="outline" size="sm" className="w-full sm:w-auto bg-white/10 hover:bg-white/20 text-white border-white/30">
          <Camera className="w-4 h-4 mr-2" />
          Upload Photos
        </Button>
      </Link>
    </div>
  );
}