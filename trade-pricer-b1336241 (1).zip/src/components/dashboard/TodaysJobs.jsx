
import * as React from "react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CalendarClock, MapPin, User2, Clock3, ChevronRight } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function TodaysJobs({
  jobs = [],
  customers = [],
}) {
  if (!jobs.length) {
    return (
      <EmptyState
        title="No jobs today"
        text="You have nothing booked for today. Create a job or reschedule from the Jobs page."
        actionLabel="Create a job"
        onAction={() => (location.href = createPageUrl("NewJob"))}
      />
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 2xl:grid-cols-3 gap-4">
      {jobs.map((job, i) => (
        <JobCard key={job.id} job={job} customer={customers.find(c => c.id === job.customer_id)} index={i} />
      ))}
    </div>
  );
}

/* ---------------- item ---------------- */

function JobCard({ job, customer, index }) {
  const start = job.start_time || job.scheduled_date;
  const end = job.end_time || job.scheduled_end_time;
  const time = start ? format(new Date(start), "HH:mm") : "—";
  const timeEnd = end ? format(new Date(end), "HH:mm") : "";

  const address = [
    job.address_line1,
    job.address_line2,
    job.town,
    job.postcode,
  ]
    .filter(Boolean)
    .join(", ");

  const statusColour =
    job.status === "completed"
      ? "bg-emerald-50 text-emerald-700"
      : job.status === "in_progress"
      ? "bg-blue-50 text-blue-700"
      : "bg-gray-100 text-gray-700";

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.04 }}>
      <Card className="border-0 shadow-sm hover:shadow-md transition">
        <CardContent className="p-4 space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="text-sm text-gray-500">Job</div>
              <div className="text-lg font-semibold text-gray-900 truncate">{job.title || "Untitled job"}</div>
            </div>
            <span className={`text-xs px-2 py-1 rounded-full flex-shrink-0 ${statusColour}`}>
              {prettyStatus(job.status)}
            </span>
          </div>

          <Row icon={<CalendarClock className="w-4 h-4 text-blue-600" />}>
            <span className="font-medium">
              {time}
              {timeEnd ? ` to ${timeEnd}` : ""}
            </span>
          </Row>

          {customer ? (
            <Row icon={<User2 className="w-4 h-4 text-blue-600" />}>
              <span className="truncate">{customer.full_name || customer.email || "Customer"}</span>
            </Row>
          ) : null}

          {address ? (
            <Row icon={<MapPin className="w-4 h-4 text-blue-600" />}>
              <span className="truncate">{address}</span>
            </Row>
          ) : null}

          <div className="flex items-center gap-2 pt-1">
            <Button asChild size="sm" className="bg-blue-600 hover:bg-blue-700">
              <a href={createPageUrl(`Job?id=${job.id}`)}>
                Open job <ChevronRight className="w-4 h-4 ml-1" />
              </a>
            </Button>
            <Button asChild size="sm" variant="outline">
              <a href={createPageUrl(`NewDiary?job_id=${job.id}`)}>
                Site diary <Clock3 className="w-4 h-4 ml-1" />
              </a>
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

/* ---------------- ui bits ---------------- */

function Row({ icon, children }) {
  return (
    <div className="flex items-center gap-2 text-gray-700">
      <div className="w-7 h-7 rounded-md bg-blue-50 flex items-center justify-center">{icon}</div>
      <div className="truncate">{children}</div>
    </div>
  );
}

function EmptyState({
  title,
  text,
  actionLabel,
  onAction,
}) {
  return (
    <div className="border rounded-xl bg-white p-8 text-center shadow-sm">
      <div className="mx-auto h-10 w-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-700">
        <CalendarClock className="w-5 h-5" />
      </div>
      <div className="mt-3 text-lg font-semibold text-gray-900">{title}</div>
      <div className="mt-1 text-gray-600">{text}</div>
      <Button variant="outline" className="mt-4" onClick={onAction}>
        {actionLabel}
      </Button>
    </div>
  );
}

function prettyStatus(s) {
  if (!s) return "scheduled";
  return s.replace(/_/g, " ");
}
