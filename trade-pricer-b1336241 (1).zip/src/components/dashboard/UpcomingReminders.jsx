import * as React from "react";
import { motion } from "framer-motion";
import { format, isValid, parseISO } from "date-fns";
import { BellRing, FileText, Mail, Phone, CalendarDays, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { createPageUrl } from "@/utils";

export default function UpcomingReminders({
  reminders = [],
  customers = [],
}) {
  if (!reminders.length) {
    return (
      <EmptyState
        title="No reminders due"
        text="Schedule reminders from certificates and invoices. You will see the next five here."
        actionLabel="Create reminder"
        onAction={() => (location.href = createPageUrl("Reminders"))}
      />
    );
  }

  return (
    <div className="space-y-3">
      {reminders.map((r, i) => (
        <ReminderItem key={r.id} reminder={r} customer={customers.find(c => c.id === r.customer_id)} index={i} />
      ))}
    </div>
  );
}

/* ---------------- item ---------------- */

function ReminderItem({
  reminder,
  customer,
  index,
}) {
  const due = safeDate(reminder.due_date);
  const dueStr = due ? format(due, "EEE d MMM") : "Date TBC";
  const ch = reminder.channel || "email_and_sms";
  const channelPill =
    ch === "email"
      ? { cls: "bg-blue-50 text-blue-700", icon: <Mail className="w-3.5 h-3.5" />, txt: "Email" }
      : ch === "sms"
      ? { cls: "bg-emerald-50 text-emerald-700", icon: <Phone className="w-3.5 h-3.5" />, txt: "SMS" }
      : { cls: "bg-purple-50 text-purple-700", icon: <Mail className="w-3.5 h-3.5" />, txt: "Email + SMS" };

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.04 }}>
      <Card className="border-0 shadow-sm hover:shadow-md transition">
        <CardContent className="p-4">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-orange-50 text-orange-700 flex items-center justify-center">
                <BellRing className="w-4 h-4" />
              </div>
              <div>
                <div className="text-sm text-gray-500">Due {dueStr}</div>
                <div className="text-base font-semibold text-gray-900">
                  {titleFromReminder(reminder)}
                </div>
                {customer ? (
                  <div className="text-sm text-gray-600 mt-0.5">
                    {customer.full_name || customer.email || customer.phone || "Customer"}
                  </div>
                ) : null}
                <div className="mt-2 flex items-center gap-2">
                  <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full ${channelPill.cls}`}>
                    {channelPill.icon} {channelPill.txt}
                  </span>
                  {reminder.certificate_id ? (
                    <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-700">
                      <FileText className="w-3.5 h-3.5" /> Certificate
                    </span>
                  ) : null}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {reminder.job_id ? (
                <Button asChild size="sm" variant="outline">
                  <a href={createPageUrl(`Job?id=${reminder.job_id}`)}>
                    Open job <ChevronRight className="w-4 h-4 ml-1" />
                  </a>
                </Button>
              ) : null}
              <Button asChild size="sm" className="bg-blue-600 hover:bg-blue-700">
                <a href={createPageUrl("Reminders")}>
                  Manage <ChevronRight className="w-4 h-4 ml-1" />
                </a>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

/* ---------------- helpers ---------------- */

function titleFromReminder(r) {
  if (r.reminder_type) {
    return r.reminder_type
      .replace(/_/g, " ")
      .replace(/\b\w/g, s => s.toUpperCase());
  }
  if (r.message_template_key) {
    return r.message_template_key.replace(/_/g, " ");
  }
  return "Reminder";
}

function safeDate(value) {
  if (!value) return null;
  const d = typeof value === "string" ? parseISO(value) : new Date(value);
  return isValid(d) ? d : null;
}

function EmptyState({
  title,
  text,
  actionLabel,
  onAction,
}) {
  return (
    <div className="border rounded-xl bg-white p-6 text-center shadow-sm">
      <div className="mx-auto h-10 w-10 rounded-full bg-orange-50 flex items-center justify-center text-orange-700">
        <CalendarDays className="w-5 h-5" />
      </div>
      <div className="mt-3 text-lg font-semibold text-gray-900">{title}</div>
      <div className="mt-1 text-gray-600">{text}</div>
      <Button variant="outline" className="mt-3" onClick={onAction}>
        {actionLabel}
      </Button>
    </div>
  );
}