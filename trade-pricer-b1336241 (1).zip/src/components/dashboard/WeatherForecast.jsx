import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { format } from 'date-fns';
import { Sun, Cloud, CloudRain, Cloudy, Snowflake, CloudSun, Wind, MapPin } from 'lucide-react';
import { motion } from 'framer-motion';

const weatherIcons = {
  default: Sun,
  0: Sun, // Clear sky
  1: CloudSun, // Mainly clear
  2: Cloudy, // Partly cloudy
  3: Cloud, // Overcast
  45: Cloud, // Fog
  48: Cloud, // Depositing rime fog
  51: CloudRain, // Light drizzle
  53: CloudRain, // Moderate drizzle
  55: CloudRain, // Dense drizzle
  61: CloudRain, // Light rain
  63: CloudRain, // Moderate rain
  65: CloudRain, // Heavy rain
  71: Snowflake, // Slight snow fall
  73: Snowflake, // Moderate snow fall
  75: Snowflake, // Heavy snow fall
  80: CloudRain, // Rain showers
  81: CloudRain, // Moderate rain showers
  82: CloudRain, // Violent rain showers
  85: Snowflake, // Snow showers
  86: Snowflake, // Heavy snow showers
  95: CloudRain, // Thunderstorm
};

function getWeatherIcon(code) {
  return weatherIcons[code] || weatherIcons.default;
}

export default function WeatherForecast({ forecast, location }) {
  const isLoading = !forecast || forecast.length === 0;

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-blue-600" />
            5-Day Forecast {location ? `for ${location}` : ''}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className={`grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 ${isLoading ? 'h-32' : ''}`}>
            {isLoading ? (
              <div className="col-span-full flex items-center justify-center text-gray-500">
                <div className="animate-pulse flex items-center gap-2">
                  <Wind className="w-5 h-5 animate-spin" />
                  <span>Loading weather data...</span>
                </div>
              </div>
            ) : (
              forecast.map((day, index) => {
                const Icon = getWeatherIcon(day.code);
                return (
                  <div key={day.date} className="flex flex-col items-center justify-center space-y-2 p-3 rounded-lg bg-gray-50 text-center">
                    <div className="font-semibold text-gray-800">
                      {index === 0 ? "Today" : format(new Date(day.date), 'EEE')}
                    </div>
                    <Icon className="w-8 h-8 text-blue-500" />
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-xl font-bold text-gray-900">{day.temp_max}°</span>
                      <span className="text-gray-500">{day.temp_min}°</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}