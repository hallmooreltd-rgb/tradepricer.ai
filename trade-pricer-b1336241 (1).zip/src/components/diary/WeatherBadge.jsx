import React from "react";
import { Cloud, CloudRain, Sun, Snowflake } from "lucide-react";

export default function WeatherBadge({ weather }) {
  if (!weather || !weather.summary) return null;
  
  const getWeatherIcon = () => {
    const summary = weather.summary.toLowerCase();
    if (summary.includes('rain') || summary.includes('drizzle')) return CloudRain;
    if (summary.includes('snow')) return Snowflake;
    if (summary.includes('clear') || summary.includes('sunny')) return Sun;
    return Cloud;
  };
  
  const Icon = getWeatherIcon();
  
  return (
    <div className="inline-flex items-center gap-2 rounded-full bg-blue-50 px-3 py-1 text-blue-700 text-sm">
      <Icon className="w-4 h-4" />
      <span>{weather.summary}</span>
      <span>•</span>
      <span>{weather.temp_c}°C</span>
      {weather.precipitation_mm > 0 && (
        <>
          <span>•</span>
          <span>{weather.precipitation_mm}mm</span>
        </>
      )}
    </div>
  );
}