import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { X, Send, Loader2 } from "lucide-react";
import { buildInvoicePdfBrowser } from "./buildInvoicePdf";
import { UploadFile } from "@/api/integrations";
import { SendEmail } from "@/api/integrations";
import { Invoice } from "@/api/entities";

export default function SendInvoiceModal({
  open,
  onClose,
  company,
  customer,
  invoice,
  portalUrl,
  onMarkSent,
}) {
  const [to, setTo] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    if (!open) return;
    setTo(customer?.email || "");
    setSubject(`Invoice ${invoice?.invoice_number} from ${company?.name}`);
    setMessage(
      `Hi ${customer?.full_name || "there"},\n\nPlease find your invoice attached.\n` +
      (portalUrl ? `You can also view it online here: ${portalUrl}\n` : "") +
      `\nBank transfer preferred. Reply if you would like a card payment link.\n\nThanks,\n${company?.name}`
    );
    setErr("");
  }, [open, customer, company, invoice, portalUrl]);

  if (!open) return null;

  const sendNow = async () => {
    setErr("");
    if (!to) {
      setErr("Recipient email is required.");
      return;
    }
    setBusy(true);
    try {
      const blob = await buildInvoicePdfBrowser({ company, customer, invoice });
      const pdfFile = new File([blob], `${invoice.invoice_number}.pdf`, { type: 'application/pdf' });
      
      const { file_url: pdfUrl } = await UploadFile({ file: pdfFile });
      
      await Invoice.update(invoice.id, { pdf_url: pdfUrl });

      const finalMessage = message + `\n\nDownload your PDF invoice here: ${pdfUrl}`;

      await SendEmail({
        to,
        from_name: company?.name || "CertiFlow",
        subject,
        body: finalMessage,
      });

      const updatedInvoice = await Invoice.update(invoice.id, { status: "sent" });
      if (onMarkSent) onMarkSent(updatedInvoice);

      onClose();
      alert("Invoice sent successfully!");
    } catch (e) {
      console.error(e);
      setErr(e?.message || "Could not send the invoice.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-xl">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-semibold">Send Invoice</h2>
          <button className="p-2" onClick={onClose} aria-label="Close"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-6 space-y-4">
          {err ? <p className="text-red-600 text-sm p-3 bg-red-50 rounded-md">{err}</p> : null}
          <div>
            <Label>To</Label>
            <Input type="email" value={to} onChange={e => setTo(e.target.value)} />
          </div>
          <div>
            <Label>Subject</Label>
            <Input value={subject} onChange={e => setSubject(e.target.value)} />
          </div>
          <div>
            <Label>Message</Label>
            <Textarea rows={8} value={message} onChange={e => setMessage(e.target.value)} />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={sendNow} disabled={busy} className="bg-blue-600 hover:bg-blue-700">
              {busy ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Sending</> : <>Send <Send className="w-4 h-4 ml-2" /></>}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}