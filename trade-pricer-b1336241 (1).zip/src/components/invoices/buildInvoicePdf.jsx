
import jsPDF from "jspdf";
import { drawWatermarkIfNeeded } from "../pdf/watermark";

const gbp = (n) => new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

async function loadImage(src) {
  const el = new Image();
  el.crossOrigin = "anonymous";
  el.referrerPolicy = "no-referrer";
  return new Promise((resolve, reject) => {
    el.onload = () => resolve({ el, width: el.naturalWidth, height: el.naturalHeight });
    el.onerror = reject;
    el.src = src;
  });
}

export async function buildInvoicePdfBrowser({
  company,
  customer,
  invoice,
}) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });

  let x = 20;
  let y = 16;

  const logo = invoice.logo_url || company?.logo_url;
  if (logo) {
    try {
      const img = await loadImage(logo);
      const w = 40;
      const r = img.width ? w / img.width : 1;
      const h = img.height ? img.height * r : 16;
      doc.addImage(img.el, "PNG", x, y - 6, w, h);
      x = 65;
    } catch (e) {
        console.error("Could not load image for PDF", e);
    }
  }

  doc.setFontSize(16);
  doc.text(company?.name || "Company", x, y);
  doc.setFontSize(10);
  const contact = [
    company?.address_line1,
    company?.address_line2,
    [company?.town_city, company?.postcode].filter(Boolean).join(" "),
  ].filter(Boolean);
  if (contact.length) doc.text(contact.join(", "), x, y + 6);
  const line2 = [company?.phone && `Tel: ${company.phone}`, company?.email && `Email: ${company.email}`]
    .filter(Boolean).join("    ");
  if (line2) doc.text(line2, x, y + 12);

  doc.setFontSize(18);
  doc.text("Invoice", 20, 42);
  doc.setFontSize(11);
  doc.text(`Invoice number: ${invoice.invoice_number}`, 20, 49);
  doc.text(`Issue date: ${invoice.issue_date}`, 20, 55);
  doc.text(`Due date: ${invoice.due_date}`, 20, 61);

  const addr = [
    customer?.full_name,
    customer?.address_line1,
    customer?.address_line2,
    [customer?.town_city, customer?.postcode].filter(Boolean).join(" "),
  ].filter(Boolean).join("\n");
  doc.text("Bill to:", 130, 42);
  doc.text(addr || "", 130, 49);

  let tableY = 75;
  doc.setFontSize(11);
  doc.text("Description", 20, tableY);
  doc.text("Qty", 120, tableY);
  doc.text("Unit ex VAT", 135, tableY);
  doc.text("VAT", 165, tableY);
  doc.text("Line total", 185, tableY, { align: "right" });
  doc.setLineWidth(0.2);
  doc.line(20, tableY + 2, 190, tableY + 2);

  let yCursor = tableY + 8;
  const items = Array.isArray(invoice.items_json) ? invoice.items_json : JSON.parse(invoice.items_json || '[]');
  items.forEach((it) => {
    const descLines = doc.splitTextToSize(String(it.description || ""), 95);
    const rowH = Math.max(6, descLines.length * 5);
    doc.text(descLines, 20, yCursor);
    doc.text(String(it.quantity || 0), 120, yCursor);
    doc.text(gbp(it.unit_price || 0), 135, yCursor);
    doc.text(`${Number(it.vat_rate || 0)}%`, 165, yCursor);
    const lineTotal = (it.quantity || 0) * (it.unit_price || 0) * (1 + (Number(it.vat_rate || 0) / 100));
    doc.text(gbp(lineTotal), 185, yCursor, { align: "right" });
    yCursor += rowH + 3;
  });

  yCursor += 4;
  doc.setLineWidth(0.2);
  doc.line(120, yCursor, 190, yCursor);
  yCursor += 6;
  doc.text("Subtotal", 145, yCursor);
  doc.text(gbp(invoice.subtotal), 185, yCursor, { align: "right" });
  yCursor += 6;
  doc.text("VAT", 145, yCursor);
  doc.text(gbp(invoice.vat_total), 185, yCursor, { align: "right" });
  if (invoice.discount_percent) {
    yCursor += 6;
    const beforeDiscount = Number(invoice.subtotal) + Number(invoice.vat_total);
    const disc = beforeDiscount * (Number(invoice.discount_percent) / 100);
    doc.text(`Discount ${invoice.discount_percent}%`, 145, yCursor);
    doc.text(`- ${gbp(disc)}`, 185, yCursor, { align: "right" });
  }
  yCursor += 8;
  doc.setFontSize(13);
  doc.text("Total", 145, yCursor);
  doc.text(gbp(invoice.total), 185, yCursor, { align: "right" });

  yCursor += 12;
  doc.setFontSize(11);
  if (invoice.notes) {
    doc.text("Notes", 20, yCursor);
    yCursor += 5;
    const lines = doc.splitTextToSize(invoice.notes, 170);
    doc.text(lines, 20, yCursor);
    yCursor += lines.length * 5 + 4;
  }
  if (invoice.terms) {
    doc.text("Terms", 20, yCursor);
    yCursor += 5;
    const lines = doc.splitTextToSize(invoice.terms, 170);
    doc.text(lines, 20, yCursor);
  }

  drawWatermarkIfNeeded(doc, company);
  return doc.output("blob");
}
