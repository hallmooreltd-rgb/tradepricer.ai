
import React, { useEffect, useMemo, useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Expense } from "@/api/entities";
import { User } from "@/api/entities";
import { format } from "date-fns";
import { Loader2, Plus, Trash2, Download, Upload, Receipt, Sparkles } from "lucide-react";
import ExpensesCsvImportModal from "./ExpensesCsvImportModal";
import { InvokeLLM } from "@/api/integrations";

const TYPES = [
  { value: "materials", label: "Materials" },
  { value: "hire", label: "Hire" },
  { value: "subcontractor", label: "Subcontractor" },
  { value: "mileage", label: "Mileage" },
  { value: "other", label: "Other" },
];

export default function ExpensesCard({ job }) {
  const [me, setMe] = useState(null);
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false); // New state for showing add form
  const [importOpen, setImportOpen] = useState(false);
  const [isAiPricing, setIsAiPricing] = useState(false);

  // new entry state
  const [type, setType] = useState("materials");
  const [date, setDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [description, setDescription] = useState("");
  const [supplier, setSupplier] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [cost, setCost] = useState(0); // Renamed from unitCost
  const [vat, setVat] = useState(20); // Renamed from vatRate
  const [miles, setMiles] = useState(0);
  const [mileageRate, setMileageRate] = useState(0.45); // £ per mile

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      try {
        const u = await User.me();
        if (!mounted) return;
        setMe(u);
        // Fetch all expenses for a job
        const exps = await Expense.filter({ company_id: u.company_id, job_id: job.id }, "-created_at", null); 
        if (!mounted) return;
        setRows(exps || []);
      } finally {
        if (mounted) setLoading(false);
      }
    };
    if (job?.id) load(); // Only load if job ID is available
    return () => { mounted = false; };
  }, [job?.id]);

  const reloadExpenses = async () => {
    if (!me || !job?.id) return; // Ensure me and job.id are available before reloading
    try {
        const data = await Expense.filter({ company_id: me.company_id, job_id: job.id }, "-created_at", null); // Fetch all expenses
        setRows(data || []);
      } catch (error) {
        console.error("Error reloading expenses:", error);
      }
  };

  const totals = useMemo(() => {
    const exVat = rows.reduce((a, r) => {
      if (r.type === "mileage") return a + (Number(r.miles || 0) * Number(r.unit_cost_ex_vat || 0));
      const qty = Number(r.quantity || 1);
      const unit = Number(r.unit_cost_ex_vat || 0);
      return a + qty * unit;
    }, 0);
    const vat = rows.reduce((a, r) => {
      const rate = Number(r.vat_rate || 0) / 100;
      if (r.type === "mileage") return a + (Number(r.miles || 0) * Number(r.unit_cost_ex_vat || 0)) * rate;
      const qty = Number(r.quantity || 1);
      const unit = Number(r.unit_cost_ex_vat || 0);
      return a + qty * unit * rate;
    }, 0);
    return { exVat, vat, incVat: exVat + vat };
  }, [rows]);

  const addRow = async () => {
    if (!description.trim()) return; // Prevent adding empty descriptions
    const payload = {
      company_id: me.company_id,
      job_id: job.id,
      type,
      description: description.trim(),
      supplier: supplier?.trim(),
      date,
      vat_rate: Number(vat), // Use 'vat' state
    };
    if (type === "mileage") {
      payload.miles = Number(miles || 0);
      payload.unit_cost_ex_vat = Number(mileageRate || 0);
    } else {
      payload.quantity = Number(quantity || 1);
      payload.unit_cost_ex_vat = Number(cost || 0); // Use 'cost' state
    }
    const created = await Expense.create(payload);
    setRows(prev => [created, ...prev]);
    setDescription("");
    setSupplier("");
    setQuantity(1);
    setCost(0); // Reset 'cost'
    setMiles(0);
    setIsAdding(false); // Hide the add form after successful addition
  };

  const remove = async (id) => {
    setRows(prev => prev.filter(r => r.id !== id));
    try { await Expense.delete(id); } catch (error) {
      console.error("Error deleting expense:", error);
      // Optionally, re-fetch or re-add the item if delete fails on backend
    }
  };

  const exportCsv = () => {
    const headers = ["Date", "Type", "Description", "Quantity", "Unit Cost", "VAT Rate", "Supplier", "Ref"];
    const csvRows = [
      headers.join(","),
      ...rows.map(r => [
        r.date || "",
        r.type,
        `"${String(r.description).replace(/"/g, '""')}"`, // Handle quotes in description
        r.type === "mileage" ? "" : r.quantity, // Quantity is empty for mileage
        r.unit_cost_ex_vat,
        r.vat_rate,
        `"${String(r.supplier || "").replace(/"/g, '""')}"`, // Handle quotes in supplier
        `"${String(r.ref || "").replace(/"/g, '""')}"` // Handle quotes in ref
      ].join(","))
    ];
    
    const blob = new Blob([csvRows.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `expenses-${job?.title?.replace(/\s/g, '_') || 'job'}-${format(new Date(), "yyyy-MM-dd")}.csv`; // Dynamic filename
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleAiPrice = async () => {
    if (!description.trim()) return;
    setIsAiPricing(true);
    try {
      const result = await InvokeLLM({
        prompt: `Based on the current UK market, parse the following item description and provide the quantity and estimated trade price (ex VAT) per unit. Refine the description for clarity if needed. Also suggest a typical supplier (e.g., Screwfix, Toolstation, etc.). Description: "${description}"`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            description: { type: "string" },
            quantity: { type: "number" },
            unit_cost_ex_vat: { type: "number" },
            supplier_suggestion: { type: "string" }
          },
          required: ["description", "quantity", "unit_cost_ex_vat"]
        }
      });
      
      if (result) {
        setDescription(result.description || description);
        setQuantity(result.quantity || 1);
        setCost(result.unit_cost_ex_vat || 0);
        setSupplier(result.supplier_suggestion || supplier);
      }

    } catch (e) {
      console.error("AI pricing failed", e);
      // In a real app, you might want to show a user-friendly error message here.
    } finally {
      setIsAiPricing(false);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader><CardTitle>Materials and expenses</CardTitle></CardHeader>
        <CardContent className="flex items-center gap-2 text-gray-700 py-8">
          <Loader2 className="w-5 h-5 animate-spin" /> Loading…
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <CardTitle className="flex items-center gap-2">
            <Receipt className="w-5 h-5" />
            Materials and expenses
          </CardTitle>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={exportCsv}>
              <Download className="w-4 h-4 mr-2" /> 
              Export CSV
            </Button>
            <Button variant="outline" size="sm" onClick={() => setImportOpen(true)}>
              <Upload className="w-4 h-4 mr-2" />
              Import CSV
            </Button>
            <Button size="sm" onClick={() => setIsAdding(!isAdding)}> {/* Toggles the add form visibility */}
              <Plus className="w-4 h-4 mr-2" /> 
              Add expense
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {isAdding && ( // Conditionally render the add form
          <div className="border rounded-lg p-4 bg-gray-50 space-y-4">
            <h4 className="font-medium text-gray-900">Add new expense</h4>
            
            {/* First row - Date, Type, Supplier */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="expense-date">Date</Label>
                <Input 
                  id="expense-date"
                  type="date" 
                  value={date} 
                  onChange={e => setDate(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="expense-type">Type</Label>
                <Select value={type} onValueChange={setType}>
                  <SelectTrigger id="expense-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="expense-supplier">Supplier</Label>
                <Input 
                  id="expense-supplier"
                  value={supplier} 
                  onChange={e => setSupplier(e.target.value)} 
                  placeholder="Optional" 
                />
              </div>
            </div>

            {/* Second row - Description with AI button */}
            <div className="space-y-2">
              <Label htmlFor="expense-description">Description</Label>
              <div className="relative">
                <Input 
                  id="expense-description"
                  value={description} 
                  onChange={e => setDescription(e.target.value)} 
                  placeholder="e.g. 10 bags of cement"
                  className="pr-12"
                />
                <Button
                  type="button"
                  size="icon"
                  variant="ghost"
                  className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8"
                  onClick={handleAiPrice}
                  disabled={!description || isAiPricing}
                  title="Find price with AI"
                >
                  {isAiPricing ? 
                    <Loader2 className="w-4 h-4 animate-spin" /> : 
                    <Sparkles className="w-4 h-4 text-purple-600 hover:text-purple-700" />
                  }
                </Button>
              </div>
            </div>

            {/* Third row - Quantity/Cost or Mileage fields */}
            {type === "mileage" ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="expense-miles">Miles</Label>
                  <Input 
                    id="expense-miles"
                    type="number" 
                    inputMode="decimal" 
                    value={miles} 
                    onChange={e => setMiles(Number(e.target.value))} 
                  />
                </div>
                <div>
                  <Label htmlFor="expense-rate">Rate £/mile</Label>
                  <Input 
                    id="expense-rate"
                    type="number" 
                    inputMode="decimal" 
                    value={mileageRate} 
                    onChange={e => setMileageRate(Number(e.target.value))} 
                  />
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="expense-quantity">Quantity</Label>
                  <Input 
                    id="expense-quantity"
                    type="number" 
                    inputMode="decimal" 
                    value={quantity} 
                    onChange={e => setQuantity(Number(e.target.value))} 
                  />
                </div>
                <div>
                  <Label htmlFor="expense-cost">Unit cost ex VAT</Label>
                  <Input 
                    id="expense-cost"
                    type="number" 
                    inputMode="decimal" 
                    step="0.01"
                    value={cost} 
                    onChange={e => setCost(Number(e.target.value))} 
                  />
                </div>
                <div>
                  <Label htmlFor="expense-vat">VAT rate</Label>
                  <Select value={String(vat)} onValueChange={v => setVat(Number(v))}>
                    <SelectTrigger id="expense-vat">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0">0%</SelectItem>
                      <SelectItem value="5">5%</SelectItem>
                      <SelectItem value="20">20%</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {/* Action buttons */}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsAdding(false)}>
                Cancel
              </Button>
              <Button onClick={addRow} disabled={!description.trim()}>
                <Plus className="w-4 h-4 mr-2" /> 
                Add Expense
              </Button>
            </div>
          </div>
        )}

        <div className="space-y-3">
          {rows.length === 0 ? <p className="text-gray-600 text-center py-8">No expenses yet.</p> : null}
          {rows.map(r => {
            const qty = Number(r.quantity || 1);
            const unit = Number(r.unit_cost_ex_vat || 0);
            const miles = Number(r.miles || 0);
            const ex = r.type === "mileage" ? miles * unit : qty * unit;
            return (
              <div key={r.id} className="border rounded-lg p-4 bg-white flex items-center justify-between hover:bg-gray-50 transition-colors">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap mb-2">
                    <span className="font-medium text-gray-900">{r.type}</span>
                    {r.supplier && <span className="text-gray-500">• {r.supplier}</span>}
                    {r.date && <span className="text-gray-500">• {r.date}</span>}
                  </div>
                  <div className="text-sm text-gray-600 break-words">{r.description}</div>
                </div>
                <div className="flex items-center gap-4 ml-4">
                  <div className="text-right">
                    <div className="font-medium text-gray-900">
                      £{ex.toFixed(2)} ex VAT
                    </div>
                    {r.vat_rate && (
                      <div className="text-xs text-gray-500">VAT {r.vat_rate}%</div>
                    )}
                  </div>
                  <Button variant="outline" size="icon" onClick={() => remove(r.id)} aria-label="Remove">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="border rounded-lg p-4 bg-gray-50">
          <div className="grid grid-cols-2 gap-4">
            <div className="text-gray-600">Expenses ex VAT</div>
            <div className="text-right font-medium text-gray-900">£{totals.exVat.toFixed(2)}</div>
            <div className="text-gray-600">VAT</div>
            <div className="text-right font-medium text-gray-900">£{totals.vat.toFixed(2)}</div>
            <div className="text-gray-800 font-semibold border-t pt-2">Total inc VAT</div>
            <div className="text-right text-lg font-bold text-gray-900 border-t pt-2">£{totals.incVat.toFixed(2)}</div>
          </div>
        </div>
      </CardContent>

      <ExpensesCsvImportModal
        open={importOpen}
        onClose={(imported) => { // Made onClose synchronous and calls reloadExpenses
          setImportOpen(false);
          if (imported) {
            reloadExpenses(); // Call the helper function to reload expenses
          }
        }}
        job={job}
      />
    </Card>
  );
}
