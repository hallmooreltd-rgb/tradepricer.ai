
import React, { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Expense } from "@/api/entities";
import { User } from "@/api/entities";
import { X } from "lucide-react";

export default function ExpensesCsvImportModal({
  open,
  onClose,
  job,
}) {
  const [text, setText] = useState("");
  const [supplier, setSupplier] = useState("Screwfix");
  const [vatDefault, setVatDefault] = useState(20);
  const [dateOverride, setDateOverride] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  if (!open) return null;

  const parsed = useMemo(() => {
    try {
      return parseCsv(text, supplier, vatDefault, dateOverride);
    } catch (e) {
      console.error("Error parsing CSV:", e);
      // Optionally set an error state here if the parseCsv function throws
      // setErr("Failed to parse CSV. Please check format.");
      return [];
    }
  }, [text, supplier, vatDefault, dateOverride]);

  const importRows = async () => {
    setErr("");
    if (!parsed.length) { 
      setErr("No rows to import."); 
      return; 
    }
    setBusy(true);
    try {
      const me = await User.me();
      let count = 0;
      for (const r of parsed) {
        await Expense.create({
          company_id: me.company_id,
          job_id: job.id,
          type: "materials",
          description: r.description,
          quantity: r.quantity,
          unit_cost_ex_vat: r.unit_cost_ex_vat,
          vat_rate: r.vat_rate,
          supplier: r.supplier,
          date: r.date,
        });
        count++;
      }
      onClose(count);
    } catch (e) {
      console.error(e);
      setErr("Import failed. Please check your data and try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-3xl shadow-xl max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-lg font-semibold">Import materials from CSV</h2>
          <button onClick={() => onClose()} className="p-2">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-4 space-y-4 overflow-y-auto max-h-[calc(90vh-120px)]">
          {err && <p className="text-red-600 bg-red-50 p-3 rounded-lg">{err}</p>}
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label>Supplier</Label>
              <select 
                className="border rounded-md h-10 px-3 w-full" 
                value={supplier} 
                onChange={e => setSupplier(e.target.value)}
              >
                <option>Screwfix</option>
                <option>Toolstation</option>
                <option>Other</option>
              </select>
            </div>
            <div>
              <Label>Default VAT %</Label>
              <select 
                className="border rounded-md h-10 px-3 w-full" 
                value={String(vatDefault)} 
                onChange={e => setVatDefault(Number(e.target.value))}
              >
                <option value="0">0%</option>
                <option value="5">5%</option>
                <option value="20">20%</option>
              </select>
            </div>
            <div>
              <Label>Date override (optional)</Label>
              <Input 
                type="date" 
                value={dateOverride}
                onChange={e => setDateOverride(e.target.value)} 
              />
              <p className="text-xs text-gray-500 mt-1">Leave blank to use CSV date if present.</p>
            </div>
          </div>

          <div>
            <Label>Paste CSV content here</Label>
            <Textarea 
              rows={8} 
              value={text} 
              onChange={e => setText(e.target.value)} 
              placeholder="Paste your CSV file contents here..."
              className="font-mono text-sm"
            />
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Preview ({parsed.length} rows)</CardTitle>
            </CardHeader>
            <CardContent>
              {!parsed.length ? (
                <p className="text-gray-600">No rows detected. Check your CSV format.</p>
              ) : (
                <div className="space-y-1 text-sm">
                  {parsed.slice(0, 5).map((r, i) => (
                    <div key={i} className="p-2 bg-gray-50 rounded">
                      <strong>{r.supplier}</strong> · {r.description} × {r.quantity} at £{r.unit_cost_ex_vat.toFixed(2)} ex VAT ({r.vat_rate}%)
                      {r.date && <span className="text-gray-500"> · {r.date}</span>}
                    </div>
                  ))}
                  {parsed.length > 5 && (
                    <div className="text-gray-500 text-center">... and {parsed.length - 5} more rows</div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button variant="outline" onClick={() => onClose()}>Cancel</Button>
            <Button 
              onClick={importRows} 
              disabled={busy || !parsed.length}
              className="bg-green-600 hover:bg-green-700"
            >
              {busy ? "Importing..." : `Import ${parsed.length} rows`}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

function parseCsv(text, supplier, vatDefault, dateOverride) {
  const lines = text.trim().split(/\r?\n/);
  if (!lines.length) return [];
  
  // Skip empty lines at the beginning or end of the CSV data
  const nonEmptyLines = lines.filter(line => line.trim() !== '');
  if (!nonEmptyLines.length) return [];

  const headers = nonEmptyLines[0].split(",").map(h => h.trim().toLowerCase().replace(/"/g, ''));

  // Try to detect matching columns
  const idx = {
    desc: headers.findIndex(h => ["description","item","product","product name","name"].includes(h)),
    qty: headers.findIndex(h => ["qty","quantity","q"].includes(h)),
    ex: headers.findIndex(h => ["price ex vat","ex vat","net price","unit price","price"].includes(h)),
    vat: headers.findIndex(h => ["vat","vat %","tax","vat rate"].includes(h)),
    date: headers.findIndex(h => ["date","order date","invoice date"].includes(h)),
  };

  const out = [];
  for (let i = 1; i < nonEmptyLines.length; i++) {
    const line = nonEmptyLines[i];
    if (line.trim() === '') continue; // skip empty or whitespace-only lines within the CSV body

    const cols = splitCsvLine(line);
    if (cols.length < 1) continue; // skip rows that result in no columns (e.g., just a comma and nothing else)
    
    // Bug Fix 1: Ensure description always has a value, preferring detected column.
    // Fallback to joining first few columns as a heuristic if no specific description column.
    const description = take(cols, idx.desc) || cols.slice(0, 3).filter(s => s.trim() !== '').join(" ").slice(0, 120).trim() || "Imported item";
    
    const quantity = Number(take(cols, idx.qty)) || 1; // Default to 1 if quantity is missing or invalid

    // Bug Fix 2: Changed `take(cols, Math.min(1, cols.length - 1))` to `"0"`.
    // This removes an ambiguous heuristic for price and ensures it defaults to 0 if not found.
    const priceStr = String(take(cols, idx.ex) || "0");
    const unit_cost_ex_vat = Number(priceStr.replace(/[£,$]/g, "")) || 0;

    const vatStr = String(take(cols, idx.vat) || String(vatDefault)); // Ensure vatDefault is string for concatenation
    const vat_rate = Number(vatStr.replace("%","")) || vatDefault;

    // Bug Fix 3: Changed `undefined` to `""` for consistency with string fields and database nullability.
    const date = dateOverride || take(cols, idx.date) || ""; 
    
    // Only import if a valid description is found and unit cost is positive
    if (!description || unit_cost_ex_vat <= 0) continue;
    
    out.push({ 
      description: description, 
      quantity, 
      unit_cost_ex_vat, 
      vat_rate, 
      supplier, 
      date 
    });
  }
  return out;
}

function splitCsvLine(line) {
  const out = [];
  let cur = "", inQ = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"' ) {
      // Handle escaped double quotes within a quoted field: ""
      if (inQ && line[i+1] === '"') { 
        cur += '"'; 
        i++; // Skip the next quote as it's escaped
        continue; 
      }
      inQ = !inQ; // Toggle inQ state
      continue;
    }
    if (ch === "," && !inQ) { 
      out.push(cur.trim()); // Add current segment to output
      cur = ""; // Reset segment
      continue; 
    }
    cur += ch; // Append character to current segment
  }
  out.push(cur.trim()); // Add the last segment
  return out;
}

function take(cols, i) { 
  // Return the value at index i, if it exists and is within bounds. Remove quotes.
  // Otherwise, return an empty string.
  return i >= 0 && i < cols.length ? cols[i].replace(/"/g, '') : ""; 
}
