
import React, { useEffect, useMemo, useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { User } from "@/api/entities";
import { Quote } from "@/api/entities";
import { PriceItem } from "@/api/entities";
import { Timesheet } from "@/api/entities";
import { Expense } from "@/api/entities";
import { Payment } from "@/api/entities";
import { TrendingUp, TrendingDown, AlertTriangle, Target } from "lucide-react";

export default function JobProfitabilityCard({ job }) {
  const [me, setMe] = useState(null);
  const [quote, setQuote] = useState(null);
  const [priceItems, setPriceItems] = useState([]);
  const [timesheets, setTimesheets] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      try {
        const u = await User.me();
        if (!mounted) return;
        setMe(u);

        const [quoteData, timesheetData, expenseData, paymentData, priceItemData] = await Promise.all([
          job?.quote_id && Quote.get ? Quote.get(job.quote_id) : Promise.resolve(null),
          Timesheet.filter ? Timesheet.filter({ company_id: u.company_id, job_id: job.id }) : Promise.resolve([]),
          Expense.filter ? Expense.filter({ company_id: u.company_id, job_id: job.id }) : Promise.resolve([]),
          Payment.filter ? Payment.filter({ company_id: u.company_id, job_id: job.id }) : Promise.resolve([]),
          PriceItem.filter ? PriceItem.filter({ company_id: u.company_id }, "", 1000) : Promise.resolve([])
        ]);

        if (!mounted) return;
        setQuote(quoteData);
        setTimesheets(timesheetData || []);
        setExpenses(expenseData || []);
        setPayments(paymentData || []);
        setPriceItems(priceItemData || []);
      } catch (error) {
        console.error("Error loading profitability data:", error);
      } finally {
        if (mounted) setLoading(false);
      }
    };

    load();
    return () => { mounted = false; };
  }, [job?.id, job?.quote_id]);

  const gbp = (n) => new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

  // Actual costs
  const labourCost = useMemo(() => 
    timesheets.reduce((acc, t) => acc + (Number(t.hours) || 0) * (Number(t.hourly_rate) || 0), 0), 
    [timesheets]
  );

  const materialsCost = useMemo(() => 
    expenses.reduce((acc, e) => acc + (Number(e.quantity) || 1) * (Number(e.unit_cost_ex_vat) || 0), 0), 
    [expenses]
  );

  const totalActualCost = labourCost + materialsCost;
  
  const quoteItems = useMemo(() => {
    if (!quote?.items_json) return [];
    try {
      // Ensure items_json is parsed correctly, it might be a stringified array
      return typeof quote.items_json === 'string' ? JSON.parse(quote.items_json) : quote.items_json;
    } catch {
      return [];
    }
  }, [quote?.items_json]);

  // Forecast costs from price book
  function costForLine(it) {
    if (typeof it.expected_cost_ex_vat === "number") return it.expected_cost_ex_vat;
    if (it.price_item_id) {
      const pi = priceItems.find(p => p.id === it.price_item_id);
      if (pi?.default_cost != null) return Number(it.quantity || 1) * Number(pi.default_cost || 0);
    }
    // fallback: assume 60 percent of sell if nothing else
    return Number(it.quantity || 1) * Number(it.unit_price || 0) * 0.6;
  }

  const forecastCostExVat = quoteItems.reduce((a, it) => a + costForLine(it), 0);

  const forecastMarginExVat = Number(quote?.subtotal || 0) - forecastCostExVat;
  const forecastMarginPct = Number(quote?.subtotal || 0)
    ? (forecastMarginExVat / Number(quote.subtotal)) * 100
    : 0;

  // Actual profit calculations
  const revenue = payments.reduce((acc, p) => acc + (Number(p.amount_gbp) || 0), 0);
  const actualProfit = revenue - totalActualCost;
  const actualMarginPct = revenue ? (actualProfit / revenue) * 100 : 0;

  // Risk assessment
  const targetPct = 30; // or load from Company settings
  const riskLow = forecastMarginPct < targetPct && forecastMarginPct > -100; // a check to avoid showing for very wrong data

  if (loading) {
    return (
      <Card>
        <CardHeader><CardTitle>Job Profitability</CardTitle></CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Target className="w-5 h-5" />
          Job Profitability
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Quote Value */}
          <div className="border rounded-xl p-3 bg-white">
            <div className="text-sm text-gray-600">Quote value</div>
            <div className="text-xl font-bold text-blue-700">{gbp(quote?.total || 0)}</div>
            <div className="text-xs text-gray-500">inc VAT</div>
          </div>

          {/* Forecast Cost */}
          <div className="border rounded-xl p-3 bg-white">
            <div className="text-sm text-gray-600">Forecast cost from price book</div>
            <div className="text-xl font-bold">{gbp(forecastCostExVat)}</div>
            <div className="text-sm text-gray-600 mt-2">Forecast margin</div>
            <div className={`font-semibold ${forecastMarginPct >= targetPct ? "text-green-700" : "text-amber-700"}`}>
              {forecastMarginPct.toFixed(1)}%
            </div>
          </div>

          {/* Actual Costs */}
          <div className="border rounded-xl p-3 bg-white">
            <div className="text-sm text-gray-600">Actual costs</div>
            <div className="text-xl font-bold">{gbp(totalActualCost)}</div>
            <div className="text-xs text-gray-500 mt-1">
              Labour: {gbp(labourCost)} · Materials: {gbp(materialsCost)}
            </div>
          </div>

          {/* Payments Received */}
          <div className="border rounded-xl p-3 bg-white">
            <div className="text-sm text-gray-600">Payments received</div>
            <div className="text-xl font-bold text-green-700">{gbp(revenue)}</div>
            <div className="text-xs text-gray-500">{payments.length} payment{payments.length !== 1 ? 's' : ''}</div>
          </div>

          {/* Actual Profit */}
          <div className="border rounded-xl p-3 bg-white">
            <div className="text-sm text-gray-600">Actual profit</div>
            <div className={`text-xl font-bold ${actualProfit >= 0 ? "text-green-700" : "text-red-700"}`}>
              {gbp(actualProfit)}
            </div>
            <div className="text-sm text-gray-600 mt-1">
              <span className={actualMarginPct >= 0 ? "text-green-700" : "text-red-700"}>
                {actualMarginPct.toFixed(1)}% margin
              </span>
            </div>
          </div>

          {/* Status Badge */}
          <div className="border rounded-xl p-3 bg-white flex items-center justify-center">
            {actualProfit > 0 ? (
              <Badge className="bg-green-100 text-green-700 border-green-200">
                <TrendingUp className="w-4 h-4 mr-1" />
                Profitable
              </Badge>
            ) : actualProfit < 0 ? (
              <Badge className="bg-red-100 text-red-700 border-red-200">
                <TrendingDown className="w-4 h-4 mr-1" />
                Loss Making
              </Badge>
            ) : (
              <Badge className="bg-gray-100 text-gray-700 border-gray-200">
                Break Even
              </Badge>
            )}
          </div>

          {/* Risk Alert */}
          {riskLow && quoteItems.length > 0 && (
            <div className="border rounded-xl p-3 bg-amber-50 text-amber-800 md:col-span-3">
              <div className="flex items-center gap-2 font-semibold mb-2">
                <AlertTriangle className="w-4 h-4" />
                Margin Risk Alert
              </div>
              <p className="text-sm">
                Forecast margin is {forecastMarginPct.toFixed(1)}% which is below your target of {targetPct}%.
                Consider adjusting scope, checking material costs or adding a staged payment.
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
