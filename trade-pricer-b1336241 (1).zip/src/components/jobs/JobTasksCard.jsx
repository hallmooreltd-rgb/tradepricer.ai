
import React, { useEffect, useMemo, useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea"; 
import { User } from "@/api/entities";
import { Task } from "@/api/entities";
import { Quote } from "@/api/entities";
import { Job } from "@/api/entities"; 
import { format, isValid, parseISO } from "date-fns";
import {
  Plus, Trash2, ArrowUp, ArrowDown, Calendar, Users as UsersIcon, Loader2, ListChecks,
  FilePlus, FileClock, Save, 
} from "lucide-react";

function safePrettyDate(s) {
  if (!s) return "";
  const d = parseISO(s);
  return isValid(d) ? format(d, "d MMM yyyy") : s;
}

function nameFor(team, id) {
  if (!id) return "";
  const u = team.find(x => x.id === id);
  return u?.full_name || u?.email || "User";
}

export default function JobTasksCard({ job, customer, variations }) { 
  const [me, setMe] = useState(null);
  const [team, setTeam] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [jobNotes, setJobNotes] = useState(""); 
  const [savingNotes, setSavingNotes] = useState(false); 
  const [newTitle, setNewTitle] = useState("");
  const [newAssignee, setNewAssignee] = useState("");
  const [newDue, setNewDue] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      setLoading(true);
      setErrorMsg("");
      try {
        const u = await User.me();
        if (!mounted) return;
        setMe(u);
        setJobNotes(job?.notes || "");
        
        const [teamData, tasksData] = await Promise.all([
          User.filter ? User.filter({ company_id: u.company_id, is_active: true }) : [u],
          Task.filter({ company_id: u.company_id, job_id: job.id }, "order_index", 200)
        ]);

        if (!mounted) return;
        setTeam(Array.isArray(teamData) ? teamData : []);
        setTasks(Array.isArray(tasksData) ? tasksData : []);
      } catch (e) {
        console.error(e);
        if (mounted) setErrorMsg("Could not load tasks.");
      } finally {
        if (mounted) setLoading(false);
      }
    };

    if (job?.id) {
      load();
    } else {
      setLoading(false);
    }
    return () => { mounted = false; };
  }, [job?.id, job?.notes]);

  const progress = useMemo(() => {
    const total = tasks.length;
    if (total === 0) return { total, done: 0, pct: 0 };
    const done = tasks.filter(t => t.status === "done").length;
    const pct = Math.round((done / total) * 100);
    return { total, done, pct };
  }, [tasks]);

  const saveNotes = async () => {
    if (!job?.id) return; // Cannot save if job is not defined
    setSavingNotes(true);
    try {
      await Job.update(job.id, { notes: jobNotes });
    } catch (e) {
      console.error("Failed to save job description:", e);
      setErrorMsg("Could not save description.");
    } finally {
      setSavingNotes(false);
    }
  };

  const addTask = async () => {
    if (!newTitle.trim()) return;
    setBusy(true);
    try {
      const payload = {
        company_id: me.company_id,
        job_id: job.id,
        title: newTitle.trim(),
        status: "open",
        order_index: tasks.length ? Math.max(...tasks.map(t => t.order_index || 0)) + 1 : 1,
      };
      if (newAssignee) payload.assigned_to_user_id = newAssignee;
      if (newDue) payload.due_date = newDue;
      
      const created = await Task.create(payload);
      setTasks(prev => [...prev, created].sort((a, b) => (a.order_index || 0) - (b.order_index || 0)));
      setNewTitle("");
      setNewAssignee("");
      setNewDue("");
    } catch (e) {
      console.error(e);
      setErrorMsg("Could not create task.");
    } finally {
      setBusy(false);
    }
  };

  const toggleTask = async (t) => {
    const nextStatus = t.status === "done" ? "open" : "done";
    const originalTasks = tasks;
    setTasks(prev => prev.map(x => x.id === t.id ? { ...x, status: nextStatus } : x));
    try {
      await Task.update(t.id, { status: nextStatus });
    } catch (e) {
      console.error("Failed to toggle task:", e);
      setTasks(originalTasks);
    }
  };

  const updateTask = async (id, patch) => {
    const originalTasks = tasks;
    setTasks(prev => prev.map(x => x.id === id ? { ...x, ...patch } : x));
    try {
      await Task.update(id, patch);
    } catch (e) {
      console.error("Failed to update task:", e);
      setTasks(originalTasks);
    }
  };

  const removeTask = async (id) => {
    const originalTasks = tasks;
    const keep = tasks.filter(t => t.id !== id);
    setTasks(keep);
    try { 
      await Task.delete(id); 
    } catch (e) {
      console.error("Failed to delete task:", e);
      setTasks(originalTasks);
    }
  };

  const move = async (idx, dir) => {
    const next = tasks.slice();
    const j = idx + dir;
    if (j < 0 || j >= next.length) return;
    
    const a = next[idx];
    const b = next[j];
    
    const ai = a.order_index || idx + 1;
    const bi = b.order_index || j + 1;
    
    a.order_index = bi;
    b.order_index = ai;
    
    [next[idx], next[j]] = [b, a];
    setTasks(next);
    
    try {
      await Promise.all([
        Task.update(a.id, { order_index: a.order_index }),
        Task.update(b.id, { order_index: b.order_index }),
      ]);
    } catch { 
      // Not critical to revert on UI
      console.warn("Failed to persist task order.");
    }
  };

  const importFromQuoteStages = async () => {
    if (!job?.quote_id) {
      alert("This job is not linked to a quote.");
      return;
    }
    setBusy(true);
    try {
      const quotes = await Quote.filter({ id: job.quote_id });
      const q = quotes?.[0];
      const stages = q?.stages_json ? JSON.parse(q.stages_json) : [];

      if (!stages.length) {
        alert("No stages found on the quote.");
        setBusy(false);
        return;
      }
      
      const baseIndex = tasks.length ? Math.max(...tasks.map(t => t.order_index || 0)) + 1 : 1;
      const created = [];
      const existingTitles = new Set(tasks.map(t => t.title)); // Prevent duplicate imports
      let newTasksCount = 0;

      for (let i = 0; i < stages.length; i++) {
        const s = stages[i];
        const title = s.label || `Stage ${i + 1}`;
        if (!existingTitles.has(title)) {
            const t = await Task.create({
                company_id: me.company_id,
                job_id: job.id,
                title: title,
                status: "open",
                order_index: baseIndex + newTasksCount,
            });
            created.push(t);
            newTasksCount++;
        }
      }

      if (created.length === 0) {
        alert("All quote stages have already been imported as tasks or no new stages to import.");
      } else {
        setTasks(prev => [...prev, ...created].sort((a, b) => (a.order_index || 0) - (b.order_index || 0)));
      }
    } catch (e) {
      console.error(e);
      setErrorMsg("Could not import stages.");
    } finally {
      setBusy(false);
    }
  };

  const importFromVariations = async () => {
    const approvedVariations = variations?.filter(v => v.status === 'approved') || [];
    if (!approvedVariations.length) {
      alert("No approved variations found for this job.");
      return;
    }
    setBusy(true);
    try {
      const baseIndex = tasks.length ? Math.max(...tasks.map(t => t.order_index || 0)) + 1 : 1;
      const created = [];
      const existingTitles = new Set(tasks.map(t => t.title));

      let newTasksCount = 0;
      for (const v of approvedVariations) {
         const variationItems = v.items_json ? JSON.parse(v.items_json) : [];
         for (const item of variationItems) {
             const title = item.description || `Variation ${v.variation_number} Item`; // Fallback title
             if (title.trim() && !existingTitles.has(title)) { // Ensure title is not empty and not a duplicate
                const t = await Task.create({
                    company_id: me.company_id,
                    job_id: job.id,
                    title: title,
                    status: "open",
                    order_index: baseIndex + newTasksCount,
                });
                created.push(t);
                existingTitles.add(title); // Add to set to prevent future duplicates in this import
                newTasksCount++;
             }
         }
      }
      
      if (created.length === 0) {
          alert("All approved variation items have already been imported as tasks or no new items to import.");
      } else {
          setTasks(prev => [...prev, ...created].sort((a, b) => (a.order_index || 0) - (b.order_index || 0)));
      }
    } catch (e) {
      console.error(e);
      setErrorMsg("Could not import tasks from variations.");
    } finally {
      setBusy(false);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ListChecks className="w-5 h-5" /> Job Scope & Tasks
          </CardTitle>
        </CardHeader>
        <CardContent className="text-gray-700 flex items-center gap-2 py-8">
          <Loader2 className="w-5 h-5 animate-spin" />
          Loading tasks...
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <CardTitle className="flex items-center gap-2">
            <ListChecks className="w-5 h-5" /> Job Scope & Tasks
          </CardTitle>
          {tasks.length > 0 && (
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <span className="text-sm text-gray-700 flex-shrink-0">
                {progress.done}/{progress.total} complete
              </span>
              <div className="w-full sm:w-40 h-2 bg-gray-200 rounded">
                <div
                  className="h-2 bg-green-600 rounded transition-all duration-300"
                  style={{ width: `${progress.pct}%` }}
                />
              </div>
            </div>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {errorMsg ? <p className="text-red-600">{errorMsg}</p> : null}

        <div className="space-y-2">
          <Label htmlFor="job-notes" className="font-semibold text-gray-800">Job Description / Scope of Work</Label>
          <Textarea
            id="job-notes"
            value={jobNotes}
            onChange={(e) => setJobNotes(e.target.value)}
            placeholder="Enter the main description of the job here..."
            rows={4}
            className="bg-white"
          />
          <div className="flex justify-end">
            <Button size="sm" onClick={saveNotes} disabled={savingNotes}>
              {savingNotes ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
              {savingNotes ? "Saving..." : "Save Description"}
            </Button>
          </div>
        </div>

        <div className="border-t pt-6"></div> {/* Added pt-6 for spacing after separator */}

        <div className="border rounded-lg p-4 bg-gray-50">
          <h4 className="font-semibold text-gray-800 mb-3">Sub-tasks checklist</h4>
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
              <div className="md:col-span-3">
                <Label htmlFor="new-task-title" className="text-xs font-medium text-gray-700">New Task</Label>
                <Input
                  id="new-task-title"
                  placeholder="e.g., Fix leaking tap in kitchen"
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  onKeyDown={e => e.key === "Enter" ? addTask() : null}
                  className="mt-1"
                />
              </div>
              <div className="md:col-span-3">
                <Label htmlFor="new-task-assignee" className="text-xs font-medium text-gray-700">Assign to</Label>
                <Select value={newAssignee} onValueChange={setNewAssignee}>
                  <SelectTrigger id="new-task-assignee" className="mt-1"><SelectValue placeholder="Select member" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>Unassigned</SelectItem>
                    {team.map(u => <SelectItem key={u.id} value={u.id}>{u.full_name || u.email}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="md:col-span-3">
                <Label htmlFor="new-task-due" className="text-xs font-medium text-gray-700">Due Date</Label>
                <Input id="new-task-due" type="date" value={newDue} onChange={e => setNewDue(e.target.value)} className="mt-1 w-full" />
              </div>
              <div className="md:col-span-3 flex justify-end">
                <Button onClick={addTask} disabled={busy || !newTitle.trim()} className="w-full">
                    <Plus className="w-4 h-4 mr-2" /> Add Task
                </Button>
              </div>
            </div>
        </div>

        <div className="space-y-2">
          {tasks.length === 0 ? <p className="text-gray-600 text-center py-4">No sub-tasks yet for this job.</p> : null}
          {tasks.map((t, idx) => (
            <div key={t.id} className="border rounded-lg p-3 bg-white hover:bg-gray-50 transition-colors">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
                <div className="md:col-span-5 flex items-center gap-3 min-w-0">
                  <Checkbox
                    id={`task-${t.id}`}
                    checked={t.status === "done"}
                    onCheckedChange={() => toggleTask(t)}
                    aria-label={t.title}
                  />
                  <Input
                    className={`flex-1 bg-transparent outline-none border-0 focus-visible:ring-0 min-w-0 ${t.status === "done" ? "line-through text-gray-500" : ""}`}
                    value={t.title}
                    onChange={e => updateTask(t.id, { title: e.target.value })}
                  />
                </div>

                <div className="md:col-span-2">
                  <Select
                    value={t.assigned_to_user_id || ""}
                    onValueChange={v => updateTask(t.id, { assigned_to_user_id: v || null })}
                  >
                    <SelectTrigger className="text-xs h-8"><SelectValue placeholder="Assign" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>Unassigned</SelectItem>
                      {team.map(u => <SelectItem key={u.id} value={u.id}>{u.full_name || u.email}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>

                <div className="md:col-span-3">
                  <Input
                    type="date"
                    className="text-xs h-8 w-full"
                    value={t.due_date || ""}
                    onChange={e => updateTask(t.id, { due_date: e.target.value || null })}
                  />
                </div>

                <div className="md:col-span-2 flex justify-end gap-1">
                  <Button variant="ghost" size="icon" onClick={() => move(idx, -1)} disabled={idx === 0} aria-label="Move up">
                    <ArrowUp className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => move(idx, 1)} disabled={idx === tasks.length - 1} aria-label="Move down">
                    <ArrowDown className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => removeTask(t.id)} aria-label="Remove">
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-end pt-2 gap-2 flex-wrap">
          {job?.quote_id && (
            <Button variant="secondary" onClick={importFromQuoteStages} disabled={busy}>
              <FileClock className="w-4 h-4 mr-2" />
              Import from quote stages
            </Button>
          )}
          {variations && variations.some(v => v.status === 'approved') && (
            <Button variant="secondary" onClick={importFromVariations} disabled={busy}>
              <FilePlus className="w-4 h-4 mr-2" />
              Import from variations
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
