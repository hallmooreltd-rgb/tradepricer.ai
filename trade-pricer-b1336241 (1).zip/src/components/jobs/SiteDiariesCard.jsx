import React, { useState, useEffect } from "react";
import { SiteDiary } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Plus, Calendar, FileText } from "lucide-react";
import { format } from "date-fns";
import WeatherBadge from "../diary/WeatherBadge";

export default function SiteDiariesCard({ job }) {
  const [diaries, setDiaries] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (job?.id) {
      loadDiaries();
    }
  }, [job]);

  const loadDiaries = async () => {
    try {
      const diaryData = await SiteDiary.filter({ job_id: job.id }, "-date", 5);
      setDiaries(diaryData || []);
    } catch (error) {
      console.error("Error loading site diaries:", error);
    }
    setLoading(false);
  };

  const getTotalHours = (labour) => {
    if (!labour || !Array.isArray(labour)) return 0;
    return labour.reduce((sum, worker) => sum + (Number(worker.hours) || 0), 0);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          Site Diaries
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-600">
              Daily progress logs with weather and labour tracking
            </p>
            <Link to={createPageUrl(`NewDiary?job_id=${job.id}`)}>
              <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                New Diary
              </Button>
            </Link>
          </div>

          {loading ? (
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="h-16 bg-gray-200 rounded"></div>
                </div>
              ))}
            </div>
          ) : diaries.length > 0 ? (
            <div className="space-y-3">
              {diaries.map((diary) => (
                <Link 
                  key={diary.id} 
                  to={createPageUrl(`DiaryDetail?id=${diary.id}`)}
                  className="block"
                >
                  <div className="p-3 border rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm">
                            {format(new Date(diary.date), "MMM d, yyyy")}
                          </span>
                          {diary.weather && diary.weather.summary && (
                            <WeatherBadge weather={diary.weather} />
                          )}
                        </div>
                        
                        <div className="flex items-center gap-4 text-xs text-gray-600">
                          {diary.labour && diary.labour.length > 0 && (
                            <span>
                              {diary.labour.length} workers • {getTotalHours(diary.labour)}h
                            </span>
                          )}
                          {diary.postcode && (
                            <span>{diary.postcode}</span>
                          )}
                        </div>
                        
                        {diary.notes && (
                          <p className="text-xs text-gray-600 mt-1 line-clamp-1">
                            {diary.notes}
                          </p>
                        )}
                      </div>
                      
                      <FileText className="w-4 h-4 text-gray-400 mt-1" />
                    </div>
                  </div>
                </Link>
              ))}
              
              {diaries.length >= 5 && (
                <Link to={createPageUrl(`Diaries?job_id=${job.id}`)}>
                  <Button variant="outline" size="sm" className="w-full">
                    View All Diaries for This Job
                  </Button>
                </Link>
              )}
            </div>
          ) : (
            <div className="text-center py-8">
              <Calendar className="w-8 h-8 text-gray-300 mx-auto mb-3" />
              <h3 className="font-medium text-gray-900 mb-2">No diaries yet</h3>
              <p className="text-sm text-gray-500 mb-4">
                Start tracking daily progress, weather conditions, and labour hours.
              </p>
              <Link to={createPageUrl(`NewDiary?job_id=${job.id}`)}>
                <Button size="sm">
                  <Plus className="w-4 h-4 mr-2" />
                  Create First Diary
                </Button>
              </Link>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}