
import React, { useEffect, useMemo, useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Quote } from "@/api/entities";
import { Payment } from "@/api/entities";
import { User } from "@/api/entities";
import { format } from "date-fns";
import { CreditCard, CheckCircle } from "lucide-react";

export default function StagePaymentsCard({ job }) {
  const [me, setMe] = useState(null);
  const [quote, setQuote] = useState(null);
  const [payments, setPayments] = useState([]);
  const [savingId, setSavingId] = useState(null);

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      try {
        const u = await User.me();
        if (!mounted) return;
        setMe(u);
        
        if (job?.quote_id && Quote.get) {
          const q = await Quote.get(job.quote_id);
          if (!mounted) return;
          setQuote(q);
        }
        
        const pay = Payment.filter ? await Payment.filter({ company_id: u.company_id, job_id: job.id }, "-received_at", 500) : [];
        if (mounted) setPayments(pay || []);
      } catch (error) {
        console.error("Error loading stage payments:", error);
      }
    };
    load();
    return () => { mounted = false; };
  }, [job?.id, job?.quote_id]);

  const totalIncVat = Number(quote?.total || 0);

  const rows = useMemo(() => {
    if (!quote?.stages_json) return [];
    
    let stages = [];
    try {
      stages = JSON.parse(quote.stages_json);
    } catch {
      return [];
    }

    if (!Array.isArray(stages)) return [];

    return stages.map((s, idx) => {
      const amount = s.type === "percent" ? (totalIncVat * Number(s.value || 0)) / 100 : Number(s.value || 0);
      const paid = payments.find(p => p.source === "stage" && p.ref === s.label);
      return { 
        idx, 
        label: s.label, 
        amount, 
        due: s.due,
        paid_at: s.paid_at || paid?.received_at || null 
      };
    });
  }, [quote, payments, totalIncVat]);

  const gbp = (n) => new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

  const markPaid = async (row) => {
    if (!me || !quote) return;
    setSavingId(row.label);
    try {
      // 1) create payment
      const pay = await Payment.create({
        company_id: me.company_id,
        job_id: job.id,
        source: "stage",
        amount_gbp: Number(row.amount.toFixed(2)),
        received_at: format(new Date(), "yyyy-MM-dd"),
        ref: row.label,
        notes: `Stage paid from job card`,
      });
      setPayments(prev => [pay, ...prev]);

      // 2) stamp paid_at on the quote stage
      const stages = quote.stages_json ? JSON.parse(quote.stages_json) : [];
      stages[row.idx] = { ...stages[row.idx], paid_at: new Date().toISOString() };
      const updated = await Quote.update(quote.id, { stages_json: JSON.stringify(stages) });
      setQuote(updated);
    } catch (error) {
      console.error("Error marking stage as paid:", error);
    } finally {
      setSavingId(null);
    }
  };

  if (!quote?.stages_json || rows.length === 0) return null;

  const totalPaid = rows.filter(r => r.paid_at).reduce((acc, r) => acc + r.amount, 0);
  const totalDue = rows.reduce((acc, r) => acc + r.amount, 0);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="w-5 h-5" />
          Stage Payments
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="text-center p-3 bg-green-50 rounded-lg">
            <div className="text-lg font-bold text-green-700">{gbp(totalPaid)}</div>
            <div className="text-sm text-green-600">Received</div>
          </div>
          <div className="text-center p-3 bg-blue-50 rounded-lg">
            <div className="text-lg font-bold text-blue-700">{gbp(totalDue - totalPaid)}</div>
            <div className="text-sm text-blue-600">Outstanding</div>
          </div>
        </div>

        <div className="space-y-2">
          {rows.map((r) => (
            <div key={r.idx} className="border rounded-xl p-4 bg-white flex items-center justify-between">
              <div>
                <div className="font-medium">{r.label}</div>
                <div className="text-sm text-gray-600">
                  {gbp(r.amount)} · Due {r.due.replace('_', ' ')}
                  {r.paid_at && (
                    <span className="text-green-600 ml-2">
                      · Paid {format(new Date(r.paid_at), "d MMM yyyy")}
                    </span>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2">
                {r.paid_at ? (
                  <CheckCircle className="w-5 h-5 text-green-600" />
                ) : (
                  <Button 
                    size="sm" 
                    onClick={() => markPaid(r)} 
                    disabled={savingId === r.label}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    {savingId === r.label ? "Saving..." : "Mark Paid"}
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
