import React, { useEffect, useMemo, useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Timesheet } from "@/api/entities";
import { User } from "@/api/entities";
import { format } from "date-fns";
import { Loader2, Plus, Trash2 } from "lucide-react";

function nameFor(team, id) {
  const u = team.find(x => x.id === id);
  return u?.full_name || u?.email || "User";
}

export default function TimesheetsCard({ job }) {
  const [me, setMe] = useState(null);
  const [team, setTeam] = useState([]);
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);

  // new entry
  const [userId, setUserId] = useState("");
  const [date, setDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [hours, setHours] = useState(8);
  const [rate, setRate] = useState(25);
  const [notes, setNotes] = useState("");

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      try {
        const u = await User.me();
        if (!mounted) return;
        setMe(u);
        const t = User.filter ? await User.filter({ company_id: u.company_id, is_active: true }) : [u];
        if (!mounted) return;
        setTeam(t || []);
        const ts = await Timesheet.filter({ company_id: u.company_id, job_id: job.id }, "-created_at", 200);
        if (!mounted) return;
        setRows(ts || []);
        // default to me
        setUserId(u.id);
        setRate(Number(u.hourly_rate || 25));
      } finally {
        if (mounted) setLoading(false);
      }
    };
    if (job?.id) load();
    return () => { mounted = false; };
  }, [job?.id]);

  const totalHours = useMemo(() => rows.reduce((a, r) => a + Number(r.hours || 0), 0), [rows]);
  const labourCost = useMemo(
    () => rows.reduce((a, r) => a + Number(r.hours || 0) * Number(r.hourly_rate || 0), 0),
    [rows]
  );

  const addRow = async () => {
    if (!userId || !hours) return;
    const payload = {
      company_id: me.company_id,
      job_id: job.id,
      user_id: userId,
      hours: Number(hours),
      hourly_rate: Number(rate),
      notes: notes?.trim(),
      start_at: date ? new Date(date + "T08:00:00").toISOString() : undefined,
      end_at: date ? new Date(date + "T16:00:00").toISOString() : undefined,
    };
    const created = await Timesheet.create(payload);
    setRows(prev => [created, ...prev]);
    setNotes("");
  };

  const remove = async (id) => {
    setRows(prev => prev.filter(r => r.id !== id));
    try { await Timesheet.delete(id); } catch {}
  };

  if (loading) {
    return (
      <Card>
        <CardHeader><CardTitle>Labour</CardTitle></CardHeader>
        <CardContent className="flex items-center gap-2 text-gray-700 py-8">
          <Loader2 className="w-5 h-5 animate-spin" /> Loading…
        </CardContent>
      </Card>
    );
  }

  const gbp = (n) => new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Labour timesheets</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-8 gap-3 items-end">
          <div className="md:col-span-2">
            <Label>Engineer</Label>
            <Select value={userId} onValueChange={setUserId}>
              <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
              <SelectContent>
                {team.map(u => <SelectItem key={u.id} value={u.id}>{u.full_name || u.email}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Date</Label>
            <Input type="date" value={date} onChange={e => setDate(e.target.value)} />
          </div>
          <div>
            <Label>Hours</Label>
            <Input type="number" inputMode="decimal" value={hours} onChange={e => setHours(Number(e.target.value))} />
          </div>
          <div>
            <Label>Rate £/h</Label>
            <Input type="number" inputMode="decimal" value={rate} onChange={e => setRate(Number(e.target.value))} />
          </div>
          <div className="md:col-span-2">
            <Label>Notes</Label>
            <Input value={notes} onChange={e => setNotes(e.target.value)} placeholder="Optional" />
          </div>
          <div className="flex justify-end">
            <Button onClick={addRow}><Plus className="w-4 h-4 mr-2" /> Add</Button>
          </div>
        </div>

        <div className="space-y-2">
          {rows.length === 0 ? <p className="text-gray-600">No entries yet.</p> : null}
          {rows.map(r => (
            <div key={r.id} className="border rounded-xl p-3 bg-white flex items-center justify-between">
              <div>
                <div className="font-medium">{nameFor(team, r.user_id)} · {Number(r.hours)} h at £{Number(r.hourly_rate || 0).toFixed(2)}</div>
                <div className="text-xs text-gray-600">
                  {r.start_at ? format(new Date(r.start_at), "d MMM yyyy") : ""} {r.notes ? " · " + r.notes : ""}
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-sm font-medium">{gbp((r.hours || 0) * (r.hourly_rate || 0))}</div>
                <Button variant="outline" size="icon" onClick={() => remove(r.id)} aria-label="Remove">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-3 border rounded-xl p-3 bg-gray-50">
          <div className="text-sm text-gray-600">Total hours</div>
          <div className="text-right font-medium">{totalHours}</div>
          <div className="text-sm text-gray-600">Labour cost (ex VAT)</div>
          <div className="text-right font-medium">{gbp(labourCost)}</div>
        </div>
      </CardContent>
    </Card>
  );
}