import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Variation } from '@/api/entities';
import { Plus, Loader2 } from 'lucide-react';
import { format } from 'date-fns';

const statusColors = {
  draft: "bg-gray-100 text-gray-700",
  sent: "bg-blue-100 text-blue-700",
  approved: "bg-green-100 text-green-700",
  rejected: "bg-red-100 text-red-700",
};

export default function VariationsCard({ job, variations: propVariations }) {
  const navigate = useNavigate();
  const [variations, setVariations] = useState(propVariations || []);
  const [loading, setLoading] = useState(!propVariations);

  useEffect(() => {
    if (!propVariations) {
      const fetchVariations = async () => {
        setLoading(true);
        try {
          const vars = await Variation.filter({ job_id: job.id }, "-created_date");
          setVariations(vars || []);
        } catch (error) {
          console.error("Error loading variations:", error);
        } finally {
          setLoading(false);
        }
      };
      fetchVariations();
    } else {
      setVariations(propVariations);
      setLoading(false);
    }
  }, [job.id, propVariations]);

  const gbp = (n) => new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Variations</CardTitle>
        <Button size="sm" onClick={() => navigate(createPageUrl(`NewVariation?job_id=${job.id}`))}>
          <Plus className="w-4 h-4 mr-2" /> New Variation
        </Button>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex justify-center p-4">
            <Loader2 className="w-4 h-4 animate-spin" />
          </div>
        ) : (
          <div className="space-y-3">
            {variations.length === 0 ? (
              <p className="text-sm text-gray-500">No variations for this job yet.</p>
            ) : (
              variations.map(v => (
                <div key={v.id} className="border rounded-lg p-3 flex justify-between items-center">
                  <div>
                    <Link to={createPageUrl(`VariationDetail?id=${v.id}`)} className="font-semibold text-blue-600 hover:underline">
                      {v.variation_number}
                    </Link>
                    <p className="text-sm text-gray-500">Issued: {format(new Date(v.issue_date), 'd MMM yyyy')}</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="font-semibold">{gbp(v.total)}</span>
                    <Badge className={statusColors[v.status] || statusColors.draft}>{v.status}</Badge>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}