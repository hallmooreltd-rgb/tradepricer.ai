export function drawWatermarkIfNeeded(doc, company) {
  const show = (company?.plan_tier || "free") === "free";
  if (!show) return;
  const text = "Created with CertiFlow Pro";
  doc.setTextColor(180);
  doc.setFontSize(36);
  doc.saveGraphicsState();
  // centre across the page
  doc.rotate(-30, { origin: [105, 148] });
  doc.text(text, 30, 160);
  doc.restoreGraphicsState();
  doc.setTextColor(0);
}