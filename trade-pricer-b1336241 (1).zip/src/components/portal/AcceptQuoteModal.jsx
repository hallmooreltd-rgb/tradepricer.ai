import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import SignaturePad from "../certificates/SignaturePad";
import { UploadFile } from "@/api/integrations";
import { X } from "lucide-react";

export default function AcceptQuoteModal({
  open,
  onClose,
  quote,
  onAccepted,
}) {
  const [name, setName] = useState("");
  const [sig, setSig] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  if (!open) return null;

  const handleUpload = async (blob) => {
    try {
      const timestamp = Date.now();
      const file = new File([blob], `quote-signature-${timestamp}.png`, {
        type: 'image/png',
        lastModified: timestamp
      });
      const { file_url } = await UploadFile({ file });
      return file_url;
    } catch (error) {
      console.error("Error uploading signature:", error);
      throw error;
    }
  };

  const submit = async () => {
    setErr("");
    if (!name.trim()) { setErr("Please enter your name."); return; }
    if (!sig) { setErr("Please add your signature."); return; }
    setBusy(true);
    try {
      await onAccepted({ signature_url: sig, signer_name: name });
      onClose();
    } catch (e) {
      console.error(e);
      setErr("Could not accept the quote. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  const gbp = (n) => new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-xl">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-semibold">Accept quote {quote?.quote_number}</h2>
          <button className="p-2" onClick={onClose} aria-label="Close">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-6 space-y-4">
          {err ? <p className="text-red-600">{err}</p> : null}
          
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex justify-between items-center">
              <span className="font-medium">Quote total:</span>
              <span className="text-xl font-bold text-blue-700">{gbp(quote?.total)}</span>
            </div>
            {quote?.deposit_due > 0 && (
              <div className="flex justify-between items-center mt-2 text-sm">
                <span>Deposit due on acceptance:</span>
                <span className="font-medium">{gbp(quote.deposit_due)}</span>
              </div>
            )}
          </div>

          <div>
            <Label>Your full name</Label>
            <Input 
              value={name} 
              onChange={e => setName(e.target.value)} 
              placeholder="Enter your full name"
            />
          </div>
          
          <div>
            <SignaturePad 
              label="Digital signature" 
              onSignatureChange={setSig}
              upload={handleUpload}
              height={150}
            />
          </div>
          
          <div className="bg-gray-50 border rounded-lg p-4 text-sm">
            <p className="text-gray-700">
              By signing and accepting this quote, you agree to the terms and conditions outlined in the quotation. 
              {quote?.deposit_due > 0 && " You will be redirected to pay the deposit after acceptance."}
            </p>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={submit} disabled={busy} className="bg-blue-600 hover:bg-blue-700">
              {busy ? "Processing..." : "Accept & Sign"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}