
import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Send } from "lucide-react";
import { format, isValid, parseISO } from "date-fns";
import { Lead } from "@/api/entities";
import { SendEmail } from "@/api/integrations";

const SERVICE_OPTIONS = [
  { value: "boiler_service", label: "Boiler service" },
  { value: "electrical_inspection", label: "Electrical inspection" },
  { value: "roof_inspection", label: "Roofing inspection" },
  { value: "damp_followup", label: "Damp follow up" },
  { value: "other", label: "Other" },
];

function labelFor(v) {
  const found = SERVICE_OPTIONS.find(o => o.value === v);
  return found ? found.label : "Service";
}

export default function BookingRequestModal({ open, onClose, company, customer, portalToken, preset = {} }) {
  const [serviceType, setServiceType] = useState(preset?.service_type || "boiler_service");
  const [preferredDate, setPreferredDate] = useState(preset?.preferred_date || format(new Date(), "yyyy-MM-dd"));
  const [timeWindow, setTimeWindow] = useState("Any");
  const [notes, setNotes] = useState("");
  const [contactEmail, setContactEmail] = useState(customer?.email || "");
  const [contactPhone, setContactPhone] = useState(customer?.phone || "");
  const [saving, setSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!open) return;
    // reset on open
    setServiceType(preset?.service_type || "boiler_service");
    setPreferredDate(preset?.preferred_date || format(new Date(), "yyyy-MM-dd"));
    setTimeWindow("Any");
    setNotes("");
    setContactEmail(customer?.email || "");
    setContactPhone(customer?.phone || "");
    setSaving(false);
    setErrorMsg("");
    setDone(false);
  }, [open, preset, customer]);

  if (!open) return null;

  const validate = () => {
    const errs = [];
    if (!serviceType) errs.push("Please choose a service type.");
    if (preferredDate) {
      const d = parseISO(preferredDate);
      if (!isValid(d)) errs.push("Preferred date is not valid.");
    }
    if (!contactEmail && !contactPhone) errs.push("Provide at least one contact method.");
    return errs;
  };

  const submit = async () => {
    setErrorMsg("");
    const errs = validate();
    if (errs.length) {
      setErrorMsg(errs.join("\n"));
      return;
    }
    setSaving(true);
    try {
      const payload = {
        company_id: company.id,
        customer_id: customer.id,
        source: "customer_portal",
        title: labelFor(serviceType) + " request",
        service_type: serviceType,
        preferred_date: preferredDate,
        time_window: timeWindow,
        notes,
        contact_email: contactEmail,
        contact_phone: contactPhone,
        portal_token: portalToken,
        status: "new",
      };
      const created = await Lead.create(payload);

      // Notify office - this would need to be implemented on your backend
      try {
        await fetch("/api/notify/booking-request", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ company, customer, lead: created }),
        });
      } catch {
        // non critical
      }

      setDone(true);
    } catch (e) {
      console.error(e);
      setErrorMsg("Could not send your request. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-xl">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-semibold">{done ? "Request sent" : "Request a booking"}</h2>
          <button className="p-2" onClick={onClose} aria-label="Close"><X className="w-5 h-5" /></button>
        </div>

        {!done ? (
          <div className="p-4">
            {errorMsg ? <p className="text-red-600 mb-3 whitespace-pre-line">{errorMsg}</p> : null}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Service type</Label>
                <Select value={serviceType} onValueChange={setServiceType}>
                  <SelectTrigger><SelectValue placeholder="Choose service" /></SelectTrigger>
                  <SelectContent>
                    {SERVICE_OPTIONS.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Preferred date</Label>
                <Input type="date" value={preferredDate} onChange={e => setPreferredDate(e.target.value)} />
              </div>
              <div>
                <Label>Preferred time</Label>
                <Select value={timeWindow} onValueChange={setTimeWindow}>
                  <SelectTrigger><SelectValue placeholder="Any" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Any">Any</SelectItem>
                    <SelectItem value="AM">AM</SelectItem>
                    <SelectItem value="PM">PM</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Contact email</Label>
                <Input type="email" value={contactEmail} onChange={e => setContactEmail(e.target.value)} placeholder="Optional" />
              </div>
              <div>
                <Label>Contact phone</Label>
                <Input value={contactPhone} onChange={e => setContactPhone(e.target.value)} placeholder="Optional" />
              </div>
              <div className="md:col-span-2">
                <Label>Notes</Label>
                <Textarea rows={4} value={notes} onChange={e => setNotes(e.target.value)} placeholder="Tell us about access, parking, preferred time or any issues" />
              </div>
            </div>

            <div className="flex justify-end gap-2 mt-5">
              <Button variant="outline" onClick={onClose}>Cancel</Button>
              <Button onClick={submit} disabled={saving} className="bg-blue-600 hover:bg-blue-700">
                {saving ? "Sending..." : <>Send request <Send className="w-4 h-4 ml-2" /></>}
              </Button>
            </div>
          </div>
        ) : (
          <div className="p-6">
            <p className="text-gray-800">Thanks. Your request has been sent to {company?.name || "the office"}. We will contact you to confirm a time.</p>
            <div className="flex justify-end mt-4">
              <Button onClick={onClose}>Close</Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
