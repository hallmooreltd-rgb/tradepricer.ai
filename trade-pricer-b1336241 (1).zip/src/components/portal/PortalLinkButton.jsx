
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Copy, RefreshCw } from "lucide-react";
import { Customer } from "@/api/entities";
import { randomToken, buildPortalUrl, defaultExpiryYears } from "./portalUtils";

export default function PortalLinkButton({ customer }) {
  const [busy, setBusy] = useState(false);
  const [url, setUrl] = useState(customer?.portal_token ? buildPortalUrl(customer.portal_token) : null);

  const ensureLink = async (rotate = false) => {
    setBusy(true);
    try {
      let token = customer.portal_token;
      if (!token || rotate) token = randomToken(48);
      const payload = {
        portal_token: token,
        portal_token_expires: customer.portal_token_expires || defaultExpiryYears(3),
      };
      const updated = await Customer.update(customer.id, payload);
      const portalUrl = buildPortalUrl(updated.portal_token);
      setUrl(portalUrl);
      await navigator.clipboard.writeText(portalUrl);
      alert(rotate ? "New portal link created and copied." : "Portal link copied.");
    } catch (e) {
      console.error(e);
      alert("Could not create portal link.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex gap-2">
      <Button type="button" onClick={() => ensureLink(false)} disabled={busy}>
        <Copy className="w-4 h-4 mr-2" /> Copy portal link
      </Button>
      <Button type="button" variant="outline" onClick={() => ensureLink(true)} disabled={busy}>
        <RefreshCw className="w-4 h-4 mr-2" /> Rotate link
      </Button>
      {url ? <a href={url} target="_blank" rel="noreferrer" className="text-sm text-blue-700 underline">Open</a> : null}
    </div>
  );
}
