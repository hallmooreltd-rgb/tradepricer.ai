import jsPDF from "jspdf";
import QRCode from "qrcode";
import { buildPortalUrl } from "./portalUtils";

export async function buildPortalStickers({ company, customer }) {
  if (!customer?.portal_token) throw new Error("Customer has no portal token");
  const url = buildPortalUrl(customer.portal_token);
  const qr = await QRCode.toDataURL(url, { margin: 0 });

  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const labelW = 63.5;
  const labelH = 38.1;
  const cols = 3;
  const rows = 7;
  const leftMargin = 5;  // tweak to your label sheet
  const topMargin = 12;

  let y = topMargin;
  for (let r = 0; r < rows; r++) {
    let x = leftMargin;
    for (let c = 0; c < cols; c++) {
      // Border for debug: doc.rect(x, y, labelW, labelH);
      doc.addImage(qr, "PNG", x + 2, y + 2, 20, 20);
      doc.setFontSize(10);
      const name = company?.name || "Your contractor";
      doc.text(name, x + 24, y + 8);
      doc.setFontSize(8);
      doc.text("Scan for documents and booking", x + 24, y + 14);
      if (company?.phone) doc.text(`Tel ${company.phone}`, x + 24, y + 20);
      // hide long URL on stickers or shorten if you have a short domain
      x += labelW;
    }
    y += labelH;
  }
  return doc.output("blob");
}