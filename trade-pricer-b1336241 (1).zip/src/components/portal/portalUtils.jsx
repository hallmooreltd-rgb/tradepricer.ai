import { format, addYears } from "date-fns";

export function randomToken(len = 48) {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let out = "";
  for (let i = 0; i < len; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

export function buildPortalUrl(token) {
  // Works for prod and dev. Change if your public site lives elsewhere.
  const base = window.location.origin;
  return `${base}/portal/${token}`;
}

export function defaultExpiryYears(years = 3) {
  return format(addYears(new Date(), years), "yyyy-MM-dd");
}