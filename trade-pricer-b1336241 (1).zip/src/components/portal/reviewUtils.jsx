
import { addDays, format, isBefore } from "date-fns";
import { Company } from "@/api/entities";
import { Reminder } from "@/api/entities";
import { SendEmail } from "@/api/integrations";

const REVIEW_PLATFORMS = []; // Content not provided in the outline, initializing as empty array to ensure valid syntax.

export async function sendReviewBooster({
  company,
  customer,
  job,
}) {
  const url = company?.google_review_url || company?.checkatrade_url || company?.trustpilot_url;

  if (!url) return; // nothing to send

  try {
    await fetch("/api/notify/review-booster", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ company, customer, job, review_url: url }),
    });
  } catch (e) {
    console.warn("Review email failed", e);
  }

  // Optional follow up in 7 days
  try {
    await Reminder.create({
      company_id: company.id,
      job_id: job.id,
      customer_id: customer.id,
      reminder_type: "review_followup",
      due_date: format(addDays(new Date(), 7), "yyyy-MM-dd"),
      channel: "email",
      message_template_key: "review_followup",
      status: "scheduled",
    });
  } catch (e) {
    console.warn("Failed to create review follow-up reminder:", e);
  }
}

/** Convenience check you can call after payments or on job completion */
export async function maybeSendReviewOnComplete({
  company,
  customer,
  job,
  stages = [],
}) {
  const allPaid = Array.isArray(stages) && stages.length > 0
    ? stages.every(s => s.paid_at || s.status === "paid")
    : false;

  if (job.status === "completed" || allPaid) {
    await sendReviewBooster({ company, customer, job });
  }
}
