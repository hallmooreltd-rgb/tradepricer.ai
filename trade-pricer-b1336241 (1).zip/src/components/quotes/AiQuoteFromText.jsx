import React, { useState } from 'react';
import { InvokeLLM } from '@/api/integrations';
import { PriceItem } from '@/api/entities'; // This import is still valid for typing if PriceItem is used elsewhere, though not directly in this component's new LLM output.
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Loader2, Type, Sparkles, Globe } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { loadCompanyRoleRates, generateStaffRateSnippet } from "../utils/labourRates";

export default function AiQuoteFromText({ onQuoteGenerated, onError }) { // Changed onComplete to onQuoteGenerated, kept onError, removed company
    const [description, setDescription] = useState(''); // Renamed text to description
    const [saving, setSaving] = useState(false); // Renamed loading to saving

    const generateQuote = async () => { // Renamed handleGenerate to generateQuote
        if (!description.trim()) {
            onError("Please enter a description of the job first.");
            return;
        }

        setSaving(true);
        try {
            // Load company staff rates
            const roleRates = await loadCompanyRoleRates();
            const staffRateSnippet = generateStaffRateSnippet(roleRates);

            // New prompt and schema to get items and scope_of_work in a single LLM call
            const result = await InvokeLLM({
                prompt: `You are TradePricer's AI estimator. Create a detailed, professional quote for the following job description.

COMPANY LABOUR RATES:
${staffRateSnippet}

JOB DESCRIPTION:
${description}

Requirements:
1. Break down into clear line items (labour, materials, equipment)
2. Use the company labour rates provided above when possible
3. For materials, research current UK trade prices
4. Include realistic quantities and units
5. All prices should be excluding VAT
6. Add appropriate markup on materials (typically 15-25%)
7. Consider location and access factors
8. Include contingency if needed

Provide a professional scope of work and realistic pricing.`,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        scope_of_work: {
                            type: "string",
                            description: "A detailed, professional summary of the job to be performed."
                        },
                        items: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    description: { type: "string" },
                                    quantity: { type: "number" },
                                    unit: { type: "string" },
                                    unit_price: { type: "number" },
                                    category: { type: "string", enum: ["labour", "materials", "equipment", "other"] },
                                    vat_rate: { type: "number", default: 20 },
                                    notes: { type: "string" }
                                },
                                required: ["description", "quantity", "unit_price", "category", "vat_rate"]
                            }
                        },
                        notes: { type: "string" },
                        estimated_duration_days: { type: "number" }
                    },
                    required: ["scope_of_work", "items"]
                }
            });

            if (onQuoteGenerated) {
                // Pass the entire result object as per the new structure
                onQuoteGenerated(result);
            }

        } catch (err) {
            console.error("AI Generation failed:", err);
            onError(err.message || "Failed to generate quote from text.");
        } finally {
            setSaving(false);
        }
    };

    return (
        <Card>
            <CardContent className="p-6">
                <div className="space-y-4">
                    <div className="text-center">
                        <div className="w-16 h-16 mx-auto bg-green-100 rounded-full flex items-center justify-center mb-4">
                            <Type className="w-8 h-8 text-green-600" />
                        </div>
                        <h3 className="text-lg font-semibold mb-2">Describe Your Job</h3>
                        <p className="text-sm text-gray-600 mb-4">
                            Describe the work needed and I'll suggest materials, quantities, and current UK pricing.
                        </p>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="job-description">Job Description</Label>
                        <Textarea
                            id="job-description"
                            rows={8}
                            value={description} // Changed to description
                            onChange={(e) => setDescription(e.target.value)} // Changed to setDescription
                            placeholder="Example: Install a new combi boiler in a 3-bedroom house. Remove old conventional boiler and tank. Run new gas line from meter. Install new thermostat and radiator valves. Power flush system. Customer wants Worcester Bosch boiler..."
                            disabled={saving} // Changed to saving
                        />
                        <p className="text-xs text-gray-500">
                            💡 Be as detailed as possible. Include room sizes, specific brands, existing installations, access issues, etc.
                        </p>
                    </div>

                    <Button
                        onClick={generateQuote} // Changed to generateQuote
                        disabled={saving || !description.trim()} // Changed to saving and description.trim()
                        className="w-full bg-green-600 hover:bg-green-700"
                    >
                        {saving ? ( // Changed to saving
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Analyzing...
                            </>
                        ) : (
                            <>
                                <Sparkles className="w-4 h-4 mr-2" />
                                Generate Quote from Description
                            </>
                        )}
                    </Button>

                    <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                        <div className="flex items-start gap-2">
                            <Globe className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                            <div className="text-sm text-green-800">
                                <p className="font-medium mb-1">AI-Powered Pricing</p>
                                <p>I'll search current UK trade suppliers and industry standards to provide realistic pricing for your quote.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}