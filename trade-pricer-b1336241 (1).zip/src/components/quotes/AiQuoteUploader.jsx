
import React, { useState } from 'react';
import { UploadFile, ExtractDataFromUploadedFile, InvokeLLM } from '@/api/integrations';
import { PriceItem } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Loader2, UploadCloud, FileText, Sparkles, Globe, User } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const EXTRACTION_SCHEMA = {
    type: "object",
    properties: {
        customer_info: {
            type: "object",
            properties: {
                name: { type: "string", description: "Customer full name if mentioned" },
                address: { type: "string", description: "Complete customer address if mentioned" },
                phone: { type: "string", description: "Phone number if mentioned" },
                email: { type: "string", description: "Email address if mentioned" }
            }
        },
        scope_of_work: {
            type: "string",
            description: "A detailed, professional summary of the job to be performed, written from the perspective of the tradesperson or company providing the quote. This should clearly outline what will be done."
        },
        items: {
            type: "array",
            items: {
                type: "object",
                properties: {
                    description: { type: "string", description: "Detailed description of the material or labor item" },
                    quantity: { type: "number", description: "The quantity of the item" },
                    unit: { type: "string", description: "The unit of measurement (e.g., 'm', 'item', 'hour', 'kg')" },
                    specifications: { type: "string", description: "Any technical specifications, dimensions, or brand requirements" }
                },
                required: ["description", "quantity", "unit"]
            }
        },
        project_type: { type: "string", description: "Type of project (e.g., 'boiler installation', 'electrical work', 'plumbing')" },
        location: { type: "string", description: "Project location or area if mentioned" }
    },
    required: ["items", "scope_of_work"]
};

export default function AiQuoteUploader({ onComplete, onError, companyId }) {
    const [file, setFile] = useState(null);
    const [loading, setLoading] = useState(false);
    const [status, setStatus] = useState("Ready to upload PDF drawing or specification");
    const [extractedData, setExtractedData] = useState(null);

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
        setExtractedData(null);
    };

    const findRealWorldPricing = async (items) => {
        const pricedItems = [];
        
        for (const item of items) {
            try {
                const pricingPrompt = `Find current UK trade prices for: ${item.description}
                Quantity: ${item.quantity} ${item.unit}
                ${item.specifications ? `Specifications: ${item.specifications}` : ''}
                
                I need:
                - Typical trade price per ${item.unit} (excluding VAT)
                - Brief explanation of the pricing
                - Any relevant supplier information
                
                Focus on realistic UK trade prices from suppliers like Screwfix, Toolstation, Travis Perkins, or similar.`;

                const pricingResult = await InvokeLLM({
                    prompt: pricingPrompt,
                    add_context_from_internet: true,
                    response_json_schema: {
                        type: "object",
                        properties: {
                            unit_price_ex_vat: { type: "number", description: "Price per unit excluding VAT" },
                            total_price_ex_vat: { type: "number", description: "Total price for this line item excluding VAT" },
                            vat_rate: { type: "number", description: "VAT rate (usually 20)" },
                            pricing_notes: { type: "string", description: "Brief explanation of pricing source" },
                            supplier_suggestion: { type: "string", description: "Suggested supplier name" }
                        }
                    }
                });

                pricedItems.push({
                    description: item.description,
                    quantity: item.quantity,
                    unit: item.unit,
                    unit_price: pricingResult.unit_price_ex_vat || 0,
                    vat_rate: pricingResult.vat_rate || 20,
                    notes: pricingResult.pricing_notes || '',
                    supplier: pricingResult.supplier_suggestion || '',
                    specifications: item.specifications || ''
                });

            } catch (error) {
                console.warn(`Pricing failed for ${item.description}:`, error);
                // Fallback to basic item without pricing
                pricedItems.push({
                    description: item.description,
                    quantity: item.quantity,
                    unit: item.unit,
                    unit_price: 0,
                    vat_rate: 20,
                    notes: 'Price needs manual review',
                    supplier: '',
                    specifications: item.specifications || ''
                });
            }
        }

        return pricedItems;
    };

    const findExistingCustomer = async (customerInfo) => {
        if (!customerInfo.name || !companyId) return null;

        try {
            // Search for existing customer by name
            const customers = await Customer.filter({ 
                company_id: companyId,
                full_name: { $regex: customerInfo.name, $options: 'i' }
            });

            if (customers.length > 0) {
                return customers[0]; // Return first match
            }
        } catch (error) {
            console.warn('Customer search failed:', error);
        }
        
        return null;
    };

    const processFile = async () => {
        if (!file) {
            onError("Please select a PDF file first.");
            return;
        }

        setLoading(true);
        try {
            setStatus("1/5: Uploading PDF file...");
            const { file_url } = await UploadFile({ file });

            setStatus("2/5: Extracting project details from PDF...");
            const extractionResult = await ExtractDataFromUploadedFile({
                file_url,
                json_schema: EXTRACTION_SCHEMA
            });
            
            if (extractionResult.status !== 'success' || !extractionResult.output.items) {
                throw new Error(extractionResult.details || "Could not extract items from the PDF. Please ensure the file contains a clear materials list or specifications.");
            }
            
            const { items, customer_info, project_type, location, scope_of_work } = extractionResult.output;

            setStatus("3/5: Finding real-world prices...");
            const pricedItems = await findRealWorldPricing(items);

            setStatus("4/5: Checking for existing customer...");
            const existingCustomer = customer_info ? await findExistingCustomer(customer_info) : null;

            setStatus("5/5: Preparing quote...");
            
            const result = {
                items: pricedItems,
                customerInfo: customer_info || null,
                existingCustomer,
                projectType: project_type || '',
                location: location || '',
                scopeOfWork: scope_of_work || '',
                extractionSummary: {
                    totalItems: pricedItems.length,
                    customerFound: !!customer_info?.name,
                    existingCustomerFound: !!existingCustomer
                }
            };

            setExtractedData(result);
            setStatus("✅ PDF processed successfully!");
            
            // Call the completion handler
            if (onComplete) {
                onComplete(result);
            }

        } catch (error) {
            console.error('PDF processing failed:', error);
            onError(`Failed to process PDF: ${error.message}`);
            setStatus("❌ Processing failed");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Card>
            <CardContent className="p-6">
                <div className="space-y-4">
                    <div className="text-center">
                        <div className="w-16 h-16 mx-auto bg-blue-100 rounded-full flex items-center justify-center mb-4">
                            <FileText className="w-8 h-8 text-blue-600" />
                        </div>
                        <h3 className="text-lg font-semibold mb-2">Upload PDF Drawing or Specification</h3>
                        <p className="text-sm text-gray-600 mb-4">
                            Upload a PDF with project specifications, drawings, or materials list. 
                            I'll extract the materials and find current UK trade prices.
                        </p>
                    </div>

                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                        <input
                            type="file"
                            accept=".pdf"
                            onChange={handleFileChange}
                            className="hidden"
                            id="pdf-upload"
                            disabled={loading}
                        />
                        <label 
                            htmlFor="pdf-upload" 
                            className="cursor-pointer flex flex-col items-center"
                        >
                            <UploadCloud className="w-12 h-12 text-gray-400 mb-2" />
                            <span className="text-sm font-medium text-gray-700">
                                {file ? file.name : "Click to select PDF file"}
                            </span>
                            <span className="text-xs text-gray-500 mt-1">
                                PDF files only, max 10MB
                            </span>
                        </label>
                    </div>

                    {file && (
                        <Button 
                            onClick={processFile} 
                            disabled={loading}
                            className="w-full bg-blue-600 hover:bg-blue-700"
                        >
                            {loading ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Processing...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4 mr-2" />
                                    Generate AI Quote
                                </>
                            )}
                        </Button>
                    )}

                    {status && (
                        <div className="text-center">
                            <p className={`text-sm ${loading ? 'text-blue-600' : extractedData ? 'text-green-600' : 'text-gray-600'}`}>
                                {status}
                            </p>
                        </div>
                    )}

                    {extractedData && (
                        <div className="bg-green-50 border border-green-200 rounded-lg p-4 space-y-2">
                            <div className="flex items-center gap-2 text-green-800 font-medium">
                                <Sparkles className="w-4 h-4" />
                                Extraction Complete
                            </div>
                            <div className="grid grid-cols-2 gap-4 text-sm">
                                <div className="flex items-center gap-2">
                                    <Globe className="w-4 h-4 text-blue-500" />
                                    <span>{extractedData.extractionSummary.totalItems} items priced</span>
                                </div>
                                {extractedData.extractionSummary.customerFound && (
                                    <div className="flex items-center gap-2">
                                        <User className="w-4 h-4 text-purple-500" />
                                        <span>Customer: {extractedData.customerInfo.name}</span>
                                    </div>
                                )}
                            </div>
                            {extractedData.projectType && (
                                <p className="text-sm text-gray-600">
                                    Project: {extractedData.projectType}
                                </p>
                            )}
                        </div>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}
