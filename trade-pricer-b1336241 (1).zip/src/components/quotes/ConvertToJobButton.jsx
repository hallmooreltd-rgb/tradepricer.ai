import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Job } from "@/api/entities";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { CheckCircle, Loader2 } from "lucide-react";

export default function ConvertToJobButton({ quote, customer }) {
  const navigate = useNavigate();
  const [converting, setConverting] = useState(false);

  const handleConvert = async () => {
    if (!quote || !customer) return;
    
    setConverting(true);
    try {
      // Create a job from the accepted quote
      const jobData = {
        company_id: quote.company_id,
        customer_id: quote.customer_id,
        quote_id: quote.id,
        job_type: "other", // Default, user can change later
        title: `Job from Quote ${quote.quote_number}`,
        status: "draft",
        notes: `Created from accepted quote ${quote.quote_number}. Total value: £${quote.total}`,
      };

      const newJob = await Job.create(jobData);
      navigate(createPageUrl(`Job?id=${newJob.id}`));
    } catch (e) {
      console.error("Failed to convert quote to job:", e);
      alert("Could not create job from quote. Please try again.");
    } finally {
      setConverting(false);
    }
  };

  return (
    <Button 
      onClick={handleConvert} 
      disabled={converting}
      className="bg-green-600 hover:bg-green-700"
    >
      {converting ? (
        <>
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          Creating Job...
        </>
      ) : (
        <>
          <CheckCircle className="w-4 h-4 mr-2" />
          Convert to Job
        </>
      )}
    </Button>
  );
}