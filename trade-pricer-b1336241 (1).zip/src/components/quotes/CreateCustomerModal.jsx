import React, { useState } from 'react';
import { Customer } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogFooter,
} from '@/components/ui/dialog';
import { Loader2, User } from 'lucide-react';

export default function CreateCustomerModal({ 
    isOpen, 
    onClose, 
    onCustomerCreated, 
    companyId, 
    prefillData = {} 
}) {
    const [form, setForm] = useState({
        full_name: prefillData.name || '',
        email: prefillData.email || '',
        phone: prefillData.phone || '',
        address_line1: prefillData.address ? prefillData.address.split(',')[0] || '' : '',
        address_line2: '',
        town_city: '',
        county: '',
        postcode: '',
        notes: `Created from AI quote on ${new Date().toLocaleDateString()}`,
        ...prefillData
    });
    
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState('');

    // Parse address if it's a complete address string
    React.useEffect(() => {
        if (prefillData.address && prefillData.address.includes(',')) {
            const parts = prefillData.address.split(',').map(p => p.trim());
            const updates = {
                address_line1: parts[0] || '',
                town_city: parts[parts.length - 2] || '',
                postcode: parts[parts.length - 1] || ''
            };
            
            // If there are more parts, use them for address_line2
            if (parts.length > 3) {
                updates.address_line2 = parts.slice(1, -2).join(', ');
            }
            
            setForm(prev => ({ ...prev, ...updates }));
        }
    }, [prefillData.address]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setForm(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (!form.full_name.trim()) {
            setError('Customer name is required.');
            return;
        }

        setSaving(true);
        setError('');

        try {
            const newCustomer = await Customer.create({
                ...form,
                company_id: companyId,
                postcode: form.postcode.toUpperCase().trim()
            });

            onCustomerCreated(newCustomer);
            onClose();
        } catch (err) {
            console.error('Failed to create customer:', err);
            setError(err.message || 'Failed to create customer. Please try again.');
        } finally {
            setSaving(false);
        }
    };

    const handleClose = () => {
        if (!saving) {
            setForm({
                full_name: '',
                email: '',
                phone: '',
                address_line1: '',
                address_line2: '',
                town_city: '',
                county: '',
                postcode: '',
                notes: ''
            });
            setError('');
            onClose();
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={handleClose}>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <User className="w-5 h-5" />
                        Create New Customer
                    </DialogTitle>
                </DialogHeader>

                <form onSubmit={handleSubmit} className="space-y-4">
                    {error && (
                        <div className="p-3 bg-red-50 text-red-700 border border-red-200 rounded-md text-sm">
                            {error}
                        </div>
                    )}

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <Label htmlFor="full_name">
                                Full Name <span className="text-red-500">*</span>
                            </Label>
                            <Input
                                id="full_name"
                                name="full_name"
                                value={form.full_name}
                                onChange={handleChange}
                                required
                                disabled={saving}
                            />
                        </div>
                        <div>
                            <Label htmlFor="phone">Phone</Label>
                            <Input
                                id="phone"
                                name="phone"
                                type="tel"
                                value={form.phone}
                                onChange={handleChange}
                                disabled={saving}
                            />
                        </div>
                    </div>

                    <div>
                        <Label htmlFor="email">Email</Label>
                        <Input
                            id="email"
                            name="email"
                            type="email"
                            value={form.email}
                            onChange={handleChange}
                            disabled={saving}
                        />
                    </div>

                    <div className="space-y-4">
                        <Label className="text-base font-medium">Address</Label>
                        
                        <div>
                            <Label htmlFor="address_line1">Address Line 1</Label>
                            <Input
                                id="address_line1"
                                name="address_line1"
                                value={form.address_line1}
                                onChange={handleChange}
                                disabled={saving}
                                placeholder="House number and street name"
                            />
                        </div>

                        <div>
                            <Label htmlFor="address_line2">Address Line 2</Label>
                            <Input
                                id="address_line2"
                                name="address_line2"
                                value={form.address_line2}
                                onChange={handleChange}
                                disabled={saving}
                                placeholder="Area, district, or additional address info"
                            />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <Label htmlFor="town_city">Town/City</Label>
                                <Input
                                    id="town_city"
                                    name="town_city"
                                    value={form.town_city}
                                    onChange={handleChange}
                                    disabled={saving}
                                />
                            </div>
                            <div>
                                <Label htmlFor="county">County</Label>
                                <Input
                                    id="county"
                                    name="county"
                                    value={form.county}
                                    onChange={handleChange}
                                    disabled={saving}
                                />
                            </div>
                            <div>
                                <Label htmlFor="postcode">Postcode</Label>
                                <Input
                                    id="postcode"
                                    name="postcode"
                                    value={form.postcode}
                                    onChange={handleChange}
                                    disabled={saving}
                                    placeholder="SW1A 1AA"
                                />
                            </div>
                        </div>
                    </div>

                    <div>
                        <Label htmlFor="notes">Notes</Label>
                        <Textarea
                            id="notes"
                            name="notes"
                            rows={3}
                            value={form.notes}
                            onChange={handleChange}
                            disabled={saving}
                            placeholder="Additional customer information..."
                        />
                    </div>

                    <DialogFooter className="gap-2 pt-4">
                        <Button 
                            type="button" 
                            variant="outline" 
                            onClick={handleClose}
                            disabled={saving}
                        >
                            Cancel
                        </Button>
                        <Button 
                            type="submit" 
                            disabled={saving || !form.full_name.trim()}
                            className="bg-blue-600 hover:bg-blue-700"
                        >
                            {saving ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Creating...
                                </>
                            ) : (
                                'Create Customer'
                            )}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}