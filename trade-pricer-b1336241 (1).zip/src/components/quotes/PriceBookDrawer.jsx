import React, { useEffect, useMemo, useState } from "react";
import { PriceItem } from "@/api/entities";
import { Assembly } from "@/api/entities";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Plus, Package, Search, X } from "lucide-react";

export default function PriceBookDrawer({
  open,
  onClose,
  onPick,
}) {
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState([]);
  const [assemblies, setAssemblies] = useState([]);
  const [q, setQ] = useState("");

  useEffect(() => {
    if (!open) return;
    const load = async () => {
      setLoading(true);
      try {
        const its = await PriceItem.list ? await PriceItem.list("-created_date", 500) : [];
        const asms = await Assembly.list ? await Assembly.list("-created_date", 200) : [];
        setItems(its || []);
        setAssemblies((asms || []).map(a => ({
          ...a,
          lines: a.lines_json ? JSON.parse(a.lines_json) : []
        })));
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [open]);

  const filteredItems = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return items;
    return items.filter((i) =>
      [i.name, i.sku, i.category].filter(Boolean).join(" ").toLowerCase().includes(term)
    );
  }, [items, q]);

  const filteredAssemblies = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return assemblies;
    return assemblies.filter((a) => a.name?.toLowerCase().includes(term));
  }, [assemblies, q]);

  const addItem = (i) => {
    onPick([{
      description: i.name,
      quantity: 1,
      unit_price: i.default_price || 0,
      vat_rate: i.default_vat_rate ?? 20,
      price_item_id: i.id,
      expected_cost_ex_vat: i.default_cost || 0,
    }]);
  };

  const addAssembly = (a) => {
    const lines = (a.lines || []).map((ln) => {
      const ref = items.find((x) => x.id === ln.price_item_id);
      const basePrice = ref?.default_price ?? 0;
      const baseVat = ref?.default_vat_rate ?? 20;
      return {
        description: `${ref?.name || "Item"} - from assembly ${a.name}`,
        quantity: ln.quantity || 1,
        unit_price: ln.override_price ?? basePrice,
        vat_rate: ln.override_vat_rate ?? baseVat,
        price_item_id: ref?.id,
        expected_cost_ex_vat: (ln.quantity || 1) * (ref?.default_cost ?? 0),
      };
    });
    onPick(lines);
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden shadow-xl">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-semibold">Add from price book</h2>
          <button className="p-2" onClick={onClose} aria-label="Close">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto max-h-[calc(90vh-120px)]">
          <div className="flex gap-2 items-center mb-6">
            <Search className="w-4 h-4 text-gray-500" />
            <Input placeholder="Search items or assemblies" value={q} onChange={e => setQ(e.target.value)} />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h4 className="text-lg font-semibold mb-3 flex items-center gap-2">
                <Package className="w-5 h-5" />
                Assemblies
              </h4>
              <div className="space-y-2">
                {loading && <div className="text-gray-600">Loading…</div>}
                {!loading && filteredAssemblies.length === 0 && <div className="text-gray-600">No assemblies found.</div>}
                {filteredAssemblies.map((a) => (
                  <div key={a.id} className="border rounded-xl p-4 bg-white hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Package className="w-5 h-5 text-blue-600" />
                        <div>
                          <div className="font-medium">{a.name}</div>
                          <div className="text-sm text-gray-600">{(a.lines || []).length} items</div>
                        </div>
                      </div>
                      <Button size="sm" onClick={() => addAssembly(a)}>
                        <Plus className="w-4 h-4 mr-1" /> Add
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-3">Individual Items</h4>
              <div className="space-y-2">
                {!loading && filteredItems.length === 0 && <div className="text-gray-600">No items found.</div>}
                {filteredItems.map((i) => (
                  <div key={i.id} className="border rounded-xl p-4 bg-white hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">{i.name}</div>
                        <div className="text-sm text-gray-600">
                          {i.category || "Uncategorised"} {i.sku && ` · ${i.sku}`}
                        </div>
                        <div className="text-sm font-medium text-green-700">
                          £{(i.default_price || 0).toFixed(2)} + {i.default_vat_rate || 0}% VAT
                        </div>
                        {i.default_cost && (
                          <div className="text-xs text-gray-500">
                            Cost: £{(i.default_cost || 0).toFixed(2)}
                          </div>
                        )}
                      </div>
                      <Button size="sm" onClick={() => addItem(i)}>
                        <Plus className="w-4 h-4 mr-1" /> Add
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}