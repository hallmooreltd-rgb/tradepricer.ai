import React, { useMemo, useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Users, Calculator } from "lucide-react";
import { Staff } from "@/api/entities";
import { User } from "@/api/entities";

export default function QuoteItemsEditor({ items, onChange }) {
  const [staffList, setStaffList] = useState([]);
  const [loadingStaff, setLoadingStaff] = useState(true);
  
  const list = items || [];

  // Load staff members
  useEffect(() => {
    const loadStaff = async () => {
      try {
        const me = await User.me();
        if (me?.company_id) {
          const staff = await Staff.filter(
            { company_id: me.company_id, active: { $ne: false } }, 
            "name", 
            200
          );
          setStaffList(staff);
        }
      } catch (error) {
        console.error("Error loading staff:", error);
      }
      setLoadingStaff(false);
    };
    loadStaff();
  }, []);

  const add = () => {
    onChange([
      ...list,
      { description: "", quantity: 1, unit_price: 0, vat_rate: 20, category: "materials" },
    ]);
  };

  const addLabourItem = () => {
    onChange([
      ...list,
      { 
        description: "Labour - ", 
        quantity: 1, 
        unit_price: 0, 
        vat_rate: 20, 
        category: "labour",
        staff_assignments: [] // New field for staff assignments
      },
    ]);
  };

  const update = (idx, patch) => {
    const next = list.slice();
    next[idx] = { ...next[idx], ...patch };
    onChange(next);
  };

  const removeAt = (idx) => {
    const next = list.slice();
    next.splice(idx, 1);
    onChange(next);
  };

  // Add staff assignment to a labor item
  const addStaffAssignment = (itemIdx) => {
    const item = list[itemIdx];
    const assignments = item.staff_assignments || [];
    const newAssignments = [
      ...assignments,
      { staff_id: "", days: 1, daily_rate: 0 }
    ];
    update(itemIdx, { staff_assignments: newAssignments });
  };

  // Update staff assignment
  const updateStaffAssignment = (itemIdx, assignmentIdx, patch) => {
    const item = list[itemIdx];
    const assignments = [...(item.staff_assignments || [])];
    assignments[assignmentIdx] = { ...assignments[assignmentIdx], ...patch };
    
    // Auto-calculate unit price based on total staff costs
    const totalStaffCost = assignments.reduce((sum, assignment) => {
      return sum + (assignment.days * assignment.daily_rate);
    }, 0);
    
    update(itemIdx, { 
      staff_assignments: assignments,
      unit_price: totalStaffCost,
      quantity: 1 // Labor items are typically quantity 1 with total cost
    });
  };

  // Remove staff assignment
  const removeStaffAssignment = (itemIdx, assignmentIdx) => {
    const item = list[itemIdx];
    const assignments = [...(item.staff_assignments || [])];
    assignments.splice(assignmentIdx, 1);
    
    // Recalculate total
    const totalStaffCost = assignments.reduce((sum, assignment) => {
      return sum + (assignment.days * assignment.daily_rate);
    }, 0);
    
    update(itemIdx, { 
      staff_assignments: assignments,
      unit_price: totalStaffCost
    });
  };

  // Handle staff selection change
  const handleStaffChange = (itemIdx, assignmentIdx, staffId) => {
    const selectedStaff = staffList.find(s => s.id === staffId);
    const dailyRate = selectedStaff ? selectedStaff.daily_rate_gbp : 0;
    
    updateStaffAssignment(itemIdx, assignmentIdx, {
      staff_id: staffId,
      daily_rate: dailyRate
    });
  };

  // Check if item is labor-related
  const isLaborItem = (item) => {
    return item.category === "labour" || 
           item.description.toLowerCase().includes("labour") ||
           item.description.toLowerCase().includes("install") ||
           item.description.toLowerCase().includes("fitting");
  };

  const totals = useMemo(() => {
    const subtotal = list.reduce(
      (acc, it) => acc + (Number(it.quantity) || 0) * (Number(it.unit_price) || 0),
      0
    );
    const vat_total = list.reduce((acc, it) => {
      const line = (Number(it.quantity) || 0) * (Number(it.unit_price) || 0);
      const vat = (Number(it.vat_rate) || 0) / 100;
      return acc + line * vat;
    }, 0);
    return { subtotal, vat_total, total: subtotal + vat_total };
  }, [list]);

  const gbp = (n) =>
    new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Line items</h3>
        <div className="flex gap-2">
          <Button type="button" variant="outline" onClick={addLabourItem}>
            <Users className="w-4 h-4 mr-2" /> Add labour
          </Button>
          <Button type="button" onClick={add}>
            <Plus className="w-4 h-4 mr-2" /> Add item
          </Button>
        </div>
      </div>

      <div className="space-y-3">
        {list.map((it, idx) => (
          <div key={idx} className="border rounded-xl p-4 bg-white">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
              <div className="md:col-span-6">
                <Label>Description</Label>
                <Textarea
                  rows={2}
                  value={it.description}
                  onChange={e => update(idx, { description: e.target.value })}
                  placeholder="Describe labour or materials"
                />
              </div>
              
              {!isLaborItem(it) && (
                <>
                  <div className="md:col-span-2">
                    <Label>Quantity</Label>
                    <Input
                      type="number"
                      inputMode="decimal"
                      value={it.quantity}
                      onChange={e => update(idx, { quantity: Number(e.target.value) })}
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Label>Unit price (ex VAT)</Label>
                    <Input
                      type="number"
                      inputMode="decimal"
                      step="0.01"
                      value={it.unit_price}
                      onChange={e => update(idx, { unit_price: Number(e.target.value) })}
                    />
                  </div>
                </>
              )}
              
              {isLaborItem(it) && (
                <div className="md:col-span-4">
                  <Label>Total Cost (calculated from staff)</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      inputMode="decimal"
                      step="0.01"
                      value={it.unit_price}
                      onChange={e => update(idx, { unit_price: Number(e.target.value) })}
                      className="bg-gray-50"
                    />
                    <Calculator className="w-4 h-4 text-gray-400" />
                  </div>
                </div>
              )}
              
              <div className="md:col-span-2">
                <Label>VAT rate</Label>
                <select
                  className="w-full border rounded-md h-10 px-3"
                  value={it.vat_rate}
                  onChange={e => update(idx, { vat_rate: Number(e.target.value) })}
                >
                  <option value={0}>0%</option>
                  <option value={5}>5%</option>
                  <option value={20}>20%</option>
                </select>
              </div>
            </div>

            {/* Staff Assignments for Labor Items */}
            {isLaborItem(it) && (
              <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex items-center justify-between mb-3">
                  <Label className="text-blue-800 font-medium">Staff Assignments</Label>
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm"
                    onClick={() => addStaffAssignment(idx)}
                    disabled={loadingStaff}
                  >
                    <Plus className="w-3 h-3 mr-1" /> Add staff
                  </Button>
                </div>
                
                {(it.staff_assignments || []).map((assignment, assignmentIdx) => (
                  <div key={assignmentIdx} className="grid grid-cols-1 md:grid-cols-5 gap-3 items-end mb-2 p-3 bg-white rounded border">
                    <div className="md:col-span-2">
                      <Label className="text-sm">Staff Member</Label>
                      <Select 
                        value={assignment.staff_id} 
                        onValueChange={(value) => handleStaffChange(idx, assignmentIdx, value)}
                      >
                        <SelectTrigger className="h-9">
                          <SelectValue placeholder="Select staff" />
                        </SelectTrigger>
                        <SelectContent>
                          {staffList.map(staff => (
                            <SelectItem key={staff.id} value={staff.id}>
                              {staff.name} ({staff.role}) - £{staff.daily_rate_gbp}/day
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label className="text-sm">Days</Label>
                      <Input
                        type="number"
                        inputMode="decimal"
                        step="0.5"
                        value={assignment.days}
                        onChange={e => updateStaffAssignment(idx, assignmentIdx, { days: Number(e.target.value) })}
                        className="h-9"
                      />
                    </div>
                    
                    <div>
                      <Label className="text-sm">Cost</Label>
                      <div className="text-sm font-medium text-gray-700 py-2">
                        {gbp(assignment.days * assignment.daily_rate)}
                      </div>
                    </div>
                    
                    <div>
                      <Button 
                        type="button" 
                        variant="outline" 
                        size="sm"
                        onClick={() => removeStaffAssignment(idx, assignmentIdx)}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                ))}
                
                {(!it.staff_assignments || it.staff_assignments.length === 0) && (
                  <div className="text-sm text-blue-600 italic">
                    Add staff assignments to automatically calculate labor costs
                  </div>
                )}
              </div>
            )}

            <div className="flex justify-between items-center mt-3">
              <div className="text-sm text-gray-600">
                Line total ex VAT: {gbp((it.quantity || 0) * (it.unit_price || 0))}
              </div>
              <Button type="button" variant="outline" onClick={() => removeAt(idx)}>
                <Trash2 className="w-4 h-4 mr-2" /> Remove
              </Button>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 border rounded-xl p-4 bg-gray-50">
        <div className="text-sm text-gray-600">Subtotal</div>
        <div className="md:col-span-2 text-right font-medium">{gbp(totals.subtotal)}</div>
        <div className="text-sm text-gray-600">VAT</div>
        <div className="md:col-span-2 text-right font-medium">{gbp(totals.vat_total)}</div>
        <div className="text-sm text-gray-800 font-semibold">Total</div>
        <div className="md:col-span-2 text-right text-lg font-bold">{gbp(totals.total)}</div>
      </div>
    </div>
  );
}