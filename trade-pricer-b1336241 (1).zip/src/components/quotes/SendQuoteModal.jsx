import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { X, Send, Loader2 } from "lucide-react";
import { buildQuotePdfBrowser } from "./buildQuotePdf";
import { UploadFile } from "@/api/integrations";
import { SendEmail } from "@/api/integrations";
import { Quote } from "@/api/entities";

export default function SendQuoteModal({
  open,
  onClose,
  company,
  customer,
  quote,
  portalUrl,
  onMarkSent,
}) {
  const [to, setTo] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    if (!open) return;
    setTo(customer?.email || "");
    setSubject(`Your quote ${quote?.quote_number} from ${company?.name || 'CertiFlow'}`);
    setMessage(
      `Hi ${customer?.full_name || "there"},\n\nPlease find your quote attached.\n` +
      (portalUrl ? `You can also view it online and accept it here: ${portalUrl}\n` : "") +
      `\nIf you would like to go ahead, please reply to this email or accept in the portal.\n\nThanks,\n${company?.name || 'CertiFlow'}`
    );
    setErr("");
  }, [open, customer, company, quote, portalUrl]);

  if (!open) return null;

  const sendNow = async () => {
    setErr("");
    if (!to) {
      setErr("Recipient email is required.");
      return;
    }
    setBusy(true);
    try {
      // Parse items_json if it's a string
      let quoteWithParsedItems = { ...quote };
      if (typeof quote.items_json === 'string') {
        try {
          quoteWithParsedItems.items_json = JSON.parse(quote.items_json);
        } catch (e) {
          quoteWithParsedItems.items_json = [];
        }
      }

      // 1. Generate PDF blob
      const blob = await buildQuotePdfBrowser({ 
        company, 
        customer, 
        quote: quoteWithParsedItems 
      });
      const pdfFile = new File([blob], `${quote.quote_number}.pdf`, { type: 'application/pdf' });

      // 2. Upload PDF to get a URL
      const { file_url: pdfUrl } = await UploadFile({ file: pdfFile });

      // 3. Update the Quote with the new PDF URL
      await Quote.update(quote.id, { pdf_url: pdfUrl });

      // 4. Construct email body with the PDF link
      const finalMessage = message + `\n\nDownload your PDF quote here: ${pdfUrl}`;

      // 5. Send the email using the integration
      await SendEmail({
        to,
        from_name: company?.name || "CertiFlow",
        subject,
        body: finalMessage,
      });

      // 6. Mark quote as sent and pass updated quote back
      const finalUpdatedQuote = await Quote.update(quote.id, { status: "sent" });
      if (onMarkSent) onMarkSent(finalUpdatedQuote);

      onClose();
      alert("Quote sent successfully!");
    } catch (e) {
      console.error(e);
      setErr(e?.message || "Could not send the quote. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-xl">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-semibold">Send quote</h2>
          <button className="p-2" onClick={onClose} aria-label="Close"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-6 space-y-4">
          {err ? <p className="text-red-600 text-sm p-3 bg-red-50 rounded-md">{err}</p> : null}
          <div>
            <Label>To</Label>
            <Input type="email" value={to} onChange={e => setTo(e.target.value)} />
          </div>
          <div>
            <Label>Subject</Label>
            <Input value={subject} onChange={e => setSubject(e.target.value)} />
          </div>
          <div>
            <Label>Message</Label>
            <Textarea rows={8} value={message} onChange={e => setMessage(e.target.value)} />
            <p className="text-xs text-gray-500 mt-1">
              The PDF will be uploaded and a download link will be included automatically.
            </p>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={sendNow} disabled={busy} className="bg-blue-600 hover:bg-blue-700">
              {busy ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Sending</> : <>Send <Send className="w-4 h-4 ml-2" /></>}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}