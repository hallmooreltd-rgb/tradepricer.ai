import React, { useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2 } from "lucide-react";

export default function StagedPaymentsEditor({
  stages,
  onChange,
  totalIncVat,
}) {
  const list = stages || [];

  const addStage = () => onChange([...list, { label: "Deposit", type: "percent", value: 25, due: "on_acceptance" }]);

  const update = (i, patch) => {
    const next = list.slice();
    next[i] = { ...next[i], ...patch };
    onChange(next);
  };

  const removeAt = (i) => {
    const next = list.slice();
    next.splice(i, 1);
    onChange(next);
  };

  const amounts = useMemo(() => {
    const rows = list.map(s => ({
      label: s.label,
      amount: s.type === "percent" ? (totalIncVat * (Number(s.value) || 0)) / 100 : Number(s.value) || 0,
    }));
    const planned = rows.reduce((a, r) => a + r.amount, 0);
    const diff = Math.round((totalIncVat - planned) * 100) / 100;
    return { rows, planned, diff };
  }, [list, totalIncVat]);

  const gbp = (n) => new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Staged payments</h3>
        <Button type="button" onClick={addStage}>
          <Plus className="w-4 h-4 mr-2" /> Add stage
        </Button>
      </div>

      {list.map((s, i) => (
        <div key={i} className="border rounded-xl p-4 bg-white">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
            <div className="md:col-span-3">
              <Label>Label</Label>
              <Input 
                value={s.label} 
                onChange={e => update(i, { label: e.target.value })} 
                placeholder="Deposit" 
              />
            </div>
            <div className="md:col-span-2">
              <Label>Type</Label>
              <Select value={s.type} onValueChange={(v) => update(i, { type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="percent">Percent</SelectItem>
                  <SelectItem value="fixed">Fixed amount</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="md:col-span-2">
              <Label>Value</Label>
              <Input 
                type="number" 
                inputMode="decimal" 
                value={s.value} 
                onChange={e => update(i, { value: Number(e.target.value) })} 
              />
            </div>
            <div className="md:col-span-3">
              <Label>Due</Label>
              <Select value={s.due} onValueChange={(v) => update(i, { due: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="on_acceptance">On acceptance</SelectItem>
                  <SelectItem value="scheduled_date">On scheduled date</SelectItem>
                  <SelectItem value="completion">On completion</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="md:col-span-2">
              <Label>Amount</Label>
              <div className="h-10 flex items-center px-3 border rounded-md bg-gray-50 font-medium">
                {gbp(s.type === "percent" ? (totalIncVat * (Number(s.value) || 0)) / 100 : Number(s.value) || 0)}
              </div>
            </div>
          </div>
          <div className="flex justify-end mt-3">
            <Button type="button" variant="outline" size="sm" onClick={() => removeAt(i)}>
              <Trash2 className="w-4 h-4 mr-2" /> Remove
            </Button>
          </div>
        </div>
      ))}

      {list.length > 0 && (
        <div className="grid grid-cols-2 gap-4 border rounded-xl p-4 bg-gray-50">
          <div className="text-sm text-gray-600">Planned total</div>
          <div className="text-right font-medium">{gbp(amounts.planned)}</div>
          <div className="text-sm text-gray-600">Difference to quote total</div>
          <div className={`text-right font-semibold ${amounts.diff === 0 ? "text-green-700" : "text-amber-700"}`}>
            {gbp(amounts.diff)}
          </div>
          {amounts.diff !== 0 && (
            <div className="col-span-2 text-sm text-amber-700">
              Adjust stage values to match the quote total exactly.
            </div>
          )}
        </div>
      )}
    </div>
  );
}