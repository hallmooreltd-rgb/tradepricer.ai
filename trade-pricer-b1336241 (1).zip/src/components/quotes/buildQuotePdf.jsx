import jsPDF from "jspdf";

const gbp = (n) =>
  new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

export async function buildQuotePdfBrowser({
  company,
  customer,
  quote,
}) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });

  // Header with logo
  let x = 20;
  let y = 16;

  const logo = quote.logo_url || company?.logo_url;
  if (logo) {
    try {
      const img = await loadImage(logo);
      const w = 40;
      const r = img.width ? w / img.width : 1;
      const h = img.height ? img.height * r : 16;
      doc.addImage(img.el, "PNG", x, y - 6, w, h);
      x = 65;
    } catch {
      // no logo
    }
  }

  doc.setFontSize(16);
  doc.text(company?.name || "Company", x, y);
  doc.setFontSize(10);
  const contact = [
    company?.address_line1,
    company?.address_line2,
    [company?.town_city, company?.postcode].filter(Boolean).join(" "),
  ].filter(Boolean);
  if (contact.length) doc.text(contact.join(", "), x, y + 6);
  const line2 = [company?.phone && `Tel: ${company.phone}`, company?.email && `Email: ${company.email}`]
    .filter(Boolean)
    .join("    ");
  if (line2) doc.text(line2, x, y + 12);

  // Quote meta block
  doc.setFontSize(18);
  doc.text("Quotation", 20, 42);
  doc.setFontSize(11);
  doc.text(`Quote number: ${quote.quote_number}`, 20, 49);
  doc.text(`Issue date: ${quote.issue_date}`, 20, 55);
  doc.text(`Expiry date: ${quote.expiry_date}`, 20, 61);

  // Customer block
  const c = customer || {};
  const addr = [
    c.full_name,
    c.address_line1,
    c.address_line2,
    [c.town_city, c.postcode].filter(Boolean).join(" "),
  ]
    .filter(Boolean)
    .join("\n");
  doc.text("To:", 130, 42);
  doc.text(addr || "", 130, 49);

  // Items table header
  let tableY = 75;
  doc.setFontSize(11);
  doc.text("Description", 20, tableY);
  doc.text("Qty", 120, tableY);
  doc.text("Unit ex VAT", 135, tableY);
  doc.text("VAT", 165, tableY);
  doc.text("Line total", 190, tableY, { align: "right" });

  doc.setLineWidth(0.2);
  doc.line(20, tableY + 2, 190, tableY + 2);

  // Items
  let yCursor = tableY + 8;
  quote.items_json.forEach((it, idx) => {
    const descLines = doc.splitTextToSize(it.description || "", 95);
    const rowH = Math.max(6, descLines.length * 5);
    doc.text(descLines, 20, yCursor);
    doc.text(String(it.quantity || 0), 120, yCursor);
    doc.text(gbp(it.unit_price || 0), 135, yCursor);
    doc.text(`${Number(it.vat_rate || 0)}%`, 165, yCursor);
    const lineTotal = (it.quantity || 0) * (it.unit_price || 0) * (1 + (Number(it.vat_rate || 0) / 100));
    doc.text(gbp(lineTotal), 190, yCursor, { align: "right" });
    yCursor += rowH + 3;
  });

  // Totals box
  yCursor += 4;
  doc.setLineWidth(0.2);
  doc.line(120, yCursor, 190, yCursor);
  yCursor += 6;
  doc.text("Subtotal", 145, yCursor);
  doc.text(gbp(quote.subtotal), 190, yCursor, { align: "right" });
  yCursor += 6;
  doc.text("VAT", 145, yCursor);
  doc.text(gbp(quote.vat_total), 190, yCursor, { align: "right" });
  if (quote.discount_percent) {
    yCursor += 6;
    const beforeDiscount = Number(quote.subtotal) + Number(quote.vat_total);
    const disc = beforeDiscount * (Number(quote.discount_percent) / 100);
    doc.text(`Discount ${quote.discount_percent}%`, 145, yCursor);
    doc.text(`- ${gbp(disc)}`, 190, yCursor, { align: "right" });
  }
  yCursor += 8;
  doc.setFontSize(13);
  doc.text("Total", 145, yCursor);
  doc.text(gbp(quote.total), 190, yCursor, { align: "right" });

  // Notes and terms
  yCursor += 12;
  doc.setFontSize(11);
  if (quote.notes) {
    doc.text("Notes", 20, yCursor);
    yCursor += 5;
    const lines = doc.splitTextToSize(quote.notes, 170);
    doc.text(lines, 20, yCursor);
    yCursor += lines.length * 5 + 4;
  }
  if (quote.terms) {
    doc.text("Terms", 20, yCursor);
    yCursor += 5;
    const lines = doc.splitTextToSize(quote.terms, 170);
    doc.text(lines, 20, yCursor);
  }

  return doc.output("blob");
}

async function loadImage(src) {
  const el = new Image();
  el.crossOrigin = "anonymous";
  el.referrerPolicy = "no-referrer";
  return new Promise((resolve, reject) => {
    el.onload = () => resolve({ el, width: el.naturalWidth, height: el.naturalHeight });
    el.onerror = reject;
    el.src = src;
  });
}