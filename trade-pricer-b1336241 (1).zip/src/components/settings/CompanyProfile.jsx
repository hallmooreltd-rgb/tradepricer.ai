import React, { useState } from 'react';
import { Company } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Building, Save, Upload, Loader2, Copy } from "lucide-react";
import { toast } from "sonner";

export default function CompanyProfile({ company, setCompany }) {
  const [companyData, setCompanyData] = useState(company);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleLogoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await UploadFile({ file });
      setCompanyData(prev => ({ ...prev, logo_url: file_url }));
    } catch (error) {
      console.error("Error uploading logo:", error);
      toast.error("Logo upload failed. Please try again.");
    }
    setUploading(false);
  };

  const handleSaveCompany = async () => {
    if (!company) return;

    setSaving(true);
    try {
      const updatedCompany = await Company.update(company.id, companyData);
      setCompany(updatedCompany);
      toast.success("Company profile saved!");
    } catch (error) {
      console.error("Error saving company:", error);
      toast.error("Failed to save changes.");
    }
    setSaving(false);
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success("Company ID copied!");
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Building className="w-5 h-5" />
          Company Profile
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center gap-6">
          <div className="w-20 h-20 bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden">
            {companyData.logo_url ? (
              <img
                src={companyData.logo_url}
                alt="Company logo"
                className="w-full h-full object-cover"
              />
            ) : (
              <Building className="w-8 h-8 text-gray-400" />
            )}
          </div>
          <div>
            <Label>Company Logo</Label>
            <div className="flex gap-2 mt-1">
              <input
                type="file"
                accept="image/*"
                onChange={handleLogoUpload}
                className="hidden"
                id="logo-upload"
                disabled={uploading}
              />
              <label htmlFor="logo-upload">
                <Button size="sm" variant="outline" disabled={uploading} asChild>
                  <span>
                    {uploading ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Upload className="w-4 h-4 mr-2" />
                    )}
                    {uploading ? 'Uploading...' : 'Upload Logo'}
                  </span>
                </Button>
              </label>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="company-name">Company Name</Label>
            <Input
              id="company-name"
              value={companyData.name || ""}
              onChange={(e) => setCompanyData(prev => ({ ...prev, name: e.target.value }))}
            />
          </div>
          <div>
            <Label htmlFor="company-id">Company ID</Label>
            <div className="flex items-center gap-2">
              <Input
                id="company-id"
                value={company?.id || ""}
                readOnly
                className="bg-gray-50"
              />
              <Button variant="outline" size="icon" onClick={() => copyToClipboard(company?.id)}>
                <Copy className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-1">Your unique company identifier for support.</p>
          </div>
          <div>
            <Label htmlFor="company-email">Email</Label>
            <Input
              id="company-email"
              type="email"
              value={companyData.email || ""}
              onChange={(e) => setCompanyData(prev => ({ ...prev, email: e.target.value }))}
            />
          </div>
          <div>
            <Label htmlFor="company-phone">Phone</Label>
            <Input
              id="company-phone"
              value={companyData.phone || ""}
              onChange={(e) => setCompanyData(prev => ({ ...prev, phone: e.target.value }))}
            />
          </div>
          <div>
            <Label htmlFor="company-website">Website</Label>
            <Input
              id="company-website"
              value={companyData.website || ""}
              onChange={(e) => setCompanyData(prev => ({ ...prev, website: e.target.value }))}
            />
          </div>
        </div>

        <div className="space-y-4">
          <Label>Address</Label>
          <div className="grid gap-4">
            <Input
              placeholder="Address Line 1"
              value={companyData.address_line1 || ""}
              onChange={(e) => setCompanyData(prev => ({ ...prev, address_line1: e.target.value }))}
            />
            <Input
              placeholder="Address Line 2"
              value={companyData.address_line2 || ""}
              onChange={(e) => setCompanyData(prev => ({ ...prev, address_line2: e.target.value }))}
            />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Input
                placeholder="Town/City"
                value={companyData.town_city || ""}
                onChange={(e) => setCompanyData(prev => ({ ...prev, town_city: e.target.value }))}
              />
              <Input
                placeholder="County"
                value={companyData.county || ""}
                onChange={(e) => setCompanyData(prev => ({ ...prev, county: e.target.value }))}
              />
              <Input
                placeholder="Postcode"
                value={companyData.postcode || ""}
                onChange={(e) => setCompanyData(prev => ({ ...prev, postcode: e.target.value }))}
              />
            </div>
          </div>
        </div>

        <div>
          <Label htmlFor="vat-number">VAT Number</Label>
          <Input
            id="vat-number"
            value={companyData.vat_number || ""}
            onChange={(e) => setCompanyData(prev => ({ ...prev, vat_number: e.target.value }))}
          />
        </div>

        <div className="space-y-4">
          <Label>Review Links</Label>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="google-review" className="text-xs">Google Reviews URL</Label>
              <Input
                id="google-review"
                value={companyData.google_review_url || ""}
                onChange={(e) => setCompanyData(prev => ({ ...prev, google_review_url: e.target.value }))}
                placeholder="https://g.page/r/..."
              />
            </div>
            <div>
              <Label htmlFor="checkatrade" className="text-xs">Checkatrade URL</Label>
              <Input
                id="checkatrade"
                value={companyData.checkatrade_url || ""}
                onChange={(e) => setCompanyData(prev => ({ ...prev, checkatrade_url: e.target.value }))}
                placeholder="https://www.checkatrade.com/..."
              />
            </div>
            <div>
              <Label htmlFor="trustpilot" className="text-xs">Trustpilot URL</Label>
              <Input
                id="trustpilot"
                value={companyData.trustpilot_url || ""}
                onChange={(e) => setCompanyData(prev => ({ ...prev, trustpilot_url: e.target.value }))}
                placeholder="https://uk.trustpilot.com/..."
              />
            </div>
          </div>
          <p className="text-sm text-gray-500">
            Add your review profile URLs to automatically request reviews from customers when jobs are completed.
          </p>
        </div>

        <div className="flex justify-end">
          <Button
            onClick={handleSaveCompany}
            disabled={saving}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {saving ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Save className="w-4 h-4 mr-2" />
            )}
            {saving ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}