import React, { useState } from 'react';
import { Invitation, User } from '@/api/entities';
import { SendEmail } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { User as UserIcon, Send, Trash2, Loader2 } from "lucide-react";
import { ENTITLEMENTS } from "../billing/plans";
import UpsellModal from "../billing/UpsellModal";
import { toast } from "sonner";

export default function TeamManagement({ company, team, invitations, setInvitations }) {
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState("user");
  const [inviting, setInviting] = useState(false);
  const [showUpsell, setShowUpsell] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  useState(() => {
    User.me().then(setCurrentUser);
  }, []);

  const handleInvite = async () => {
    if (!inviteEmail || !company || !currentUser) return;

    // Check plan limits
    const limit = ENTITLEMENTS[company.plan_tier || 'free'].users_included;
    const currentUsers = team.length;
    const pendingInvites = invitations.filter(i => i.status === 'pending').length;

    if ((currentUsers + pendingInvites) >= limit) {
      setShowUpsell(true);
      return;
    }

    setInviting(true);
    try {
      const newInvitation = await Invitation.create({
        company_id: company.id,
        email: inviteEmail,
        role: inviteRole,
        status: 'pending'
      });

      await SendEmail({
        to: inviteEmail,
        from_name: `${currentUser.full_name} via TradePricer`,
        subject: `You're invited to join ${company.name} on TradePricer`,
        body: `Hello,\n\nYou have been invited to join ${company.name}'s team on TradePricer.\n\nPlease sign up at the link below to accept your invitation:\n\n${window.location.origin}\n\nThanks,\nThe ${company.name} Team`
      });

      setInvitations(prev => [...prev, newInvitation]);
      setInviteEmail("");
      toast.success("Invitation sent!");
    } catch (error) {
      console.error("Failed to send invitation:", error);
      toast.error("Could not send invitation. Please try again.");
    }
    setInviting(false);
  };

  const handleRevokeInvite = async (inviteId) => {
    try {
      await Invitation.delete(inviteId);
      setInvitations(prev => prev.filter(inv => inv.id !== inviteId));
      toast.success("Invitation revoked.");
    } catch (error) {
      console.error("Failed to revoke invitation:", error);
      toast.error("Could not revoke invitation.");
    }
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UserIcon className="w-5 h-5" />
            Team Management
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-medium text-gray-800 mb-2">Current Team Members</h3>
            <div className="space-y-2 rounded-lg border p-4">
              {team.length > 0 ? (
                team.map(member => (
                  <div key={member.id} className="flex justify-between items-center">
                    <div>
                      <p className="font-semibold">{member.full_name}</p>
                      <p className="text-sm text-gray-500">{member.email}</p>
                    </div>
                    <Badge variant="outline">{member.role}</Badge>
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-500">No team members yet.</p>
              )}
            </div>
          </div>

          <div>
            <h3 className="font-medium text-gray-800 mb-2">Pending Invitations</h3>
            <div className="space-y-2 rounded-lg border p-4">
              {invitations.filter(i => i.status === 'pending').length > 0 ? (
                invitations.filter(i => i.status === 'pending').map(invite => (
                  <div key={invite.id} className="flex justify-between items-center">
                    <div>
                      <p className="font-semibold">{invite.email}</p>
                      <p className="text-sm text-gray-500">Role: {invite.role}</p>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => handleRevokeInvite(invite.id)}>
                      <Trash2 className="w-4 h-4 text-red-500 mr-2" />
                      Revoke
                    </Button>
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-500">No pending invitations.</p>
              )}
            </div>
          </div>

          <div>
            <h3 className="font-medium text-gray-800 mb-2">Invite New Member</h3>
            <div className="p-4 border rounded-lg bg-gray-50/50 space-y-4">
              <p className="text-sm text-gray-600">
                Your current plan includes {ENTITLEMENTS[company?.plan_tier || 'free'].users_included} team members. Adding more may result in additional charges.
                You currently have {team.length + invitations.filter(i => i.status === 'pending').length} of {ENTITLEMENTS[company?.plan_tier || 'free'].users_included} allowed members (including pending invitations).
              </p>
              <div className="flex flex-col sm:flex-row gap-2">
                <Input
                  placeholder="new.member@example.com"
                  type="email"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  className="flex-1"
                  disabled={inviting}
                />
                <Select value={inviteRole} onValueChange={setInviteRole} disabled={inviting}>
                  <SelectTrigger className="w-full sm:w-[120px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="user">User</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={handleInvite} disabled={inviting || !inviteEmail}>
                  {inviting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Send className="w-4 h-4 mr-2" />}
                  {inviting ? 'Sending...' : 'Send Invite'}
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      <UpsellModal
        open={showUpsell}
        onClose={() => setShowUpsell(false)}
        title="User limit reached"
        body={`You have reached the user limit for the ${company?.plan_tier} plan. Please upgrade to add more team members.`}
        ctaPlan="pro"
      />
    </>
  );
}