/**
 * Utility functions for handling API calls with rate limiting
 */

/**
 * Sleep function for delays
 */
export const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Retry function with exponential backoff
 */
export const retryWithBackoff = async (fn, maxRetries = 3, baseDelay = 1000) => {
  let lastError;
  
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;
      
      // If it's a rate limit error, wait longer
      if (error.message?.includes('Rate limit') || error.response?.status === 429) {
        const delay = baseDelay * Math.pow(2, attempt) + Math.random() * 1000;
        console.warn(`Rate limit hit, retrying in ${Math.round(delay)}ms (attempt ${attempt + 1}/${maxRetries})`);
        await sleep(delay);
        continue;
      }
      
      // For other errors, don't retry
      throw error;
    }
  }
  
  throw lastError;
};

/**
 * Safe entity call with rate limit handling
 */
export const safeEntityCall = async (entityFn, entityName = 'Entity') => {
  return retryWithBackoff(async () => {
    try {
      return await entityFn();
    } catch (error) {
      console.error(`Error calling ${entityName}:`, error);
      throw error;
    }
  });
};

/**
 * Batch load multiple entities with delay to prevent rate limiting
 */
export const batchLoadEntities = async (entityCalls, delayBetween = 200) => {
  const results = [];
  
  for (let i = 0; i < entityCalls.length; i++) {
    try {
      const result = await safeEntityCall(entityCalls[i].fn, entityCalls[i].name);
      results.push({ success: true, data: result, name: entityCalls[i].name });
      
      // Add delay between calls to prevent rate limiting
      if (i < entityCalls.length - 1) {
        await sleep(delayBetween);
      }
    } catch (error) {
      console.error(`Failed to load ${entityCalls[i].name}:`, error);
      results.push({ success: false, error, name: entityCalls[i].name });
    }
  }
  
  return results;
};