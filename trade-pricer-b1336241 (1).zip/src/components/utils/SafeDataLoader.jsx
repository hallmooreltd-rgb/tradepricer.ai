import React, { useState, useEffect } from 'react';
import LoadingSpinner from '../LoadingSpinner';

/**
 * Component for safely loading entity data with error handling
 */
export function SafeEntityLoader({ 
  entityClass, 
  query = {}, 
  sortBy = '', 
  limit = 100, 
  children, 
  onError,
  loadingComponent 
}) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let mounted = true;

    const loadData = async () => {
      if (!entityClass) {
        const err = 'No entity class provided';
        setError(err);
        setLoading(false);
        if (onError) onError(err);
        return;
      }

      try {
        setLoading(true);
        setError(null);

        let result;
        if (Object.keys(query).length > 0) {
          result = await entityClass.filter(query, sortBy, limit);
        } else if (entityClass.list) {
          result = await entityClass.list(sortBy, limit);
        } else {
          result = await entityClass.filter({}, sortBy, limit);
        }

        if (mounted) {
          setData(Array.isArray(result) ? result : []);
        }
      } catch (err) {
        console.error('Error loading entity data:', err);
        if (mounted) {
          const errorMsg = err.message || 'Failed to load data';
          setError(errorMsg);
          setData([]);
          if (onError) onError(errorMsg);
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    loadData();

    return () => {
      mounted = false;
    };
  }, [entityClass, JSON.stringify(query), sortBy, limit]);

  if (loading) {
    return loadingComponent || <LoadingSpinner text="Loading data..." />;
  }

  if (error) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded-md">
        <p className="text-red-600 text-sm">{error}</p>
        <button 
          onClick={() => setLoading(true)}
          className="mt-2 text-red-600 underline hover:no-underline text-xs"
        >
          Try again
        </button>
      </div>
    );
  }

  return children({ data, loading, error, refetch: () => setLoading(true) });
}

/**
 * Component for safely loading a single entity by ID
 */
export function SafeEntityById({ 
  entityClass, 
  id, 
  children, 
  onError,
  loadingComponent 
}) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let mounted = true;

    const loadData = async () => {
      if (!entityClass || !id) {
        const err = 'Entity class and ID are required';
        setError(err);
        setLoading(false);
        if (onError) onError(err);
        return;
      }

      try {
        setLoading(true);
        setError(null);

        let result;
        if (entityClass.get) {
          try {
            result = await entityClass.get(id);
          } catch (getError) {
            console.warn('get() failed, trying filter:', getError);
            const filtered = await entityClass.filter({ id });
            result = filtered && filtered.length > 0 ? filtered[0] : null;
          }
        } else {
          const filtered = await entityClass.filter({ id });
          result = filtered && filtered.length > 0 ? filtered[0] : null;
        }

        if (mounted) {
          setData(result);
        }
      } catch (err) {
        console.error('Error loading entity by ID:', err);
        if (mounted) {
          const errorMsg = err.message || 'Failed to load data';
          setError(errorMsg);
          setData(null);
          if (onError) onError(errorMsg);
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    loadData();

    return () => {
      mounted = false;
    };
  }, [entityClass, id]);

  if (loading) {
    return loadingComponent || <LoadingSpinner text="Loading..." />;
  }

  if (error) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded-md">
        <p className="text-red-600 text-sm">{error}</p>
        <button 
          onClick={() => setLoading(true)}
          className="mt-2 text-red-600 underline hover:no-underline text-xs"
        >
          Try again
        </button>
      </div>
    );
  }

  return children({ data, loading, error, refetch: () => setLoading(true) });
}