/**
 * Safe utility functions for data parsing and handling
 */

export const safeJsonParse = (jsonString, fallback = null) => {
  try {
    if (!jsonString || typeof jsonString !== 'string') {
      return fallback;
    }
    return JSON.parse(jsonString);
  } catch (error) {
    console.warn('Failed to parse JSON:', error);
    return fallback;
  }
};

export const safeJsonStringify = (data, fallback = '[]') => {
  try {
    return JSON.stringify(data);
  } catch (error) {
    console.warn('Failed to stringify data:', error);
    return fallback;
  }
};

export const safeDate = (dateValue) => {
  if (!dateValue) return null;
  try {
    const date = new Date(dateValue);
    return isNaN(date.getTime()) ? null : date;
  } catch (error) {
    console.warn('Failed to parse date:', error);
    return null;
  }
};

export const safeNumber = (value, fallback = 0) => {
  const num = parseFloat(value);
  return isNaN(num) ? fallback : num;
};

export const safeString = (value, fallback = '') => {
  if (value === null || value === undefined) return fallback;
  return String(value);
};