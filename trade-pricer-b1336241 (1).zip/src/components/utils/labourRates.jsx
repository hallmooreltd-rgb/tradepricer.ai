import { Staff } from "@/api/entities";
import { User } from "@/api/entities";

// Load company staff and expose useful lookups
export async function loadCompanyRoleRates() {
  try {
    const me = await User.me();
    if (!me?.company_id) return [];
    
    const list = await Staff.filter({ company_id: me.company_id, active: { $ne: false } }, "role", 500);
    return list
      .filter(s => s.role && s.daily_rate_gbp > 0)
      .map(s => ({ 
        role: s.role.toLowerCase().trim(), 
        daily_rate_gbp: Number(s.daily_rate_gbp),
        name: s.name 
      }));
  } catch (error) {
    console.error('Error loading company role rates:', error);
    return [];
  }
}

// Best-fit lookup: exact role → similar → default
export function pickRateForRole(role, rates, defaults = {}) {
  if (!role) return null;
  
  const key = role.toLowerCase().trim();
  
  // Direct match first
  const direct = rates.find(r => r.role === key);
  if (direct) return direct.daily_rate_gbp;

  // Fuzzy matching for common trade variations
  const fuzzyMap = {
    electrician: ["spark", "electrical", "niceic electrician", "part p electrician", "electrical contractor"],
    plumber: ["plumbing", "gas engineer", "heating engineer", "gas safe engineer", "boiler engineer"],
    roofer: ["roofing", "roof specialist", "roofer & tiler"],
    labourer: ["general labourer", "mate", "apprentice", "trainee"],
    carpenter: ["joiner", "carpentry", "carpenter & joiner", "kitchen fitter"],
    decorator: ["painter", "painter & decorator", "painter and decorator"],
    tiler: ["tiling", "wall & floor tiler", "ceramic tiler"],
    plasterer: ["plastering", "dry liner"]
  };

  // Check if role matches any canonical trade or its aliases
  for (const [canonical, aliases] of Object.entries(fuzzyMap)) {
    if (canonical === key || aliases.some(alias => key.includes(alias) || alias.includes(key))) {
      const match = rates.find(r => r.role === canonical || aliases.some(alias => r.role.includes(alias)));
      if (match) return match.daily_rate_gbp;
    }
  }

  // Check partial matches
  const partialMatch = rates.find(r => 
    r.role.includes(key) || key.includes(r.role)
  );
  if (partialMatch) return partialMatch.daily_rate_gbp;

  // Fall back to defaults if provided
  if (defaults[key] != null) return defaults[key];
  
  return null;
}

// Generate staff rate snippet for AI prompts
export function generateStaffRateSnippet(roleRates) {
  if (!roleRates || roleRates.length === 0) {
    return `No company labour rates provided. Use sensible UK market daily rates:
- Electrician: £220-250/day
- Plumber/Gas Engineer: £200-230/day  
- Carpenter/Joiner: £180-220/day
- Roofer: £170-210/day
- Decorator: £150-180/day
- Labourer: £120-150/day
All rates exclude VAT.`;
  }

  return `Use these company labour daily rates when pricing (all ex VAT):
${roleRates.map(r => `- ${r.role}: £${r.daily_rate_gbp}/day`).join('\n')}

If a specific role is not listed above, use sensible UK market rates for similar trades.`;
}

// Default UK trade rates (fallback)
export const DEFAULT_UK_RATES = {
  electrician: 235,
  plumber: 215,
  "gas engineer": 220,
  "heating engineer": 210,
  carpenter: 200,
  joiner: 200,
  roofer: 190,
  decorator: 165,
  "painter": 160,
  tiler: 175,
  plasterer: 180,
  labourer: 135,
  "general labourer": 130,
  apprentice: 90,
  mate: 120
};