
import { format, parseISO, addDays } from "date-fns";

export async function geocodePostcode(postcode) {
  if (!postcode) return null;
  try {
    const res = await fetch(`https://api.postcodes.io/postcodes/${encodeURIComponent(postcode)}`);
    if (!res.ok) return null;
    const json = await res.json();
    const r = json?.result;
    if (!r) return null;
    return { lat: r.latitude, lon: r.longitude };
  } catch (error) {
    console.error('Geocoding error:', error);
    return null;
  }
}

export async function fetchWeather(lat, lon, dateISO) {
  try {
    const date = format(parseISO(dateISO), "yyyy-MM-dd");
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&timezone=Europe/London&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,weathercode&start_date=${date}&end_date=${date}`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const j = await res.json();
    const tmax = j?.daily?.temperature_2m_max?.[0];
    const tmin = j?.daily?.temperature_2m_min?.[0];
    const prec = j?.daily?.precipitation_sum?.[0] ?? 0;
    const code = j?.daily?.weathercode?.[0];
    const label = mapWeatherCode(code);
    const avg = Math.round(((tmax ?? 0) + (tmin ?? 0)) / 2);
    return { summary: label, temp_c: avg, precipitation_mm: Math.round(prec) };
  } catch (error) {
    console.error('Weather fetch error:', error);
    return null;
  }
}

export async function fetchForecast(lat, lon, days = 5) {
  try {
    const startDate = format(new Date(), "yyyy-MM-dd");
    const endDate = format(addDays(new Date(), days - 1), "yyyy-MM-dd");
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&daily=weathercode,temperature_2m_max,temperature_2m_min&timezone=Europe/London&start_date=${startDate}&end_date=${endDate}`;
    
    const res = await fetch(url);
    if (!res.ok) return null;
    
    const j = await res.json();
    if (!j.daily || !j.daily.time) return null;

    // Zip the arrays from the API into a structured format
    const forecastData = j.daily.time.map((date, index) => ({
      date,
      code: j.daily.weathercode[index],
      temp_max: Math.round(j.daily.temperature_2m_max[index]),
      temp_min: Math.round(j.daily.temperature_2m_min[index]),
    }));
    
    return forecastData;
  } catch (error) {
    console.error('Forecast fetch error:', error);
    return null;
  }
}

function mapWeatherCode(code) {
  const weatherMap = {
    0: "Clear sky",
    1: "Mainly clear",
    2: "Partly cloudy",
    3: "Overcast",
    45: "Fog",
    48: "Depositing rime fog",
    51: "Light drizzle",
    53: "Moderate drizzle",
    55: "Dense drizzle",
    56: "Light freezing drizzle",
    57: "Dense freezing drizzle",
    61: "Light rain",
    63: "Moderate rain",
    65: "Heavy rain",
    66: "Light freezing rain",
    67: "Heavy freezing rain",
    71: "Slight snow",
    73: "Moderate snow",
    75: "Heavy snow",
    77: "Snow grains",
    80: "Rain showers",
    81: "Moderate rain showers",
    82: "Violent rain showers",
    85: "Snow showers",
    86: "Heavy snow showers",
    95: "Thunderstorm",
    96: "Thunderstorm with hail",
    99: "Thunderstorm with heavy hail",
  };
  return weatherMap[code] || "Weather data";
}
