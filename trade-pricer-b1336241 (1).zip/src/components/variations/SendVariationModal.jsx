import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Mail, Loader2 } from "lucide-react";
import { SendEmail } from "@/api/integrations";
import { UploadFile } from "@/api/integrations";
import { buildVariationPdf } from "./buildVariationPdf";
import { Variation } from "@/api/entities";

export default function SendVariationModal({ 
  variation, 
  company, 
  customer, 
  job, 
  onSent, 
  isReminder = false 
}) {
  const [open, setOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const [message, setMessage] = useState(
    isReminder 
      ? `Hi ${customer?.full_name || "there"},\n\nThis is a reminder about the variation for your job: ${job?.title}.\n\nPlease review and approve or reject this variation at your earliest convenience.\n\nThanks!`
      : `Hi ${customer?.full_name || "there"},\n\nPlease find attached the variation for your job: ${job?.title}.\n\nYou can review and approve this online using the link below.\n\nThanks!`
  );

  const handleSend = async () => {
    if (!customer?.email) {
      alert("Customer has no email address.");
      return;
    }

    setSending(true);
    try {
      // Generate PDF
      const pdfBlob = await buildVariationPdf({ company, customer, job, variation });
      
      // Upload PDF to get URL
      const pdfFile = new File([pdfBlob], `${variation.variation_number}.pdf`, { type: 'application/pdf' });
      const { file_url: pdfUrl } = await UploadFile({ file: pdfFile });

      // Create portal URL for approval
      const portalUrl = customer.portal_token 
        ? `${window.location.origin}/portal/${customer.portal_token}/variation?id=${variation.id}`
        : null;

      const emailBody = message + (portalUrl ? `\n\nApprove or reject online: ${portalUrl}` : "");

      // Send email
      await SendEmail({
        to: customer.email,
        from_name: company?.name || "CertiFlow Pro",
        subject: `${isReminder ? "Reminder: " : ""}Variation ${variation.variation_number} - ${job?.title || "Your Job"}`,
        body: emailBody,
      });

      // Update variation status
      if (!isReminder) {
        await Variation.update(variation.id, { status: "sent" });
      }

      alert(`Variation ${isReminder ? "reminder" : ""} sent successfully!`);
      setOpen(false);
      if (onSent) onSent();
    } catch (error) {
      console.error("Failed to send variation:", error);
      alert("Failed to send variation. Please try again.");
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Mail className="w-4 h-4 mr-2" />
          {isReminder ? "Send Reminder" : "Send for Approval"}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {isReminder ? "Send Variation Reminder" : "Send Variation for Approval"}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <p className="text-sm text-gray-600 mb-2">
              To: {customer?.email || "No email address"}
            </p>
          </div>
          <div>
            <Label htmlFor="message">Message</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={6}
              className="mt-1"
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setOpen(false)} disabled={sending}>
              Cancel
            </Button>
            <Button onClick={handleSend} disabled={sending || !customer?.email}>
              {sending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Mail className="w-4 h-4 mr-2" />
                  Send
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}