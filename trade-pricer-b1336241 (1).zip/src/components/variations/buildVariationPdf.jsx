
import jsPDF from "jspdf";
import { format } from "date-fns";
import { drawWatermarkIfNeeded } from "../pdf/watermark";

const gbp = (n) => new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

async function loadImage(src) {
  const el = new Image();
  el.crossOrigin = "anonymous";
  el.referrerPolicy = "no-referrer";
  return new Promise((resolve, reject) => {
    el.onload = () => resolve({ el, width: el.naturalWidth, height: el.naturalHeight });
    el.onerror = reject;
    el.src = src;
  });
}

export async function buildVariationPdf({
  company,
  customer,
  job,
  variation,
}) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });

  let x = 20;
  let y = 16;

  if (company?.logo_url) {
    try {
      const img = await loadImage(company.logo_url);
      const w = 40;
      const r = img.width ? w / img.width : 1;
      const h = img.height ? img.height * r : 16;
      doc.addImage(img.el, "PNG", x, y - 6, w, h);
      x = 65;
    } catch (e) {
      console.error("Could not load image for PDF", e);
    }
  }

  doc.setFontSize(16);
  doc.text(company?.name || "Company", x, y);

  doc.setFontSize(18);
  doc.text("Work Variation", 20, 42);
  doc.setFontSize(11);
  doc.text(`Variation No: ${variation.variation_number}`, 20, 49);
  doc.text(`Date: ${variation.issue_date}`, 20, 55);
  doc.text(`Job: ${job?.title}`, 20, 61);

  const addr = [
    customer?.full_name,
    customer?.address_line1,
    customer?.address_line2,
    [customer?.town_city, customer?.postcode].filter(Boolean).join(" "),
  ].filter(Boolean).join("\n");
  doc.text("Customer:", 130, 42);
  doc.text(addr || "", 130, 49);

  let tableY = 75;
  doc.setFontSize(11);
  doc.text("Description", 20, tableY);
  doc.text("Qty", 100, tableY);
  doc.text("Unit ex VAT", 120, tableY);
  doc.text("VAT", 145, tableY);
  doc.text("Line total", 185, tableY, { align: "right" });
  doc.setLineWidth(0.2);
  doc.line(20, tableY + 2, 190, tableY + 2);

  let yCursor = tableY + 8;
  const items = Array.isArray(variation.items_json) ? variation.items_json : JSON.parse(variation.items_json || '[]');
  items.forEach((it) => {
    const descLines = doc.splitTextToSize(String(it.description || ""), 75);
    const rowH = Math.max(6, descLines.length * 5);
    doc.text(descLines, 20, yCursor);
    doc.text(String(it.quantity || 0), 100, yCursor);
    doc.text(gbp(it.unit_price || 0), 120, yCursor);
    doc.text(`${Number(it.vat_rate || 0)}%`, 145, yCursor);
    const lineTotal = (it.quantity || 0) * (it.unit_price || 0) * (1 + (Number(it.vat_rate || 0) / 100));
    doc.text(gbp(lineTotal), 185, yCursor, { align: "right" });
    yCursor += rowH + 3;
  });

  yCursor += 4;
  doc.setLineWidth(0.2);
  doc.line(120, yCursor, 190, yCursor);
  yCursor += 8;
  doc.setFontSize(13);
  doc.text("Total", 145, yCursor);
  doc.text(gbp(variation.total), 185, yCursor, { align: "right" });

  yCursor += 12;
  doc.setFontSize(11);
  if (variation.notes) {
    doc.text("Notes", 20, yCursor);
    yCursor += 5;
    const lines = doc.splitTextToSize(variation.notes, 170);
    doc.text(lines, 20, yCursor);
  }

  if (variation.status === "approved" && variation.approved_at) {
    yCursor = Math.max(yCursor, 190);
    doc.setLineWidth(0.2);
    doc.line(20, yCursor, 190, yCursor);
    yCursor += 6;
    doc.text(`Approved by: ${variation.approved_by_name}`, 20, yCursor);
    doc.text(`Date: ${format(new Date(variation.approved_at), "d MMM yyyy, h:mm a")}`, 130, yCursor);
    if (variation.approved_by_signature_url) {
      try {
        const sigImg = await loadImage(variation.approved_by_signature_url);
        doc.addImage(sigImg.el, 'PNG', 20, yCursor + 2, 40, 15);
      } catch (e) {
        doc.text("[Signature]", 20, yCursor + 8);
      }
    }
  }

  drawWatermarkIfNeeded(doc, company);
  return doc.output("blob");
}
