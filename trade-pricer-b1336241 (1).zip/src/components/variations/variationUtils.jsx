import { format } from "date-fns";

export const nextVarNo = (companyId) => {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const key = `seq:variation:${companyId}:${y}${m}`;
  const next = Number(localStorage.getItem(key) || "0") + 1;
  localStorage.setItem(key, String(next));
  return `VAR-${y}${m}-${String(next).padStart(5, "0")}`;
};