
import React, { useState, useEffect, useMemo, useCallback } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { User, Company, Customer, Quote } from '@/api/entities';
import { UploadFile } from "@/api/integrations";
import { buildQuotePdfBrowser } from "../components/quotes/buildQuotePdf";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Loader2, Sparkles, FileText, Type, User as UserIcon, AlertCircle, RefreshCw, Plus } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { format, addDays } from 'date-fns';
import { createPageUrl } from '@/utils';
import AiQuoteUploader from '../components/quotes/AiQuoteUploader';
import AiQuoteFromText from '../components/quotes/AiQuoteFromText';
import QuoteItemsEditor from '../components/quotes/QuoteItemsEditor';
import CreateCustomerModal from '../components/quotes/CreateCustomerModal';
import { safeJsonParse, safeJsonStringify } from '../components/utils/SafeDataUtils';
import { safeEntityCall, batchLoadEntities, sleep } from '../components/utils/ApiUtils';

export default function AiQuoteEditor() {
    const navigate = useNavigate();
    const location = useLocation();
    const quoteId = new URLSearchParams(location.search).get("id");
    const isEditing = !!quoteId;

    const [me, setMe] = useState(null);
    const [company, setCompany] = useState(null);
    const [customers, setCustomers] = useState([]);
    const [quote, setQuote] = useState(null);

    const [stage, setStage] = useState(isEditing ? 'editor' : 'select_method');
    
    const [saving, setSaving] = useState(false);
    const [loading, setLoading] = useState(true);
    const [errorMsg, setErrorMsg] = useState("");
    const [retryCount, setRetryCount] = useState(0);
    
    // Form state
    const [selectedCustomerId, setSelectedCustomerId] = useState("");
    const [quoteNumber, setQuoteNumber] = useState('');
    const [issueDate, setIssueDate] = useState(format(new Date(), "yyyy-MM-dd"));
    const [expiryDate, setExpiryDate] = useState(format(addDays(new Date(), 30), "yyyy-MM-dd"));
    const [items, setItems] = useState([]);
    const [scopeOfWork, setScopeOfWork] = useState('');
    const [discountPercent, setDiscountPercent] = useState(0);
    const [notes, setNotes] = useState("");
    const [terms, setTerms] = useState("");
    const [logoOverride, setLogoOverride] = useState("");

    const [isCreateCustomerOpen, setCreateCustomerOpen] = useState(false);
    const [customerPrefill, setCustomerPrefill] = useState({});

    const generateQuoteNumber = useMemo(() => {
        const key = 'seq:ai-quote:' + format(new Date(), 'yyyyMM');
        const next = Number(localStorage.getItem(key) || '0') + 1;
        // Don't update localStorage here, only when saving a new quote
        return `AI-QUO-${format(new Date(), 'yyyyMM')}-${String(next).padStart(5, '0')}`;
    }, []);

    const loadData = async () => {
        try {
            setLoading(true);
            setErrorMsg("");

            // Load user data first
            const user = await safeEntityCall(() => User.me(), 'User');
            setMe(user);

            if (!user?.company_id) {
                setErrorMsg('Your account is not associated with a company.');
                setLoading(false);
                return;
            }

            // Load company and customers with batchLoadEntities for sequential calls with delays
            const entityCalls = [
                {
                    name: 'Company',
                    fn: () => Company.filter({ id: user.company_id })
                },
                {
                    name: 'Customers', 
                    fn: () => Customer.filter({ company_id: user.company_id }, '-created_date', 200)
                }
            ];

            const results = await batchLoadEntities(entityCalls, 300);
            
            // Process results
            const companyResult = results.find(r => r.name === 'Company');
            const customerResult = results.find(r => r.name === 'Customers');

            let fetchedCompany = null;
            if (companyResult?.success) {
                fetchedCompany = companyResult.data[0] || null;
                setCompany(fetchedCompany);
            }

            if (customerResult?.success) {
                setCustomers(customerResult.data || []);
            }

            // Handle editing mode
            if (isEditing) {
                await sleep(200);
                const quotes = await safeEntityCall(() => Quote.filter({ id: quoteId }), 'Quote Fetch');
                const quoteToEdit = quotes[0];
                if (quoteToEdit) {
                    setQuote(quoteToEdit);
                    setSelectedCustomerId(quoteToEdit.customer_id);
                    setQuoteNumber(quoteToEdit.quote_number);
                    setIssueDate(format(new Date(quoteToEdit.issue_date), "yyyy-MM-dd"));
                    setExpiryDate(format(new Date(quoteToEdit.expiry_date), "yyyy-MM-dd"));
                    setItems(safeJsonParse(quoteToEdit.items_json, []));
                    setScopeOfWork(quoteToEdit.scope_of_work || '');
                    setDiscountPercent(quoteToEdit.discount_percent || 0);
                    setNotes(quoteToEdit.notes || "");
                    setTerms(quoteToEdit.terms || fetchedCompany?.default_terms || "");
                    setLogoOverride(quoteToEdit.logo_url || "");
                    setStage('editor');
                } else {
                    setErrorMsg("Quote for editing not found.");
                }
            } else {
                // Set the auto-generated quote number for new quotes
                setQuoteNumber(generateQuoteNumber);
                // Set default terms for new quotes
                setTerms(fetchedCompany?.default_terms || "All prices include VAT unless stated. Quote valid for 30 days. Work scheduled upon deposit payment.");
            }

        } catch (err) {
            console.error('Load data error:', err);
            if (err.message?.includes('Rate limit') || err.response?.status === 429) {
                setErrorMsg('Too many requests. Please wait a moment before trying again.');
            } else {
                setErrorMsg('Failed to load data. Please try again.');
            }
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadData();
    }, [isEditing, quoteId, retryCount]);

    const handleRetry = () => {
        setRetryCount(prev => prev + 1);
    };

    const handleDataExtracted = (data) => {
        setItems(data.items || []);
        setScopeOfWork(data.scopeOfWork || data.scope_of_work || '');
        
        // If AI found an existing customer, auto-select them
        if (data.existingCustomer) {
            setSelectedCustomerId(data.existingCustomer.id);
        }
        
        // Store customer info for potential manual creation, but don't auto-open popup
        if (data.customerInfo && !data.existingCustomer) {
            setCustomerPrefill(data.customerInfo);
        }
        
        setStage('editor');
    };

    const handleCustomerCreated = (newCustomer) => {
        setCustomers(prev => [newCustomer, ...prev]);
        setSelectedCustomerId(newCustomer.id);
        setCreateCustomerOpen(false);
        setCustomerPrefill({}); // Clear prefill data after creating
    };

    const totals = useMemo(() => {
        const subtotal = items.reduce((acc, it) => acc + (it.quantity || 0) * (it.unit_price || 0), 0);
        const vat_total = items.reduce((acc, it) => {
            const line = (it.quantity || 0) * (it.unit_price || 0);
            return acc + line * ((it.vat_rate || 0) / 100);
        }, 0);
        const beforeDiscount = subtotal + vat_total;
        const discount = beforeDiscount * ((discountPercent || 0) / 100);
        const total = beforeDiscount - discount;
        return { subtotal, vat_total, discount, total };
    }, [items, discountPercent]);

    const handleSave = useCallback(async () => {
        setErrorMsg("");
        const errs = [];
        if (!selectedCustomerId) errs.push("Please select or create a customer.");
        if (!scopeOfWork.trim()) errs.push("Scope of work is required.");
        if (errs.length) {
            setErrorMsg(errs.join("\n"));
            window.scrollTo({ top: 0, behavior: "smooth" });
            return;
        }

        setSaving(true);
        try {
            const currentCustomer = customers.find(c => c.id === selectedCustomerId);
            let payload = {
                company_id: me.company_id,
                customer_id: selectedCustomerId,
                quote_number: quoteNumber,
                issue_date: issueDate,
                expiry_date: expiryDate,
                status: 'draft',
                items_json: JSON.stringify(items),
                scope_of_work: scopeOfWork,
                discount_percent: discountPercent || 0,
                notes: notes,
                terms: terms,
                logo_url: logoOverride || company?.logo_url || "",
                subtotal: Number(totals.subtotal.toFixed(2)),
                vat_total: Number(totals.vat_total.toFixed(2)),
                total: Number(totals.total.toFixed(2)),
                pdf_url: ""
            };

            // Generate and upload PDF
            try {
                const pdfBlob = await buildQuotePdfBrowser({
                    company,
                    customer: currentCustomer,
                    quote: payload,
                });
                const { file_url } = await UploadFile({ file: pdfBlob });
                payload.pdf_url = file_url;
            } catch (pdfError) {
                console.error("PDF generation/upload failed, saving quote without it.", pdfError);
                // Optionally notify user that PDF failed but quote was saved
            }

            if (isEditing) {
                await Quote.update(quoteId, payload);
                navigate(createPageUrl(`QuoteDetail?id=${quoteId}`));
            } else {
                const newQuote = await Quote.create(payload);
                navigate(createPageUrl(`QuoteDetail?id=${newQuote.id}`));
            }
        } catch (e) {
            console.error(e);
            if (e.message?.includes('Rate limit') || e.response?.status === 429) {
                setErrorMsg('Rate limit exceeded. Please wait a moment and try again.');
            } else {
                setErrorMsg('Failed to save quote. Please try again.');
            }
        } finally {
            setSaving(false);
        }
    }, [selectedCustomerId, scopeOfWork, items, discountPercent, notes, terms, company, me, logoOverride, issueDate, expiryDate, quoteNumber, totals, isEditing, quoteId, customers, navigate]);

    const gbp = (n) => new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP' }).format(n || 0);

    if (loading) {
        return (
            <div className="p-12 flex flex-col items-center justify-center">
                <Loader2 className="w-8 h-8 animate-spin text-blue-600 mb-4" />
                <p className="text-gray-600 mb-2">Loading Quote Builder...</p>
                <p className="text-sm text-gray-500 text-center">This may take a moment due to API rate limits</p>
            </div>
        );
    }

    if (errorMsg && !me) {
        return (
            <div className="p-8 text-center">
                <Alert variant="destructive" className="max-w-md mx-auto">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription className="mt-2">
                        {errorMsg}
                        <div className="mt-4 flex gap-2 justify-center">
                            <Button onClick={handleRetry} variant="outline" size="sm">
                                <RefreshCw className="w-4 h-4 mr-2" />
                                Try Again
                            </Button>
                            <Button onClick={() => navigate(-1)} size="sm">
                                Go Back
                            </Button>
                        </div>
                    </AlertDescription>
                </Alert>
            </div>
        );
    }

    return (
        <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
            <div className="max-w-5xl mx-auto space-y-6">
                <div className="flex items-center gap-4">
                    <Button variant="outline" size="icon" onClick={() => navigate(-1)}>
                        <ArrowLeft className="w-4 h-4" />
                    </Button>
                    <div>
                        <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">
                            {isEditing ? `Edit AI Quote ${quoteNumber}` : 'New AI-Powered Quote'}
                        </h1>
                        <p className="text-gray-600 mt-1">
                            {isEditing ? "Update the details for this AI-generated quote." : "Generate quotes from PDF drawings or text descriptions."}
                        </p>
                    </div>
                </div>

                {errorMsg && (
                    <Alert variant="destructive" className="border-red-200">
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription>
                            {errorMsg}
                            {(errorMsg.includes('Rate limit') || errorMsg.includes('too many requests')) && (
                                <div className="mt-2">
                                    <Button onClick={handleRetry} variant="outline" size="sm">
                                        <RefreshCw className="w-4 h-4 mr-2" />
                                        Try Again
                                    </Button>
                                </div>
                            )}
                        </AlertDescription>
                    </Alert>
                )}

                {/* Method Selection - Only shown for new quotes at 'select_method' stage */}
                {stage === 'select_method' && !isEditing && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setStage('uploader')}>
                            <CardContent className="p-8 text-center">
                                <FileText className="w-12 h-12 mx-auto text-blue-600 mb-4" />
                                <h3 className="text-xl font-semibold mb-2">Upload PDF Drawing</h3>
                                <p className="text-gray-600">Extract items, quantities, and customer details from architectural drawings or specifications.</p>
                            </CardContent>
                        </Card>
                        <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setStage('text_input')}>
                            <CardContent className="p-8 text-center">
                                <Type className="w-12 h-12 mx-auto text-green-600 mb-4" />
                                <h3 className="text-xl font-semibold mb-2">Describe the Job</h3>
                                <p className="text-gray-600">Simply describe the work. AI will suggest materials, quantities, and pricing.</p>
                            </CardContent>
                        </Card>
                    </div>
                )}

                {/* AI Processing */}
                {stage === 'uploader' && <AiQuoteUploader onComplete={handleDataExtracted} onError={setErrorMsg} companyId={me?.company_id} />}
                {stage === 'text_input' && <AiQuoteFromText onComplete={handleDataExtracted} onError={setErrorMsg} companyId={me?.company_id} />}

                {/* Quote Building */}
                {stage === 'editor' && (
                    <div className="max-w-4xl mx-auto space-y-6">
                        <Card>
                            <CardHeader><CardTitle className="flex items-center gap-2"><UserIcon className="w-5 h-5" />Quote Details</CardTitle></CardHeader>
                            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div className="md:col-span-2 space-y-4">
                                    <div>
                                        <Label>Customer</Label>
                                        <div className="flex gap-2">
                                            <Select value={selectedCustomerId} onValueChange={setSelectedCustomerId} className="flex-1">
                                                <SelectTrigger><SelectValue placeholder="Select customer" /></SelectTrigger>
                                                <SelectContent>
                                                    {customers.map(c => (
                                                        <SelectItem key={c.id} value={c.id}>
                                                            {c.full_name} {c.postcode ? `· ${c.postcode}` : ''}
                                                        </SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                            <Button 
                                                type="button"
                                                variant="outline" 
                                                onClick={() => setCreateCustomerOpen(true)}
                                            >
                                                <Plus className="w-4 h-4 mr-2" />
                                                New Customer
                                            </Button>
                                        </div>
                                    </div>

                                    {/* Show AI-extracted customer info as a helpful hint */}
                                    {customerPrefill.name && !selectedCustomerId && (
                                        <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                                            <div className="flex items-start justify-between gap-4">
                                                <div className="flex-1">
                                                    <p className="text-sm font-medium text-blue-800 mb-1">💡 Customer found in document:</p>
                                                    <div className="text-sm text-blue-700">
                                                        <p><strong>Name:</strong> {customerPrefill.name}</p>
                                                        {customerPrefill.address && <p><strong>Address:</strong> {customerPrefill.address}</p>}
                                                    </div>
                                                </div>
                                                <Button 
                                                    variant="outline" 
                                                    size="sm" 
                                                    onClick={() => setCreateCustomerOpen(true)}
                                                    className="bg-white hover:bg-blue-50 border-blue-300"
                                                >
                                                    <UserIcon className="w-4 h-4 mr-2" />
                                                    Create Customer
                                                </Button>
                                            </div>
                                        </div>
                                    )}

                                    {/* Show confirmation when customer is selected */}
                                    {selectedCustomerId && (
                                        <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                                            <p className="text-sm text-green-800">✅ Customer selected.</p>
                                        </div>
                                    )}
                                </div>
                                <div>
                                    <Label>Quote Number</Label>
                                    <Input 
                                        value={quoteNumber} 
                                        onChange={(e) => setQuoteNumber(e.target.value)}
                                        placeholder="Enter quote number"
                                    />
                                    {!isEditing && (
                                        <p className="text-xs text-gray-500 mt-1">
                                            Auto-generated: {generateQuoteNumber}
                                        </p>
                                    )}
                                </div>
                                <div>
                                    <Label>Issue Date</Label>
                                    <Input type="date" value={issueDate} onChange={e => setIssueDate(e.target.value)} />
                                </div>
                                <div>
                                    <Label>Expiry Date</Label>
                                    <Input type="date" value={expiryDate} onChange={e => setExpiryDate(e.target.value)} />
                                </div>
                                <div className="md:col-span-3">
                                    <Label htmlFor="scope_of_work">Scope of Work</Label>
                                    <Textarea
                                        id="scope_of_work"
                                        placeholder="e.g., Supply and install a new combination boiler, including all necessary pipework and fittings..."
                                        value={scopeOfWork}
                                        onChange={(e) => setScopeOfWork(e.target.value)}
                                        className="h-24"
                                    />
                                </div>
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader><CardTitle className="flex items-center gap-2"><Sparkles className="w-5 h-5" />Quote Items</CardTitle></CardHeader>
                            <CardContent>
                                {!isEditing && <div className="mb-4 p-3 bg-blue-50 rounded-lg"><p className="text-sm text-blue-800">✨ Items extracted and priced using AI. Review and adjust as needed.</p></div>}
                                <QuoteItemsEditor items={items} onChange={setItems} />
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader><CardTitle>Summary</CardTitle></CardHeader>
                            <CardContent className="space-y-4">
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div>
                                        <Label>Discount Percent</Label>
                                        <Input type="number" value={discountPercent} onChange={e => setDiscountPercent(Number(e.target.value))} />
                                    </div>
                                    <div className="md:col-span-2 space-y-2 text-right">
                                        <div className="flex justify-between"><span>Subtotal:</span><span>{gbp(totals.subtotal)}</span></div>
                                        <div className="flex justify-between"><span>VAT:</span><span>{gbp(totals.vat_total)}</span></div>
                                        {discountPercent > 0 && <div className="flex justify-between text-green-600"><span>Discount ({discountPercent}%):</span><span>-{gbp(totals.discount)}</span></div>}
                                        <div className="flex justify-between text-lg font-semibold border-t pt-2"><span>Total:</span><span>{gbp(totals.total)}</span></div>
                                    </div>
                                </div>
                                <div><Label>Notes</Label><Textarea rows={4} value={notes} onChange={e => setNotes(e.target.value)} placeholder="Additional notes for customer" /></div>
                                <div><Label>Terms</Label><Textarea rows={3} value={terms} onChange={e => setTerms(e.target.value)} /></div>
                            </CardContent>
                            <CardFooter className="flex justify-end gap-3">
                                <Button variant="outline" onClick={() => navigate(-1)}>Cancel</Button>
                                <Button onClick={handleSave} disabled={saving} className="bg-blue-600 hover:bg-blue-700">
                                    {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Saving...</> : <>{isEditing ? "Update Quote" : <><Sparkles className="w-4 h-4 mr-2" />Create AI Quote</>}</>}
                                </Button>
                            </CardFooter>
                        </Card>

                        {/* Reset Button */}
                        {!isEditing && (
                            <div className="text-center">
                                <Button variant="outline" onClick={() => { 
                                    setStage('select_method'); 
                                    setItems([]); 
                                    setErrorMsg(''); 
                                    setNotes(''); 
                                    setSelectedCustomerId(''); 
                                    setQuoteNumber(generateQuoteNumber); 
                                    setScopeOfWork(''); 
                                    setCustomerPrefill({}); 
                                    setCreateCustomerOpen(false); 
                                }}>
                                    Start Over
                                </Button>
                            </div>
                        )}
                    </div>
                )}
            </div>

            <CreateCustomerModal 
                isOpen={isCreateCustomerOpen} 
                onClose={() => setCreateCustomerOpen(false)} 
                onCustomerCreated={handleCustomerCreated} 
                companyId={me?.company_id} 
                prefillData={customerPrefill} 
            />
        </div>
    );
}
