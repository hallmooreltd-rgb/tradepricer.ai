
import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, Send, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { agentSDK } from '@/agents';
import MessageBubble from '../components/assistant/MessageBubble';
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { User } from '@/api/entities';
import { Company } from '@/api/entities';

export default function AssistantPage() {
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const [conversation, setConversation] = useState(null);
    const [companyLogo, setCompanyLogo] = useState(null);
    const scrollAreaRef = useRef(null);
    const unsubscribeRef = useRef(null);

    useEffect(() => {
        const setupConversation = async () => {
            try {
                const userData = await User.me();
                if(userData?.company_id) {
                    const companies = await Company.filter({ id: userData.company_id });
                    if (companies?.[0]?.logo_url) {
                        setCompanyLogo(companies[0].logo_url);
                    }
                }

                let existingConv = null;
                const convs = await agentSDK.listConversations({ agent_name: 'manager' });
                
                if (convs && convs.length > 0) {
                    existingConv = convs[0];
                } else {
                    existingConv = await agentSDK.createConversation({
                        agent_name: 'manager',
                        metadata: { name: 'TradePricer Chat' }
                    });
                }
                setConversation(existingConv);
                
                const initialMessages = existingConv.messages || [];
                
                if (initialMessages.length === 0) {
                     setMessages([{
                        role: 'assistant',
                        content: `Hi! I'm your AI assistant for TradePricer. I can help you manage almost anything in your business.

**Here are some things you can ask me to do:**

*   **Customers:** "Create a new customer named Jane Doe." or "Find the phone number for John Smith."
*   **Jobs:** "Schedule a boiler service for Jane Doe next Tuesday."
*   **Quotes & Invoices:** "Draft a quote for a new boiler install at £2500." or "Show me all overdue invoices."
*   **Price Book:** "Add 'Copper Pipe' to my price book at £10 per meter."
*   **Scheduling:** "What's on my schedule for today?"
*   **Financials:** "Log 4 hours of work and £50 in materials for the Smith job."

Just tell me what you need!`
                    }]);
                } else {
                    setMessages(initialMessages);
                }

            } catch (err) {
                console.error('AgentSDK setup failed:', err);
                toast.error("AI Assistant Error", { description: "Could not connect to the assistant. Please try again later." });
                 setMessages([{
                    role: 'assistant',
                    content: `Sorry, I'm having trouble connecting right now.`
                }]);
            }
        };

        setupConversation();

        // Cleanup function
        return () => {
            if (unsubscribeRef.current) {
                unsubscribeRef.current();
            }
        };
    }, []);

    useEffect(() => {
        if (scrollAreaRef.current) {
            scrollAreaRef.current.scrollTo({
                top: scrollAreaRef.current.scrollHeight,
                behavior: 'smooth'
            });
        }
    }, [messages]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!input.trim() || !conversation) return; 

        const userMessage = { role: 'user', content: input.trim() };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setLoading(true);

        try {
            let currentConv = conversation;
            if (!currentConv) {
                currentConv = await agentSDK.createConversation({
                    agent_name: 'manager',
                    metadata: { name: 'TradePricer Chat' }
                });
                setConversation(currentConv);
            }

            // Clean up any existing subscription before adding new message
            if (unsubscribeRef.current) {
                unsubscribeRef.current();
                unsubscribeRef.current = null;
            }

            // Subscribe to updates *before* sending the message
            unsubscribeRef.current = agentSDK.subscribeToConversation(currentConv.id, (data) => {
                if (data.messages && data.messages.length > messages.length) {
                    setMessages(data.messages);
                }
                
                // Check the status of the last assistant message
                const lastMessage = data.messages[data.messages.length - 1];
                if(lastMessage.role === 'assistant' && lastMessage.status === 'completed') {
                    setLoading(false);
                    if(unsubscribeRef.current) {
                        unsubscribeRef.current(); // Unsubscribe once we get a completed response
                        unsubscribeRef.current = null;
                    }
                } else {
                    setLoading(true);
                }
            });

            await agentSDK.addMessage(currentConv, userMessage);
            
        } catch (error) {
            console.error('Error sending message:', error);
            toast.error("Message Error", { description: "Could not send your message. Please check your connection and try again." });
            setLoading(false);
        }
    };

    return (
        <div className="h-screen flex flex-col bg-gray-50 p-4">
            <div className="flex-1 flex flex-col max-w-4xl mx-auto w-full">
                <Card className="flex-1 flex flex-col shadow-lg">
                    <CardHeader className="border-b">
                        <CardTitle className="flex items-center gap-2">
                            <Sparkles className="text-blue-600" />
                            AI Assistant
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="flex-1 p-0">
                        <ScrollArea className="h-[calc(100vh-220px)] p-6" ref={scrollAreaRef}>
                            <div className="space-y-6">
                                {messages.map((message, index) => (
                                    <MessageBubble key={index} message={message} companyLogo={companyLogo} />
                                ))}
                                {loading && messages[messages.length -1].role === 'user' && (
                                    <MessageBubble message={{ role: 'assistant', content: '', tool_calls: [{ status: 'running' }] }} />
                                )}
                            </div>
                        </ScrollArea>
                    </CardContent>
                    <div className="p-4 border-t bg-white">
                        <form onSubmit={handleSubmit} className="flex gap-2">
                            <Textarea
                                value={input}
                                onChange={(e) => setInput(e.target.value)}
                                placeholder="Ask your assistant to do something, e.g. 'Create a new job for John Doe'"
                                className="flex-1"
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter' && !e.shiftKey) {
                                        e.preventDefault();
                                        handleSubmit(e);
                                    }
                                }}
                            />
                            <Button type="submit" disabled={loading || !input.trim()}>
                                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                            </Button>
                        </form>
                    </div>
                </Card>
            </div>
        </div>
    );
}
