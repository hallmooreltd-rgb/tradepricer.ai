
import React, { useEffect, useState } from "react";
import { User, Company } from "@/api/entities";
import { ENTITLEMENTS, PLAN_LABELS } from "../components/billing/plans";
import { ensureUsageMonth } from "../components/billing/usage";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check } from "lucide-react";

// NOTE: This component assumes you have backend functions set up at the specified API routes.
// The base44 platform does not support this by default. You may need to enable backend functions.

export default function Billing(){
  const [me, setMe] = useState(null);
  const [company, setCompany] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState("month");

  useEffect(() => {
    (async () => {
      try {
        const u = await User.me(); 
        setMe(u);
        if (u.company_id) {
            const co = Company.get ? await Company.get(u.company_id) : (await Company.filter({ id: u.company_id }))[0];
            ensureUsageMonth(co);
            setCompany(co);
        }
      } catch (e) {
        console.error("Failed to load billing data", e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const currentTier = company?.plan_tier || "free";
  const plans = ["free", "pro", "premium"];

  const startCheckout = async (tier) => {
    alert("Stripe integration is not fully enabled on this platform. This is a placeholder for checkout.");
    // The code below depends on a backend endpoint which is not standard on the base44 platform.
    /*
    const priceKey = selectedPeriod === "year" ? "year" : "month";
    const res = await fetch("/api/billing/create-checkout-session", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        tier,
        interval: priceKey,
        company_id: company.id,
        success_url: `${window.location.origin}/Billing?success=1`,
        cancel_url: `${window.location.origin}/Billing?cancel=1`,
      })
    }).then(r => r.json());
    if (!res?.url) return alert(res?.error || "Could not start checkout");
    window.location.assign(res.url);
    */
  };

  const openPortal = async () => {
    alert("Stripe integration is not fully enabled on this platform. This is a placeholder for the customer portal.");
    // The code below depends on a backend endpoint which is not standard on the base44 platform.
    /*
    const res = await fetch("/api/billing/create-portal-session", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ company_id: company.id, return_url: `${window.location.origin}/Billing` })
    }).then(r => r.json());
    if (!res?.url) return alert(res?.error || "Could not open portal");
    window.location.assign(res.url);
    */
  };

  if (loading) return <div className="p-8">Loading…</div>;
  if (!company) return <div className="p-8">Could not load company information.</div>;

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-5xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold">Billing</h1>
          <p className="text-gray-600 mt-1">Current plan: <span className="font-semibold">{PLAN_LABELS[currentTier]}</span></p>
        </div>

        <div className="flex gap-2">
          <Button variant={selectedPeriod==="month"?"default":"outline"} onClick={() => setSelectedPeriod("month")}>Monthly</Button>
          <Button variant={selectedPeriod==="year"?"default":"outline"} onClick={() => setSelectedPeriod("year")}>Yearly - 2 months free</Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map(tier => (
            <PlanCard
              key={tier}
              tier={tier}
              current={currentTier===tier}
              highlight={tier==="pro"}
              onSelect={() => {
                if (tier==="free") return;
                if (tier==="pro" || tier==="premium") startCheckout(tier);
              }}
              selectedPeriod={selectedPeriod}
            />
          ))}
        </div>

        {company?.stripe_customer_id ? (
          <div>
            <Button variant="outline" onClick={openPortal}>Manage subscription</Button>
          </div>
        ) : null}
      </div>
    </div>
  );
}

function PlanCard({ tier, current, highlight, onSelect, selectedPeriod }) {
  const e = ENTITLEMENTS[tier];
  const price = tier==="free" ? "Free" :
    tier==="pro" ? (selectedPeriod==="month" ? "£19 per month" : "£190 per year") :
    (selectedPeriod==="month" ? "£39 per month" : "£390 per year");

  const perks = [
    `Users included: ${e.users_included}`,
    `Active jobs: ${e.caps.active_jobs===Infinity ? "unlimited" : e.caps.active_jobs}`,
    `Quotes: ${e.caps.quotes_pm===Infinity ? "unlimited" : e.caps.quotes_pm} per month`,
    `Invoices: ${e.caps.invoices_pm===Infinity ? "unlimited" : e.caps.invoices_pm} per month`,
    `Certificates: ${e.caps.certs_pm===Infinity ? "unlimited" : e.caps.certs_pm} per month`,
    `Variations: ${e.caps.variations_pm===Infinity ? "unlimited" : e.caps.variations_pm} per month`,
    `Reminders: ${e.caps.reminders_pm===Infinity ? "unlimited" : e.caps.reminders_pm} per month`,
    `AI Job Pricer: ${e.caps.ai_runs_pm===Infinity ? "unlimited" : e.caps.ai_runs_pm} runs per month`,
    `Storage: ${e.caps.storage_gb} GB`,
    ...(tier==="premium" ? ["SMS bundle: 100 per month included"] : []),
    ...(e.features.portal_custom_domain ? ["Customer portal: custom domain"] : ["Customer portal: branded"]),
    ...(e.features.integrations_live_sync ? ["Accounting: live sync to Xero or QuickBooks"] : tier==="pro" ? ["Accounting: export file"] : ["No accounting integrations"]),
  ];

  return (
    <Card className={`${highlight ? "ring-2 ring-blue-600" : ""}`}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <span className="capitalize">{tier}</span>
          {current ? <Badge className="bg-blue-50 text-blue-700">Current</Badge> : null}
          {highlight ? <Badge className="bg-amber-50 text-amber-700">Popular</Badge> : null}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="text-2xl font-bold">{price}</div>
        <ul className="mt-4 space-y-2 text-sm text-gray-700">
          {perks.map(p => (
            <li key={p} className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-600" />
              <span>{p}</span>
            </li>
          ))}
        </ul>
        {tier!=="free" && !current ? (
          <Button className="mt-5 w-full bg-blue-600 hover:bg-blue-700" onClick={onSelect}>Choose {tier}</Button>
        ) : null}
      </CardContent>
    </Card>
  );
}
