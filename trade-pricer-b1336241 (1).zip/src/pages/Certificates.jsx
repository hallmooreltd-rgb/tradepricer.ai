
import React, { useState, useEffect } from "react";
import { Certificate, Job, Customer, User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Plus, Search, FileText, ExternalLink, Download, Calendar, User as UserIcon } from "lucide-react";
import { format } from "date-fns";
import { batchLoadEntities } from "../components/utils/ApiUtils";

const templateLabels = {
  boiler_install: "Boiler Installation",
  damp_report: "Damp Report",
  roof_inspection: "Roof Inspection", 
  risk_assessment: "Risk Assessment"
};

export default function Certificates() {
  const [certificates, setCertificates] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [filteredCertificates, setFilteredCertificates] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    filterCertificates();
  }, [certificates, searchTerm]);

  const loadData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      if (userData.company_id) {
        const results = await batchLoadEntities([
          { fn: () => Certificate.filter({ company_id: userData.company_id }, "-created_date", 100), name: "certificates" },
          { fn: () => Job.filter({ company_id: userData.company_id }), name: "jobs" },
          { fn: () => Customer.filter({ company_id: userData.company_id }), name: "customers" }
        ]);

        const certificateData = results.find(r => r.name === 'certificates' && r.success)?.data || [];
        const jobData = results.find(r => r.name === 'jobs' && r.success)?.data || [];
        const customerData = results.find(r => r.name === 'customers' && r.success)?.data || [];
        
        setCertificates(certificateData);
        setJobs(jobData);
        setCustomers(customerData);
      }
    } catch (error) {
      console.error("Error loading certificates:", error);
    }
    setLoading(false);
  };

  const filterCertificates = () => {
    let filtered = certificates;
    
    if (searchTerm) {
      filtered = filtered.filter(cert => 
        cert.certificate_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
        cert.installer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        getCustomerName(cert.job_id).toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    setFilteredCertificates(filtered);
  };

  const getCustomerName = (jobId) => {
    const job = jobs.find(j => j.id === jobId);
    if (!job) return "Unknown";
    const customer = customers.find(c => c.id === job.customer_id);
    return customer?.full_name || "Unknown Customer";
  };

  const getJobTitle = (jobId) => {
    const job = jobs.find(j => j.id === jobId);
    return job?.title || "Unknown Job";
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-48"></div>
            <div className="grid gap-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-32 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Certificates</h1>
            <p className="text-gray-600 mt-1">
              View and manage all issued certificates
            </p>
          </div>
          <Link to={createPageUrl("NewCertificate")}>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              New Certificate
            </Button>
          </Link>
        </div>

        <Card className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="Search by certificate number, installer, or customer..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </Card>

        <div className="space-y-4">
          {filteredCertificates.length === 0 ? (
            <Card className="p-8 text-center">
              <div className="space-y-4 max-w-2xl mx-auto">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto">
                  <FileText className="w-8 h-8 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">About Certificates</h3>
                  <p className="text-gray-600 mb-4 leading-relaxed">
                    Here is where you can create and manage compliance certificates for your completed work. 
                    Certificates provide legal documentation and ensure regulatory compliance.
                  </p>
                  <div className="bg-purple-50 p-4 rounded-lg mb-4">
                    <p className="text-sm text-purple-800 leading-relaxed">
                      <strong>Example scenario:</strong> After installing a new gas boiler, you need to issue a Gas Safety Certificate 
                      to confirm the installation meets safety standards. The certificate includes installation details, 
                      test results, and both customer and installer signatures for legal compliance.
                    </p>
                  </div>
                  {certificates.length === 0 ? (
                    <p className="text-gray-500 mb-4">No certificates issued yet.</p>
                  ) : (
                    <p className="text-gray-500 mb-4">No certificates match your search.</p>
                  )}
                  <Link to={createPageUrl("NewCertificate")}>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Issue Your First Certificate
                    </Button>
                  </Link>
                </div>
              </div>
            </Card>
          ) : (
            filteredCertificates.map((certificate) => (
              <Card key={certificate.id} className="hover:shadow-md transition-shadow duration-200">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0 space-y-3">
                      <div className="flex items-center gap-3 flex-wrap">
                        <h3 className="font-semibold text-lg text-gray-900">
                          {certificate.certificate_number}
                        </h3>
                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                          {templateLabels[certificate.template_key]}
                        </Badge>
                        {certificate.sent_to_customer ? (
                          <Badge className="bg-green-100 text-green-700 border-green-200">
                            Sent to Customer
                          </Badge>
                        ) : (
                          <Badge className="bg-amber-100 text-amber-700 border-amber-200">
                            Not Sent
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex flex-wrap items-center gap-6 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <UserIcon className="w-4 h-4" />
                          <span>{getCustomerName(certificate.job_id)}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          <span>Issued {format(new Date(certificate.issue_date), "MMM d, yyyy")}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4" />
                          <span>{getJobTitle(certificate.job_id)}</span>
                        </div>
                      </div>
                      
                      <div className="text-sm text-gray-600">
                        <span className="font-medium">Installer:</span> {certificate.installer_name}
                        {certificate.installer_credential_type !== 'none' && (
                          <span className="ml-2">
                            ({certificate.installer_credential_type.toUpperCase()}: {certificate.installer_credential_id})
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <div className="ml-4 flex-shrink-0 flex gap-2">
                      {certificate.pdf_url && (
                        <Button variant="outline" size="sm" asChild>
                          <a href={certificate.pdf_url} target="_blank" rel="noopener noreferrer">
                            <Download className="w-4 h-4 mr-2" />
                            Download
                          </a>
                        </Button>
                      )}
                      <Link to={createPageUrl(`Certificate?id=${certificate.id}`)}>
                        <Button variant="outline" size="sm">
                          <ExternalLink className="w-4 h-4 mr-2" />
                          View
                        </Button>
                      </Link>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
