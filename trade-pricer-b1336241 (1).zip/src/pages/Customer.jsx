
import React, { useState, useEffect } from "react";
import { useLocation, Link, useNavigate } from "react-router-dom";
import { Customer, Job, Quote, Invoice } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Edit, Mail, Phone, MapPin, Plus, Briefcase, FileText, Receipt, Sparkles, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { createPageUrl } from "@/utils";

export default function CustomerPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const customerId = new URLSearchParams(location.search).get("id");

  const [customer, setCustomer] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [quotes, setQuotes] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [acceptingQuoteId, setAcceptingQuoteId] = useState(null);

  useEffect(() => {
    if (customerId) {
      loadData();
    }
  }, [customerId]);

  const loadData = async () => {
    try {
      const [customerData, jobsData, quotesData, invoicesData] = await Promise.all([
        Customer.get(customerId),
        Job.filter({ customer_id: customerId }),
        Quote.filter({ customer_id: customerId }),
        Invoice.filter({ customer_id: customerId }),
      ]);
      setCustomer(customerData);
      setJobs(jobsData || []);
      setQuotes(quotesData || []);
      setInvoices(invoicesData || []);
    } catch (error) {
      console.error("Failed to load customer data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleAcceptAndCreateJob = async (quote) => {
    if (!quote) return;
    setAcceptingQuoteId(quote.id);
    try {
      // 1. Mark quote as accepted
      await Quote.update(quote.id, {
        status: 'accepted',
        accepted_at: new Date().toISOString()
      });

      // 2. Create a new job from the quote
      const newJob = await Job.create({
        company_id: quote.company_id,
        customer_id: quote.customer_id,
        quote_id: quote.id,
        job_type: 'other', // Default type, can be changed on edit
        title: `Job from Quote ${quote.quote_number}`,
        status: 'draft',
        notes: quote.scope_of_work,
        scheduled_date: null
      });

      // 3. Navigate to the job editor to schedule it
      navigate(createPageUrl(`NewJob?job_id=${newJob.id}`));

    } catch (error) {
      console.error("Failed to accept quote and create job:", error);
      // Optionally show an error to the user
    } finally {
      setAcceptingQuoteId(null);
    }
  };

  const formatAddress = (c) => {
    if (!c) return 'No address';
    return [c.address_line1, c.address_line2, c.town_city, c.county, c.postcode].filter(Boolean).join(', ');
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-48"></div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 h-64 bg-gray-200 rounded"></div>
            <div className="lg:col-span-2 h-96 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!customer) {
    return (
      <div className="p-8 text-center">
        <h1 className="text-xl">Customer not found</h1>
        <p className="text-gray-500">The customer you are looking for does not exist.</p>
        <Link to={createPageUrl("Customers")}>
          <Button variant="link">Go to Customers List</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Customers")}>
              <Button variant="outline" size="icon">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">{customer.full_name}</h1>
              <p className="text-gray-600">Customer #{customer.customer_number || customer.id}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Link to={createPageUrl(`NewJob?customer_id=${customer.id}`)}>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" /> New Job
              </Button>
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {customer.email && (
                  <div className="flex items-center gap-3">
                    <Mail className="w-4 h-4 text-gray-500" />
                    <span className="text-gray-700">{customer.email}</span>
                  </div>
                )}
                {customer.phone && (
                  <div className="flex items-center gap-3">
                    <Phone className="w-4 h-4 text-gray-500" />
                    <span className="text-gray-700">{customer.phone}</span>
                  </div>
                )}
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-gray-500 mt-1" />
                  <span className="text-gray-700">{formatAddress(customer)}</span>
                </div>
              </CardContent>
            </Card>
            {customer.notes && (
              <Card>
                <CardHeader>
                  <CardTitle>Notes</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 whitespace-pre-wrap">{customer.notes}</p>
                </CardContent>
              </Card>
            )}
          </div>

          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader className="flex flex-row justify-between items-center">
                <CardTitle className="flex items-center gap-2">
                  <Briefcase className="w-5 h-5 text-blue-600" />
                  Jobs
                </CardTitle>
                <Link to={createPageUrl(`NewJob?customer_id=${customer.id}`)}>
                  <Button variant="outline" size="sm">
                    <Plus className="w-3 h-3 mr-2" />
                    New Job
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                {jobs.length > 0 ? (
                  <ul className="divide-y divide-gray-100">
                    {jobs.map(job => (
                      <li key={job.id} className="py-3">
                        <Link to={createPageUrl(`Job?id=${job.id}`)} className="flex justify-between items-center hover:bg-gray-50 p-2 rounded-md">
                          <div>
                            <p className="font-medium text-gray-800">{job.title}</p>
                            <p className="text-sm text-gray-500">
                              {job.scheduled_date ? format(new Date(job.scheduled_date), "MMM d, yyyy") : "Unscheduled"}
                            </p>
                          </div>
                          <Badge 
                            variant={job.status === 'completed' ? 'default' : 'secondary'} 
                            className={`${job.status === 'completed' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}
                          >
                            {job.status}
                          </Badge>
                        </Link>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-gray-500 text-center py-4">No jobs for this customer yet.</p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row justify-between items-center">
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-purple-600" />
                  Quotes
                </CardTitle>
                <Link to={createPageUrl(`QuoteEditor?customer_id=${customer.id}`)}>
                  <Button variant="outline" size="sm">
                    <Plus className="w-3 h-3 mr-2" />
                    New Quote
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                {quotes.length > 0 ? (
                  <ul className="divide-y divide-gray-100">
                    {quotes.map(quote => (
                      <li key={quote.id} className="py-3">
                        <div className="flex justify-between items-center hover:bg-gray-50 p-2 rounded-md">
                          <Link to={createPageUrl(`QuoteDetail?id=${quote.id}`)} className="flex-1">
                            <div>
                              <p className="font-medium text-gray-800">{quote.quote_number}</p>
                              <p className="text-sm text-gray-500">
                                Total: {new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(quote.total)}
                              </p>
                            </div>
                          </Link>
                          <div className="flex items-center gap-2">
                             <Badge 
                              variant={quote.status === 'accepted' ? 'default' : 'secondary'} 
                              className={`${quote.status === 'accepted' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}
                            >
                              {quote.status}
                            </Badge>
                            {['draft', 'sent'].includes(quote.status) && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleAcceptAndCreateJob(quote)}
                                disabled={acceptingQuoteId === quote.id}
                              >
                                {acceptingQuoteId === quote.id ? (
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                ) : (
                                  'Accept & Create Job'
                                )}
                              </Button>
                            )}
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-gray-500 text-center py-4">No quotes for this customer yet.</p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row justify-between items-center">
                <CardTitle className="flex items-center gap-2">
                  <Receipt className="w-5 h-5 text-orange-600" />
                  Invoices
                </CardTitle>
                <Link to={createPageUrl(`NewInvoice?customer_id=${customer.id}`)}>
                  <Button variant="outline" size="sm">
                    <Plus className="w-3 h-3 mr-2" />
                    New Invoice
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                {invoices.length > 0 ? (
                  <ul className="divide-y divide-gray-100">
                    {invoices.map(invoice => (
                      <li key={invoice.id} className="py-3">
                        <Link to={createPageUrl(`InvoiceDetail?id=${invoice.id}`)} className="flex justify-between items-center hover:bg-gray-50 p-2 rounded-md">
                          <div>
                            <p className="font-medium text-gray-800">{invoice.invoice_number}</p>
                            <p className="text-sm text-gray-500">
                              Total: {new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(invoice.total)}
                            </p>
                          </div>
                          <Badge 
                            variant={invoice.status === 'paid' ? 'default' : 'secondary'} 
                            className={`${invoice.status === 'paid' ? 'bg-green-100 text-green-700' : (invoice.status === 'overdue' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-600')}`}
                          >
                            {invoice.status}
                          </Badge>
                        </Link>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-gray-500 text-center py-4">No invoices for this customer yet.</p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
