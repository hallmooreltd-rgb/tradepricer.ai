
import React, { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { Company } from "@/api/entities";
import { Customer } from "@/api/entities";
import { Certificate } from "@/api/entities";
import { Quote } from "@/api/entities";
import { Reminder } from "@/api/entities";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, FileText, ShieldCheck, Download, Phone, Mail, MapPin } from "lucide-react";
import { addDays, format, isValid, parseISO } from "date-fns";
import { buildPortalStickers } from "../components/portal/buildPortalStickers";
import BookingRequestModal from "../components/portal/BookingRequestModal";

export default function CustomerPortal() {
  const { token } = useParams();
  const [loading, setLoading] = useState(true);
  const [company, setCompany] = useState(null);
  const [customer, setCustomer] = useState(null);
  const [certs, setCerts] = useState([]);
  const [quotes, setQuotes] = useState([]);
  const [reminders, setReminders] = useState([]);
  const [bookingOpen, setBookingOpen] = useState(false); // New state
  const [preset, setPreset] = useState({}); // New state

  // Utility to safely parse ISO dates
  const safeDate = (isoStr) => {
    if (!isoStr) return null;
    const d = parseISO(isoStr);
    return isValid(d) ? d : null;
  };

  // Utility to format currency
  const gbp = (amount) => {
    if (typeof amount !== 'number') return '';
    return new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  };

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      try {
        // simple approach: find the customer by the unique token
        const found = await Customer.filter({ portal_token: token }, "", 1);
        if (!mounted) return;
        const c = found?.[0];
        if (!c) {
          setLoading(false);
          return;
        }
        setCustomer(c);

        const co = Company.get ? await Company.get(c.company_id) : (await Company.filter({ id: c.company_id }))[0];
        if (!mounted) return;
        setCompany(co);

        const [cs, qs, rs] = await Promise.all([
          Certificate.filter({ company_id: c.company_id, customer_id: c.id }, "-created_date", 50),
          Quote.filter ? Quote.filter({ company_id: c.company_id, customer_id: c.id }, "-created_date", 50) : Promise.resolve([]),
          Reminder.filter({ company_id: c.company_id, customer_id: c.id, status: "scheduled" }, "due_date", 20),
        ]);
        if (!mounted) return;
        setCerts(cs || []);
        setQuotes(qs || []);
        setReminders(rs || []);

        // mark visit
        try {
          await Customer.update(c.id, {
            portal_visit_count: (c.portal_visit_count || 0) + 1,
            portal_last_seen_at: new Date().toISOString(),
          });
        } catch {
          /* non critical */
        }
      } catch (e) {
        console.error(e);
      } finally {
        if (mounted) setLoading(false);
      }
    };
    if (token) load();
    return () => {
      mounted = false;
    };
  }, [token]);

  // Utility function to map reminder type to service type for booking
  function serviceFromReminder(rt) {
    if (rt === "boiler_service_due") return "boiler_service";
    if (rt === "electrical_followup") return "electrical_inspection";
    if (rt === "roof_followup") return "roof_inspection";
    if (rt === "damp_followup") return "damp_followup";
    return "other"; // Default or fallback service type
  }

  // Utility function to get human-readable label for reminder type
  function labelFromReminder(rt) {
    const map = {
      boiler_service_due: "Boiler service due",
      electrical_followup: "Electrical follow-up",
      roof_followup: "Roof follow-up",
      damp_followup: "Damp follow-up",
      generic: "Follow-up due"
    };
    return map[rt] || "Service due";
  }

  // Utility to format date strings
  const prettyDate = (isoStr) => {
    const d = safeDate(isoStr);
    return d ? format(d, "d MMM yyyy") : "Unknown";
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your documents...</p>
        </div>
      </div>
    );
  }

  if (!customer) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-8">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <h1 className="text-xl font-semibold mb-2">Link not found</h1>
            <p className="text-gray-600">This portal link may have expired or is invalid. Please contact your contractor for a fresh link.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const dueSoon = reminders.filter(r => {
    const d = safeDate(r.due_date);
    if (!d) return false;
    const now = new Date();
    const in30 = addDays(now, 30);
    return d >= now && d <= in30 && r.status === "scheduled";
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-4xl mx-auto px-6 py-8">
          <div className="flex items-center gap-4">
            {company?.logo_url && (
              <img src={company.logo_url} alt="Company logo" className="h-12 w-auto" />
            )}
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                {company?.name || "Service Portal"}
              </h1>
              <p className="text-gray-600">Welcome, {customer.full_name}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8 space-y-8">
        {/* Contact and Address */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Your details
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h3 className="font-medium text-gray-900 mb-2">Property address</h3>
                <p className="text-gray-700">
                  {customer.address_line1}
                  {customer.address_line2 && <><br />{customer.address_line2}</>}
                  <br />
                  {customer.town_city && `${customer.town_city}, `}
                  {customer.postcode}
                </p>
              </div>
              <div>
                <h3 className="font-medium text-gray-900 mb-2">Contact</h3>
                <div className="space-y-1">
                  {customer.phone && (
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-gray-500" />
                      <span className="text-gray-700">{customer.phone}</span>
                    </div>
                  )}
                  {customer.email && (
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-gray-500" />
                      <span className="text-gray-700">{customer.email}</span>
                    </div>
                  )}
                  {company?.phone && (
                    <div className="flex items-center gap-2 pt-2">
                      <Phone className="w-4 h-4 text-blue-600" />
                      <span className="text-blue-700 font-medium">
                        Call us: {company.phone}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Services */}
        {dueSoon.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Services due soon
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {dueSoon.map((r) => (
                  <div key={r.id} className="border rounded-xl p-3 bg-white">
                    <div className="font-medium">{labelFromReminder(r.reminder_type)}</div>
                    <div className="text-sm text-gray-600">Due around {prettyDate(r.due_date)}</div>
                    <Button
                      className="mt-2 w-full"
                      onClick={() => {
                        setPreset({
                          service_type: serviceFromReminder(r.reminder_type),
                          preferred_date: r.due_date,
                        });
                        setBookingOpen(true);
                      }}
                    >
                      Request booking
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Documents */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Your documents
            </CardTitle>
          </CardHeader>
          <CardContent>
            {certs.length === 0 && quotes.length === 0 ? (
              <div className="text-center py-8">
                <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-600">No documents available yet.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {certs.map((cert) => (
                  <div key={cert.id} className="flex items-center justify-between p-4 border rounded-lg bg-white">
                    <div>
                      <div className="font-medium">Certificate {cert.certificate_number}</div>
                      <div className="text-sm text-gray-600">
                        Issued {prettyDate(cert.issue_date)}
                      </div>
                    </div>
                    {cert.pdf_url && (
                      <Button variant="outline" size="sm" asChild>
                        <a href={cert.pdf_url} target="_blank" rel="noopener noreferrer">
                          <Download className="w-4 h-4 mr-2" />
                          Download
                        </a>
                      </Button>
                    )}
                  </div>
                ))}
                {quotes.map((quote) => (
                  <div key={quote.id} className="flex items-center justify-between p-4 border rounded-lg bg-white">
                    <div>
                      <div className="font-medium">Quote {quote.quote_number}</div>
                      <div className="text-sm text-gray-600">
                        {gbp(quote.total)} &bull; Issued {prettyDate(quote.issue_date)}
                      </div>
                    </div>
                    {quote.pdf_url && (
                      <Button variant="outline" size="sm" asChild>
                        <a href={quote.pdf_url} target="_blank" rel="noopener noreferrer">
                          <Download className="w-4 h-4 mr-2" />
                          Download
                        </a>
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            )}
            <div className="pt-4 border-t mt-6">
              <Button
                variant="secondary"
                onClick={() => {
                  setPreset({}); // No specific preset for general request
                  setBookingOpen(true);
                }}
              >
                Request booking
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center text-sm text-gray-500 pt-8">
          <p>Powered by {company?.name || "Service Portal"}</p>
        </div>
      </div>

      <BookingRequestModal
        open={bookingOpen}
        onClose={() => setBookingOpen(false)}
        company={company}
        customer={customer}
        portalToken={customer.portal_token}
        preset={preset}
      />
    </div>
  );
}

// Keeping original helper functions as they might be used elsewhere or planned for future use
// though `titleFromTemplate` is no longer used in current rendering for certs
function titleFromTemplate(t) {
  if (t === "boiler_install") return "Boiler Installation Certificate";
  if (t === "damp_report") return "Damp Proofing Report";
  if (t === "roof_inspection") return "Roofing Inspection Report";
  if (t === "risk_assessment") return "Site Risk Assessment";
  if (t === "electrical_installation") return "Electrical Installation Certificate";
  if (t === "electrical_condition_report") return "Electrical Installation Condition Report";
  return "Document";
}
