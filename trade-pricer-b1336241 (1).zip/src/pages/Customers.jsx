
import React, { useState, useEffect, useCallback } from "react";
import { Customer, User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Plus, Search, User as UserIcon, Mail, Phone, MapPin, Trash2 } from "lucide-react";
import { format } from "date-fns";
import DeleteConfirmationModal from "../components/shared/DeleteConfirmationModal";

export default function Customers() {
  const [customers, setCustomers] = useState([]);
  const [filteredCustomers, setFilteredCustomers] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [deleteCustomerId, setDeleteCustomerId] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const filterCustomers = useCallback(() => {
    let filtered = customers;
    
    if (searchTerm) {
      filtered = filtered.filter(customer => 
        customer.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.phone?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    setFilteredCustomers(filtered);
  }, [customers, searchTerm]);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    filterCustomers();
  }, [filterCustomers]);

  const loadData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      if (userData.company_id) {
        const customerData = await Customer.filter({ company_id: userData.company_id }, "-created_date", 200);
        setCustomers(customerData);
      }
    } catch (error) {
      console.error("Error loading customers:", error);
    }
    setLoading(false);
  };

  const formatAddress = (customer) => {
    const parts = [
      customer.address_line1,
      customer.town_city,
      customer.postcode
    ].filter(Boolean);
    return parts.join(', ') || 'No address';
  };

  const handleDeleteCustomer = async (customerId) => {
    setDeleting(true);
    try {
      await Customer.delete(customerId);
      
      // Remove customer from local state
      setCustomers(prevCustomers => prevCustomers.filter(customer => customer.id !== customerId));
      setDeleteCustomerId(null); // Close the modal
    } catch (error) {
      console.error("Error deleting customer:", error);
      alert("Failed to delete customer. Please try again.");
    } finally {
      setDeleting(false);
    }
  };

  const getCustomerForDeletion = (customerId) => {
    const customer = customers.find(c => c.id === customerId);
    return {
      title: customer?.full_name || "Unknown Customer",
      subtitle: customer?.email || customer?.phone || "No contact info",
      warning: "This customer and all associated jobs, quotes, and certificates will be permanently deleted. This action cannot be undone."
    };
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-48"></div>
            <div className="grid gap-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-32 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Customers</h1>
            <p className="text-gray-600 mt-1">
              Manage your customer database and contact information
            </p>
          </div>
          <Link to={createPageUrl("NewCustomer")}>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              New Customer
            </Button>
          </Link>
        </div>

        <Card className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="Search customers by name, email, or phone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </Card>

        <div className="grid gap-4">
          {customers.length === 0 && !loading ? (
             <Card className="p-8 text-center">
              <div className="space-y-4 max-w-2xl mx-auto">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                  <UserIcon className="w-8 h-8 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">About Customers</h3>
                  <p className="text-gray-600 mb-4 leading-relaxed">
                    This is your digital address book. A well-maintained customer list is key to providing great service, sending timely reminders, and managing your jobs efficiently.
                  </p>
                  <div className="bg-blue-50 p-4 rounded-lg mb-4">
                    <p className="text-sm text-blue-800 leading-relaxed">
                      <strong>Example:</strong> Add a new customer, "Jane Smith," with her address and contact details. Now you can create a quote for her, and if she accepts, all her information will be automatically linked to the new job.
                    </p>
                  </div>
                  <Link to={createPageUrl("NewCustomer")}>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Your First Customer
                    </Button>
                  </Link>
                </div>
              </div>
            </Card>
          ) : filteredCustomers.length === 0 ? (
            <Card className="p-12 text-center text-gray-500">
              No customers match your search.
            </Card>
          ) : (
            filteredCustomers.map((customer) => (
              <Card key={customer.id} className="hover:shadow-md transition-shadow duration-200">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4 flex-1 min-w-0">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-white font-semibold text-lg">
                          {customer.full_name.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      
                      <div className="flex-1 min-w-0 space-y-3">
                        <div>
                          <h3 className="font-semibold text-lg text-gray-900">
                            {customer.full_name}
                          </h3>
                          <p className="text-sm text-gray-500">
                            Added {format(new Date(customer.created_date), "MMM d, yyyy")}
                          </p>
                        </div>
                        
                        <div className="space-y-2">
                          {customer.email && (
                            <div className="flex items-center gap-2 text-sm text-gray-600">
                              <Mail className="w-4 h-4" />
                              <span className="truncate">{customer.email}</span>
                            </div>
                          )}
                          {customer.phone && (
                            <div className="flex items-center gap-2 text-sm text-gray-600">
                              <Phone className="w-4 h-4" />
                              <span>{customer.phone}</span>
                            </div>
                          )}
                          <div className="flex items-center gap-2 text-sm text-gray-600">
                            <MapPin className="w-4 h-4 flex-shrink-0" />
                            <span className="truncate">{formatAddress(customer)}</span>
                          </div>
                        </div>
                        
                        {customer.notes && (
                          <p className="text-sm text-gray-600 truncate">
                            {customer.notes}
                          </p>
                        )}
                      </div>
                    </div>
                    
                    <div className="ml-4 flex-shrink-0 flex gap-2">
                      <Link to={createPageUrl(`Customer?id=${customer.id}`)}>
                        <Button variant="outline" size="sm">
                          View Details
                        </Button>
                      </Link>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setDeleteCustomerId(customer.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Delete Confirmation Modal */}
        {deleteCustomerId && (
          <DeleteConfirmationModal
            isOpen={!!deleteCustomerId}
            onClose={() => setDeleteCustomerId(null)}
            onConfirm={() => handleDeleteCustomer(deleteCustomerId)}
            title="Delete Customer"
            itemDetails={getCustomerForDeletion(deleteCustomerId)}
            isDeleting={deleting}
          />
        )}
      </div>
    </div>
  );
}
