
import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Job, Customer, Certificate, Reminder, User, Company, Invitation } from "@/api/entities";
import { isToday, addDays, startOfDay, parseISO, isValid, format, isAfter, subDays, isSameDay } from "date-fns";
import { batchLoadEntities } from "../components/utils/ApiUtils"; // Import safe loader

import DashboardStats from "../components/dashboard/DashboardStats";
import TodaysJobs from "../components/dashboard/TodaysJobs";
import UpcomingReminders from "../components/dashboard/UpcomingReminders";
import QuickActions from "../components/dashboard/QuickActions";
import CompanySetup from "../components/auth/CompanySetup";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { motion } from "framer-motion";
import {
  CalendarDays, CheckCircle2, Clock, FileText, Users, Briefcase, ChevronRight,
  Sparkles, Bell, CloudRain, Sun, Cloud
} from "lucide-react";
import { geocodePostcode, fetchForecast } from "../components/utils/weather";
import WeatherForecast from "../components/dashboard/WeatherForecast";

// helper to build daily series
function dailySeries(days, items, dateField) {
  const today = startOfDay(new Date());
  return Array.from({ length: days }, (_, i) => {
    const d = subDays(today, days - 1 - i);
    const count = items.filter(it => {
      const raw = it[dateField] || it.created_date || it.updated_at;
      if (!raw) return false;
      const dt = typeof raw === "string" ? parseISO(raw) : new Date(raw);
      return isValid(dt) && isSameDay(dt, d);
    }).length;
    return count;
  });
}

export default function Dashboard() {
  const navigate = useNavigate();
  const [jobs, setJobs] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [certificates, setCertificates] = useState([]);
  const [reminders, setReminders] = useState([]);
  const [user, setUser] = useState(null);
  const [company, setCompany] = useState(null);
  const [loading, setLoading] = useState(true);
  const [needsSetup, setNeedsSetup] = useState(false);
  const [forecast, setForecast] = useState(null);

  useEffect(() => {
    let mounted = true;
    const loadData = async () => {
      try {
        const userData = await User.me();
        if (!mounted) return;
        setUser(userData);

        if (!userData.company_id) {
          const pendingInvites = await Invitation.filter({ email: userData.email, status: "pending" });
          if (!mounted) return;

          if (pendingInvites.length > 0) {
            const invite = pendingInvites[0];
            await User.updateMyUserData({ company_id: invite.company_id, role: invite.role });
            await Invitation.update(invite.id, { status: "accepted" });
            window.location.reload();
            return;
          }

          setNeedsSetup(true);
          setLoading(false);
          return;
        }

        const entityCalls = [
          { fn: () => Job.filter({ company_id: userData.company_id }, "-created_date", 100), name: "jobs" },
          { fn: () => Customer.filter({ company_id: userData.company_id }, "-created_date", 200), name: "customers" },
          { fn: () => Certificate.filter({ company_id: userData.company_id }, "-created_date", 100), name: "certificates" },
          { fn: () => Reminder.filter({ company_id: userData.company_id }, "due_date", 200), name: "reminders" },
          { fn: () => Company.filter({ id: userData.company_id }), name: "company" }
        ];

        const results = await batchLoadEntities(entityCalls);
        if (!mounted) return;

        const jobData = results.find(r => r.name === 'jobs' && r.success)?.data || [];
        const customerData = results.find(r => r.name === 'customers' && r.success)?.data || [];
        const certificateData = results.find(r => r.name === 'certificates' && r.success)?.data || [];
        const reminderData = results.find(r => r.name === 'reminders' && r.success)?.data || [];
        const companyDataMaybe = results.find(r => r.name === 'company' && r.success)?.data || [];

        setJobs(jobData);
        setCustomers(customerData);
        setCertificates(certificateData);
        setReminders(reminderData);
        setCompany(companyDataMaybe[0] || null);

      } catch (error) {
        console.error("Error loading dashboard data:", error);
        if (mounted && error.message?.includes("Row level security")) {
          const userData = await User.me();
          if (!userData.company_id) {
            setNeedsSetup(true);
          }
        }
      } finally {
        if (mounted) setLoading(false);
      }
    };
    loadData();
    return () => { mounted = false; };
  }, []);

  useEffect(() => {
    if (company?.postcode) {
      const loadWeather = async () => {
        try {
          const coords = await geocodePostcode(company.postcode);
          if (coords) {
            const forecastData = await fetchForecast(coords.lat, coords.lon, 5);
            setForecast(forecastData);
          }
        } catch (e) {
          console.error("Failed to load weather forecast", e);
        }
      };
      loadWeather();
    }
  }, [company]);

  const safeDate = (value) => {
    if (!value) return null;
    const d = typeof value === "string" ? parseISO(value) : new Date(value);
    return isValid(d) ? d : null;
  };

  const todaysJobs = useMemo(() => {
    return jobs
      .filter(j => {
        const d = safeDate(j.scheduled_date);
        return d ? isToday(d) : false;
      })
      .sort((a, b) => {
        const da = safeDate(a.scheduled_date)?.getTime() ?? 0;
        const db = safeDate(b.scheduled_date)?.getTime() ?? 0;
        return da - db;
      });
  }, [jobs]);

  const weekWindow = useMemo(() => {
    const start = startOfDay(new Date());
    const end = addDays(start, 6);
    const count = jobs.filter(j => {
      const d = safeDate(j.scheduled_date);
      return d && d >= start && d <= end;
    }).length;
    return { start, end, count };
  }, [jobs]);

  const upcomingReminders = useMemo(() => {
    const today = startOfDay(new Date());
    const in31 = addDays(today, 31);
    return reminders
      .filter(r => {
        if (r.status !== "scheduled") return false;
        const d = safeDate(r.due_date);
        return !!d && d >= today && d <= in31;
      })
      .sort((a, b) => {
        const da = safeDate(a.due_date)?.getTime() ?? 0;
        const db = safeDate(b.due_date)?.getTime() ?? 0;
        return da - db;
      })
      .slice(0, 5);
  }, [reminders]);

  const activity = useMemo(() => {
    const recentJobs = jobs
      .slice(0, 50)
      .map(j => ({ type: "job", id: j.id, title: j.title, date: safeDate(j.updated_at || j.created_date) || new Date() }));
    const recentCerts = certificates
      .slice(0, 50)
      .map(c => ({ type: "cert", id: c.id, title: c.certificate_number || c.template_key, date: safeDate(c.issue_date) || new Date() }));
    const list = [...recentJobs, ...recentCerts]
      .filter(i => isValid(i.date))
      .sort((a, b) => (isAfter(a.date, b.date) ? -1 : 1))
      .slice(0, 10);
    return list;
  }, [jobs, certificates]);

  const monthStart = subDays(startOfDay(new Date()), new Date().getDate() - 1);
  const monthIssued = certificates.filter(c => {
    const d = safeDate(c.issue_date);
    return d && d >= monthStart;
  }).length;

  const stats = useMemo(() => ({
    totalJobs: jobs.length,
    completedJobs: jobs.filter(j => j.status === "completed").length,
    totalCustomers: customers.length,
    certificatesIssued: certificates.length,
    pendingReminders: reminders.filter(r => r.status === "scheduled").length,
    monthIssued
  }), [jobs, customers, certificates, reminders, monthIssued]);

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-48"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-24 bg-gray-200 rounded"></div>
              ))}
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 h-64 bg-gray-200 rounded"></div>
              <div className="h-64 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (needsSetup) {
    return <CompanySetup onComplete={() => window.location.reload()} />;
  }

  const jobsTrend = dailySeries(14, jobs, "scheduled_date");
  const customersTrend = dailySeries(14, customers, "created_date");
  const certificatesTrend = dailySeries(14, certificates, "issue_date");
  const remindersTrend = dailySeries(14, reminders, "due_date");

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-8">
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-700 text-white"
        >
          <div className="p-6 lg:p-8">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div className="flex items-center gap-4">
                {company?.logo_url && (
                  <img
                    src={company.logo_url}
                    alt={company.name ? `${company.name} Logo` : 'Company Logo'}
                    className="h-16 w-16 rounded-lg object-contain bg-white p-1 shadow-md"
                  />
                )}
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <QuickActions />
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-6">
              <GradientStat icon={<Briefcase className="w-4 h-4" />} label="Jobs" value={stats.totalJobs} sub={`${stats.completedJobs} completed`} />
              <GradientStat icon={<Users className="w-4 h-4" />} label="Customers" value={stats.totalCustomers} sub="Active contacts" />
              <GradientStat icon={<FileText className="w-4 h-4" />} label="Certificates" value={stats.certificatesIssued} sub={`${stats.monthIssued} this month`} />
              <GradientStat icon={<Bell className="w-4 h-4" />} label="Reminders" value={stats.pendingReminders} sub="Scheduled" />
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-2 text-sm">
              <CalendarDays className="w-4 h-4" />
              <span className="opacity-90">
                This week: <b>{weekWindow.count}</b> scheduled job{weekWindow.count === 1 ? "" : "s"}
              </span>
            </div>
          </div>
          <div className="pointer-events-none absolute -top-10 -right-10 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
          <div className="pointer-events-none absolute -bottom-12 -left-12 h-48 w-48 rounded-full bg-white/10 blur-2xl" />
        </motion.div>

        <DashboardStats
          stats={stats}
          trends={{ jobsTrend, customersTrend, certificatesTrend, remindersTrend }}
        />

        <div className="grid grid-cols-1 xl:xl:grid-cols-3 gap-6">
          <div className="xl:col-span-2 space-y-6">
            <Card className="shadow-sm">
              <CardHeader className="flex items-center justify-between flex-row">
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-blue-600" />
                  Today
                </CardTitle>
                <Button variant="outline" size="sm" onClick={() => navigate(createPageUrl("NewJob"))}>
                  New job
                </Button>
              </CardHeader>
              <CardContent>
                {todaysJobs.length === 0 ? (
                  <EmptyState
                    icon={<Sun className="w-5 h-5" />}
                    title="No jobs scheduled today"
                    text="Add a job or reschedule from the Jobs page."
                    actionLabel="Create a job"
                    onAction={() => navigate(createPageUrl("NewJob"))}
                  />
                ) : (
                  <TodaysJobs jobs={todaysJobs} customers={customers} />
                )}
              </CardContent>
            </Card>

            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-blue-600" />
                  Recent activity
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {activity.length === 0 ? (
                  <EmptyState
                    icon={<Cloud className="w-5 h-5" />}
                    title="Nothing to show yet"
                    text="Create a quote or issue a certificate to see activity here."
                    actionLabel="New certificate"
                    onAction={() => navigate(createPageUrl("NewCertificate"))}
                  />
                ) : (
                  activity.map(a => (
                    <div key={`${a.type}-${a.id}`} className="flex items-center justify-between border rounded-lg p-3 bg-white hover:bg-gray-50 transition">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-blue-50 text-blue-700 flex items-center justify-center">
                          {a.type === "job" ? <Briefcase className="w-4 h-4" /> : <FileText className="w-4 h-4" />}
                        </div>
                        <div>
                          <div className="font-medium text-gray-900">
                            {a.type === "job" ? "Job updated" : "Certificate issued"}
                          </div>
                          <div className="text-sm text-gray-600">
                            {a.title}
                          </div>
                        </div>
                      </div>
                      <div className="text-sm text-gray-500">{format(a.date, "d MMM, HH:mm")}</div>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="shadow-sm">
              <CardHeader className="flex items-center justify-between flex-row">
                <CardTitle className="flex items-center gap-2">
                  <Bell className="w-5 h-5 text-blue-600" />
                  Upcoming reminders
                </CardTitle>
                <Button variant="outline" size="sm" onClick={() => navigate(createPageUrl("Reminders"))}>
                  View all
                </Button>
              </CardHeader>
              <CardContent>
                {upcomingReminders.length === 0 ? (
                  <EmptyState
                    icon={<CloudRain className="w-5 h-5" />}
                    title="No reminders due"
                    text="Schedule reminders from certificates and invoices."
                    actionLabel="Create reminder"
                    onAction={() => navigate(createPageUrl("Reminders"))}
                  />
                ) : (
                  <UpcomingReminders reminders={upcomingReminders} customers={customers} />
                )}
              </CardContent>
            </Card>

            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-blue-600" />
                  This month's progress
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ProgressRow label="Certificates issued" value={stats.monthIssued} target={30} />
                <div className="mt-3">
                  <Button variant="outline" className="w-full" onClick={() => navigate(createPageUrl("NewCertificate"))}>
                    Issue a certificate <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        
        <WeatherForecast forecast={forecast} location={company?.town_city || company?.postcode} />
      </div>
    </div>
  );
}

function GradientStat({ icon, label, value, sub }) {
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
      <div className="rounded-xl bg-white/10 backdrop-blur-sm p-3 ring-1 ring-white/15 shadow-sm">
        <div className="flex items-center justify-between text-white">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-white/15 flex items-center justify-center">{icon}</div>
            <span className="text-sm opacity-90">{label}</span>
          </div>
          <div className="text-lg font-semibold">{value}</div>
        </div>
        {sub ? <div className="mt-1 text-xs text-white/80">{sub}</div> : null}
      </div>
    </motion.div>
  );
}

function EmptyState({ icon, title, text, actionLabel, onAction }) {
  return (
    <div className="flex flex-col items-center justify-center text-center p-8 border rounded-lg bg-gray-50">
      <div className="w-10 h-10 rounded-full bg-white text-blue-700 flex items-center justify-center shadow">{icon}</div>
      <div className="mt-3 font-medium text-gray-900">{title}</div>
      <div className="mt-1 text-gray-600">{text}</div>
      {actionLabel && onAction ? (
        <Button variant="outline" className="mt-4" onClick={onAction}>{actionLabel}</Button>
      ) : null}
    </div>
  );
}

function ProgressRow({ label, value, target }) {
  const pct = Math.min(100, Math.round((value / target) * 100));
  return (
    <div>
      <div className="flex items-center justify-between text-sm">
        <div className="text-gray-700">{label}</div>
        <div className="text-gray-500">{value} of {target}</div>
      </div>
      <Progress value={pct} className="mt-1" />
    </div>
  );
}
