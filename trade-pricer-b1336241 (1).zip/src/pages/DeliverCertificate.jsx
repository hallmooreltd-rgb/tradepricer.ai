import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Certificate, Job, Customer, User } from "@/api/entities";
import { SendEmail } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, Send, Mail, MessageSquare } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function DeliverCertificate() {
  const navigate = useNavigate();
  const location = useLocation();
  const urlParams = new URLSearchParams(location.search);
  const certificateId = urlParams.get("id");

  const [certificate, setCertificate] = useState(null);
  const [customer, setCustomer] = useState(null);
  const [deliveryChannel, setDeliveryChannel] = useState("email");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [attachPdf, setAttachPdf] = useState(true);
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!certificateId) {
      navigate(createPageUrl("Certificates"));
      return;
    }
    loadData();
  }, [certificateId]);

  const loadData = async () => {
    try {
      const certs = await Certificate.filter({ id: certificateId });
      if (certs.length === 0) {
        navigate(createPageUrl("Certificates"));
        return;
      }
      const cert = certs[0];
      setCertificate(cert);

      const jobs = await Job.filter({ id: cert.job_id });
      if (jobs.length > 0) {
        const customers = await Customer.filter({ id: jobs[0].customer_id });
        if (customers.length > 0) {
          const cust = customers[0];
          setCustomer(cust);
          setEmail(cust.email || "");
          setPhone(cust.phone || "");
        }
      }
    } catch (error) {
      console.error("Error loading delivery data:", error);
    }
    setLoading(false);
  };

  const handleSend = async () => {
    setSending(true);
    try {
      // Logic for sending email/SMS would go here.
      // For now, we'll simulate it.
      if (deliveryChannel.includes("email") && email) {
        await SendEmail({
          to: email,
          subject: `Your Certificate: ${certificate.certificate_number}`,
          body: `Hi ${customer.full_name},\n\nPlease find your certificate attached.\n\nCertificate Number: ${certificate.certificate_number}\n\nPDF: ${certificate.pdf_url || 'Generation in progress.'}\n\nThanks,`
        });
      }
      
      await Certificate.update(certificateId, { sent_to_customer: true });
      navigate(createPageUrl("Certificates"));
      
    } catch (error) {
      console.error("Error sending certificate:", error);
      alert("Failed to send certificate.");
    } finally {
      setSending(false);
    }
  };

  if (loading) {
    return <div className="p-8 text-center">Loading delivery options...</div>;
  }

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Deliver Certificate</h1>
            <p className="text-gray-600 mt-1">Send certificate {certificate?.certificate_number} to the customer.</p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Delivery Options</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label>Delivery Channel</Label>
              <RadioGroup value={deliveryChannel} onValueChange={setDeliveryChannel} className="flex gap-4 pt-2">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="email" id="email" />
                  <Label htmlFor="email" className="flex items-center gap-2"><Mail className="w-4 h-4" /> Email</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="sms" id="sms" />
                  <Label htmlFor="sms" className="flex items-center gap-2"><MessageSquare className="w-4 h-4" /> SMS</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="email_and_sms" id="both" />
                  <Label htmlFor="both">Both</Label>
                </div>
              </RadioGroup>
            </div>
            
            {deliveryChannel.includes("email") && (
              <div>
                <Label htmlFor="customer-email">Customer Email</Label>
                <Input id="customer-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
            )}
            
            {deliveryChannel.includes("sms") && (
              <div>
                <Label htmlFor="customer-phone">Customer Phone</Label>
                <Input id="customer-phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
              </div>
            )}
            
            <div>
              <Label>Message Preview</Label>
              <div className="p-4 border rounded-md text-sm text-gray-600 bg-gray-50 h-32 overflow-auto">
                <p>Hi {customer?.full_name},</p>
                <p className="mt-2">Please find your certificate attached from your recent work.</p>
                <p className="mt-2">Thanks,</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox id="attach-pdf" checked={attachPdf} onCheckedChange={setAttachPdf} />
              <Label htmlFor="attach-pdf">Attach PDF to message</Label>
            </div>
          </CardContent>
          <CardFooter className="p-6 flex justify-end">
            <Button onClick={handleSend} disabled={sending} size="lg" className="bg-green-600 hover:bg-green-700">
              {sending ? "Sending..." : "Send to Customer"}
              <Send className="w-4 h-4 ml-2" />
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}