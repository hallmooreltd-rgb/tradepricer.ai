
import React, { useState, useEffect, useCallback } from "react";
import { SiteDiary, Job, Customer, User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Plus, Search, Calendar, Users, User as UserIcon, MapPin, Briefcase } from "lucide-react";
import { format } from "date-fns";
import WeatherBadge from "../components/diary/WeatherBadge";

export default function Diaries() {
  const [diaries, setDiaries] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [filteredDiaries, setFilteredDiaries] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const getJobTitle = useCallback((jobId) => {
    const job = jobs.find(j => j.id === jobId);
    return job?.title || "Unknown Job";
  }, [jobs]);

  const getCustomerName = useCallback((customerId) => {
    const customer = customers.find(c => c.id === customerId);
    return customer?.full_name || "Unknown Customer";
  }, [customers]);

  const filterDiaries = useCallback(() => {
    let filtered = diaries;
    
    if (searchTerm) {
      filtered = filtered.filter(diary => {
        const job = getJobTitle(diary.job_id);
        const customer = getCustomerName(diary.customer_id);
        return (
          job.toLowerCase().includes(searchTerm.toLowerCase()) ||
          customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
          diary.notes?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          diary.postcode?.toLowerCase().includes(searchTerm.toLowerCase())
        );
      });
    }
    
    setFilteredDiaries(filtered);
  }, [diaries, searchTerm, getJobTitle, getCustomerName]); // Added getJobTitle and getCustomerName to dependencies

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    filterDiaries();
  }, [filterDiaries]); // Changed dependencies to filterDiaries

  const loadData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      if (userData.company_id) {
        const [diaryData, jobData, customerData] = await Promise.all([
          SiteDiary.filter({ company_id: userData.company_id }, "-date"),
          Job.filter({ company_id: userData.company_id }),
          Customer.filter({ company_id: userData.company_id })
        ]);
        
        setDiaries(diaryData || []);
        setJobs(jobData || []);
        setCustomers(customerData || []);
      }
    } catch (error) {
      console.error("Error loading diaries:", error);
    }
    setLoading(false);
  };

  const getTotalHours = (labour) => {
    if (!labour || !Array.isArray(labour)) return 0;
    return labour.reduce((sum, worker) => sum + (Number(worker.hours) || 0), 0);
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-48"></div>
            <div className="grid gap-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-32 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Site Diaries</h1>
            <p className="text-gray-600 mt-1">
              Keep a daily log of site activities, weather, and progress
            </p>
          </div>
          <Link to={createPageUrl("NewDiary")}>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              New Diary Entry
            </Button>
          </Link>
        </div>

        <Card className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="Search diaries by job, customer, notes, or location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </Card>

        <div className="space-y-4">
           {diaries.length === 0 && !loading ? (
             <Card className="p-8 text-center">
              <div className="space-y-4 max-w-2xl mx-auto">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                  <Calendar className="w-8 h-8 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">About Site Diaries</h3>
                  <p className="text-gray-600 mb-4 leading-relaxed">
                    A site diary is a crucial record of daily events on a job. It helps you document progress, track labour, note delays, and protect yourself in case of disputes.
                  </p>
                  <div className="bg-blue-50 p-4 rounded-lg mb-4">
                    <p className="text-sm text-blue-800 leading-relaxed">
                      <strong>Example:</strong> For your "Kitchen Refurbishment" job, you create a diary entry for today. You log 2 labourers for 8 hours each, note that the plasterer was delayed, and upload a photo of the completed first-fix electrics. The weather is automatically recorded.
                    </p>
                  </div>
                  <Link to={createPageUrl("NewDiary")}>
                    <Button className="bg-blue-600 hover:bg-blue-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Create Your First Diary Entry
                    </Button>
                  </Link>
                </div>
              </div>
            </Card>
          ) : filteredDiaries.length === 0 ? (
            <Card className="p-12 text-center text-gray-500">
              No diary entries match your filters.
            </Card>
          ) : (
            filteredDiaries.map((diary) => (
              <Card key={diary.id} className="hover:shadow-md transition-shadow duration-200">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0 space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-semibold text-lg text-gray-900">
                            {getJobTitle(diary.job_id)}
                          </h3>
                          <p className="text-sm text-gray-500">
                            {getCustomerName(diary.customer_id)}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-gray-900">
                            {format(new Date(diary.date), "MMM d, yyyy")}
                          </p>
                          <p className="text-sm text-gray-500">
                            {format(new Date(diary.date), "EEEE")}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap items-center gap-4">
                        {diary.postcode && (
                          <div className="flex items-center gap-1 text-sm text-gray-600">
                            <MapPin className="w-4 h-4" />
                            <span>{diary.postcode}</span>
                          </div>
                        )}
                        
                        {diary.labour && diary.labour.length > 0 && (
                          <div className="flex items-center gap-1 text-sm text-gray-600">
                            <Users className="w-4 h-4" />
                            <span>{diary.labour.length} workers • {getTotalHours(diary.labour)} hours</span>
                          </div>
                        )}
                        
                        {diary.weather && diary.weather.summary && (
                          <WeatherBadge weather={diary.weather} />
                        )}
                      </div>
                      
                      {diary.notes && (
                        <p className="text-gray-600 text-sm line-clamp-2">
                          {diary.notes}
                        </p>
                      )}
                    </div>
                    
                    <div className="ml-4 flex-shrink-0">
                      <Link to={createPageUrl(`DiaryDetail?id=${diary.id}`)}>
                        <Button variant="outline" size="sm">
                          View Details
                        </Button>
                      </Link>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
