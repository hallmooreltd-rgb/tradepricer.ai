import React, { useEffect, useState } from "react";
import { useLocation, Link } from "react-router-dom";
import { SiteDiary, Job, Customer, Company, User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Download, Edit, Calendar, Users, MapPin } from "lucide-react";
import WeatherBadge from "../components/diary/WeatherBadge";
import { format } from "date-fns";
import { createPageUrl } from "@/utils";
import jsPDF from "jspdf";
import { drawWatermarkIfNeeded } from "../components/pdf/watermark";

export default function DiaryDetail() {
  const location = useLocation();
  const id = new URLSearchParams(location.search).get("id");
  
  const [diary, setDiary] = useState(null);
  const [job, setJob] = useState(null);
  const [customer, setCustomer] = useState(null);
  const [company, setCompany] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      loadData();
    }
  }, [id]);

  const loadData = async () => {
    try {
      const diaryData = await SiteDiary.get(id);
      setDiary(diaryData);

      // Load related data
      const [jobData, customerData, userData] = await Promise.all([
        Job.get ? Job.get(diaryData.job_id).catch(() => Job.filter({ id: diaryData.job_id })[0]) : Job.filter({ id: diaryData.job_id })[0],
        Customer.get ? Customer.get(diaryData.customer_id).catch(() => Customer.filter({ id: diaryData.customer_id })[0]) : Customer.filter({ id: diaryData.customer_id })[0],
        User.me()
      ]);

      setJob(jobData);
      setCustomer(customerData);

      if (userData.company_id) {
        const companyData = await Company.filter({ id: userData.company_id });
        setCompany(companyData[0] || null);
      }
    } catch (error) {
      console.error("Error loading diary:", error);
    } finally {
      setLoading(false);
    }
  };

  const downloadPdf = async () => {
    if (!diary || !job || !company) return;

    const doc = new jsPDF({ unit: "pt", format: "a4" });
    let y = 60;

    // Header
    doc.setFontSize(18);
    doc.text("Site Diary", 40, y);
    y += 30;

    doc.setFontSize(12);
    doc.text(`Company: ${company.name || ""}`, 40, y);
    y += 20;
    doc.text(`Job: ${job.title || ""}`, 40, y);
    y += 16;
    doc.text(`Customer: ${customer?.full_name || ""}`, 40, y);
    y += 16;
    doc.text(`Date: ${format(new Date(diary.date), "dd/MM/yyyy")}`, 40, y);
    y += 16;
    
    if (diary.postcode) {
      doc.text(`Postcode: ${diary.postcode}`, 40, y);
      y += 16;
    }

    // Draw line
    y += 8;
    doc.line(40, y, 555, y);
    y += 20;

    // Weather
    if (diary.weather && diary.weather.summary) {
      doc.setFontSize(14);
      doc.text("Weather", 40, y);
      y += 18;
      
      doc.setFontSize(12);
      const w = diary.weather;
      const weatherText = `${w.summary} • ${w.temp_c}°C${w.precipitation_mm ? ` • ${w.precipitation_mm}mm` : ""}`;
      doc.text(weatherText, 40, y);
      y += 20;
      
      doc.line(40, y, 555, y);
      y += 20;
    }

    // Labour
    doc.setFontSize(14);
    doc.text("Labour", 40, y);
    y += 18;
    
    doc.setFontSize(12);
    const labour = diary.labour || [];
    if (labour.length > 0) {
      labour.forEach(worker => {
        const workerText = `• ${worker.name || "Operative"}${worker.role ? ` (${worker.role})` : ""} — ${worker.hours} hours`;
        doc.text(workerText, 40, y);
        y += 16;
      });
      
      const totalHours = labour.reduce((sum, w) => sum + (Number(w.hours) || 0), 0);
      y += 8;
      doc.text(`Total Hours: ${totalHours}`, 40, y);
      y += 20;
    } else {
      doc.text("No labour recorded", 40, y);
      y += 20;
    }

    doc.line(40, y, 555, y);
    y += 20;

    // Notes
    doc.setFontSize(14);
    doc.text("Notes", 40, y);
    y += 18;
    
    doc.setFontSize(12);
    if (diary.notes) {
      const noteLines = diary.notes.split('\n');
      noteLines.forEach(line => {
        // Handle long lines by splitting them
        const splitLines = doc.splitTextToSize(line || "", 515);
        splitLines.forEach(splitLine => {
          doc.text(splitLine, 40, y);
          y += 16;
        });
      });
    } else {
      doc.text("No notes recorded", 40, y);
    }

    // Add watermark for free plan
    drawWatermarkIfNeeded(doc, company);

    // Save the PDF
    const filename = `SiteDiary-${job.title?.replace(/[^a-zA-Z0-9]/g, '_') || 'Job'}-${diary.date}.pdf`;
    doc.save(filename);
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-48"></div>
          <div className="space-y-4">
            <div className="h-32 bg-gray-200 rounded"></div>
            <div className="h-24 bg-gray-200 rounded"></div>
            <div className="h-48 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!diary) {
    return (
      <div className="p-8 text-center">
        <h1 className="text-xl">Site Diary not found</h1>
        <p className="text-gray-500">The diary you are looking for does not exist.</p>
        <Link to={createPageUrl("Diaries")}>
          <Button variant="link">Go to Site Diaries</Button>
        </Link>
      </div>
    );
  }

  const totalHours = (diary.labour || []).reduce((sum, worker) => sum + (Number(worker.hours) || 0), 0);

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Diaries")}>
              <Button variant="outline" size="icon">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Site Diary</h1>
              <p className="text-gray-600">{format(new Date(diary.date), "EEEE, MMMM d, yyyy")}</p>
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button variant="outline" onClick={downloadPdf}>
              <Download className="w-4 h-4 mr-2" />
              Download PDF
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Summary
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-medium text-gray-500">Job</Label>
                <p className="font-medium">{job?.title || "Unknown Job"}</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-gray-500">Customer</Label>
                <p className="font-medium">{customer?.full_name || "Unknown Customer"}</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-gray-500">Date</Label>
                <p className="font-medium">{format(new Date(diary.date), "dd/MM/yyyy")}</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-gray-500">Location</Label>
                <p className="font-medium">{diary.postcode || "No postcode recorded"}</p>
              </div>
            </div>
            
            {diary.weather && diary.weather.summary && (
              <div>
                <Label className="text-sm font-medium text-gray-500 mb-2 block">Weather Conditions</Label>
                <WeatherBadge weather={diary.weather} />
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Labour Record
            </CardTitle>
          </CardHeader>
          <CardContent>
            {diary.labour && diary.labour.length > 0 ? (
              <div className="space-y-3">
                {diary.labour.map((worker, index) => (
                  <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">{worker.name || "Operative"}</p>
                      {worker.role && (
                        <p className="text-sm text-gray-600">{worker.role}</p>
                      )}
                    </div>
                    <Badge variant="outline" className="text-sm">
                      {worker.hours} hours
                    </Badge>
                  </div>
                ))}
                
                <div className="pt-3 border-t border-gray-200">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-900">Total Labour Hours:</span>
                    <Badge className="bg-blue-100 text-blue-800">
                      {totalHours} hours
                    </Badge>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-gray-500 italic">No labour recorded for this day</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Daily Notes
            </CardTitle>
          </CardHeader>
          <CardContent>
            {diary.notes ? (
              <pre className="whitespace-pre-wrap text-gray-800 leading-relaxed">
                {diary.notes}
              </pre>
            ) : (
              <p className="text-gray-500 italic">No notes recorded for this day</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Label({ children, className = "" }) {
  return <label className={`text-sm font-medium text-gray-500 ${className}`}>{children}</label>;
}