import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { createPageUrl } from '@/utils';
import { Sparkles, FileText, Users, Clock, ArrowRight, CheckCircle, Star } from 'lucide-react';

export default function HomePage() {
  useEffect(() => {
    // Set comprehensive SEO meta tags for landing page
    document.title = "TradePricer - AI-Powered Pricing & Business Management for Trades";
    
    const updateMeta = (name, content) => {
      let meta = document.querySelector(`meta[name="${name}"]`) || document.querySelector(`meta[property="${name}"]`);
      if (!meta) {
        meta = document.createElement('meta');
        if (name.startsWith('og:') || name.startsWith('twitter:')) {
          meta.setAttribute('property', name);
        } else {
          meta.setAttribute('name', name);
        }
        document.head.appendChild(meta);
      }
      meta.content = content;
    };

    updateMeta('description', 'TradePricer helps trade professionals create accurate quotes, manage jobs, and issue certificates with AI-powered tools. Perfect for plumbers, electricians, and construction professionals.');
    updateMeta('keywords', 'trade pricing software, AI quotes generator, job management trades, certificate generator, invoice software trades, plumbing quotes, electrical quotes, construction pricing, trade business software');
    updateMeta('author', 'TradePricer');
    updateMeta('robots', 'index, follow');

    // Open Graph tags
    updateMeta('og:title', 'TradePricer - AI-Powered Pricing for Trade Professionals');
    updateMeta('og:description', 'Create accurate quotes, manage jobs, and issue certificates with AI-powered tools designed for trade professionals.');
    updateMeta('og:type', 'website');
    updateMeta('og:image', 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/b12f0cf12_tradepricer_logo_transparent.png');

    // Twitter Card tags
    updateMeta('twitter:card', 'summary_large_image');
    updateMeta('twitter:title', 'TradePricer - AI-Powered Pricing for Trades');
    updateMeta('twitter:description', 'Create accurate quotes, manage jobs, and issue certificates with AI-powered tools designed for trade professionals.');
    updateMeta('twitter:image', 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/b12f0cf12_tradepricer_logo_transparent.png');
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Header */}
      <header className="p-4 lg:p-6 flex justify-between items-center bg-white/80 backdrop-blur-sm border-b sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/b12f0cf12_tradepricer_logo_transparent.png" 
            alt="TradePricer Logo" 
            className="h-8 w-8" 
          />
          <span className="font-bold text-xl">TradePricer</span>
        </div>
        <div className="flex items-center gap-3">
          <Link to={createPageUrl("Dashboard")}>
            <Button variant="ghost">Sign In</Button>
          </Link>
          <Link to={createPageUrl("Dashboard")}>
            <Button className="bg-blue-600 hover:bg-blue-700">Get Started Free</Button>
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 lg:py-24 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <img
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/b12f0cf12_tradepricer_logo_transparent.png"
            alt="TradePricer"
            className="h-20 w-20 mx-auto mb-6"
          />
          <h1 className="text-4xl md:text-6xl font-extrabold text-gray-900 mb-6">
            AI-Powered Pricing for<br/>
            <span className="text-blue-600">Trade Professionals</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8 leading-relaxed">
            Create accurate quotes in seconds, manage jobs efficiently, and issue professional certificates. 
            TradePricer streamlines your entire trade business with intelligent automation.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link to={createPageUrl("Dashboard")}>
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-4 shadow-lg">
                <Sparkles className="mr-2 h-5 w-5" />
                Start Free Trial
              </Button>
            </Link>
            <Link to={createPageUrl("Dashboard")}>
              <Button variant="outline" size="lg" className="text-lg px-8 py-4">
                Watch Demo
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>

          {/* Trust indicators */}
          <div className="flex flex-wrap justify-center items-center gap-8 text-sm text-gray-500">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>No Credit Card Required</span>
            </div>
            <div className="flex items-center gap-2">
              <Star className="w-4 h-4 text-yellow-500" />
              <span>Used by 1000+ Trade Professionals</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>UK Compliance Ready</span>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 mb-4">
            Everything You Need to Run Your Trade Business
          </h2>
          <p className="text-lg text-gray-600 text-center mb-12 max-w-2xl mx-auto">
            From AI-powered quotes to certificate generation, TradePricer handles the paperwork so you can focus on the work.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6 rounded-lg border border-gray-200 hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="font-bold text-xl text-gray-900 mb-2">AI Quote Generation</h3>
              <p className="text-gray-600 leading-relaxed">
                Describe the job or upload photos. Our AI instantly creates professional quotes with accurate pricing and detailed scope of work.
              </p>
            </div>
            
            <div className="text-center p-6 rounded-lg border border-gray-200 hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="font-bold text-xl text-gray-900 mb-2">Certificate Management</h3>
              <p className="text-gray-600 leading-relaxed">
                Generate Gas Safe certificates, electrical condition reports, and other compliance documents instantly with legal templates.
              </p>
            </div>
            
            <div className="text-center p-6 rounded-lg border border-gray-200 hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="font-bold text-xl text-gray-900 mb-2">Customer Portal</h3>
              <p className="text-gray-600 leading-relaxed">
                Let customers book follow-up services, view certificates, and track job progress through their own secure portal.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-600">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Price Smarter?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands of trade professionals who trust TradePricer for accurate quotes and efficient business management.
          </p>
          <Link to={createPageUrl("Dashboard")}>
            <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100 text-lg px-8 py-4 shadow-lg">
              Start Your Free Trial Today
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/b12f0cf12_tradepricer_logo_transparent.png" 
              alt="TradePricer Logo" 
              className="h-6 w-6" 
            />
            <span className="font-bold text-lg">TradePricer</span>
          </div>
          <p className="text-gray-400 mb-4">AI-Powered Pricing for Trade Professionals</p>
          <p className="text-gray-500 text-sm">
            &copy; 2024 TradePricer. All rights reserved. Made for trade professionals, by trade professionals.
          </p>
        </div>
      </footer>
    </div>
  );
}