import React, { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { User, Company, Customer, Invoice, Payment, Quote } from "@/api/entities";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Mail, Download, CheckCircle, FileText, Pencil, Trash2, Loader2 } from "lucide-react";
import { buildInvoicePdfBrowser } from "../components/invoices/buildInvoicePdf";
import SendInvoiceModal from "../components/invoices/SendInvoiceModal";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { createPageUrl } from "@/utils";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import DeleteConfirmationModal from "../components/shared/DeleteConfirmationModal";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const safeJsonParse = (jsonString) => {
  try {
    return JSON.parse(jsonString);
  } catch (e) {
    console.error("Failed to parse JSON string:", e);
    return null;
  }
};

const statusColors = {
  draft: "bg-gray-100 text-gray-700 border-gray-200",
  sent: "bg-blue-100 text-blue-700 border-blue-200",
  paid: "bg-green-100 text-green-700 border-green-200",
  overdue: "bg-red-100 text-red-700 border-red-200",
  void: "bg-gray-500 text-white border-gray-600",
};

export default function InvoiceDetail() {
  const navigate = useNavigate();
  const location = useLocation();
  const invoiceId = new URLSearchParams(location.search).get("id") || "";
  
  const [me, setMe] = useState(null);
  const [company, setCompany] = useState(null);
  const [invoice, setInvoice] = useState(null);
  const [customer, setCustomer] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isDeleteModalOpen, setDeleteModalOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const gbp = (n) => new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const u = await User.me();
      setMe(u);
      const inv = Invoice.get ? await Invoice.get(invoiceId) : (await Invoice.filter({ id: invoiceId }))[0];
      if (!inv) {
        throw new Error("Invoice not found.");
      }
      setInvoice(inv);
      const co = Company.get ? await Company.get(inv.company_id) : (await Company.filter({ id: inv.company_id }))[0];
      setCompany(co);
      const cu = Customer.get ? await Customer.get(inv.customer_id) : (await Customer.filter({ id: inv.customer_id }))[0];
      setCustomer(cu);
    } catch(e) {
        console.error("Failed to load invoice details", e);
        setError("Failed to load invoice details. " + (e.message || "Please try again."));
    } finally {
        setLoading(false);
    }
  };
  
  useEffect(() => {
    if (invoiceId) loadData();
  }, [invoiceId]);

  const portalUrl = useMemo(() => {
    if (!customer?.portal_token) return "";
    const base = window.location.origin;
    return `${base}${createPageUrl(`CustomerPortal?token=${customer.portal_token}`)}`;
  }, [customer]);

  const downloadPdf = async () => {
    if (!invoice || !company || !customer) {
      console.error("Missing invoice, company, or customer data for PDF download.");
      setError("Cannot download PDF: Missing invoice, company, or customer data.");
      return;
    }
    try {
      const blob = await buildInvoicePdfBrowser({ company, customer, invoice });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${invoice.invoice_number}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error("Failed to build or download PDF", e);
      setError("Failed to generate PDF. Please try again.");
    }
  };

  const markPaid = async () => {
    if (!invoice || !company) {
      console.error("Missing invoice or company data for marking as paid.");
      setError("Cannot mark as paid: Missing invoice or company data.");
      return;
    }
    try {
      await Payment.create({
        company_id: company.id,
        job_id: invoice.job_id || undefined,
        source: "invoice",
        amount_gbp: Number(invoice.total.toFixed(2)),
        received_at: new Date().toISOString().slice(0, 10),
        ref: invoice.invoice_number,
        notes: "Marked paid from invoice detail page",
      });
      const updated = await Invoice.update(invoice.id, { status: "paid", paid_at: new Date().toISOString() });
      setInvoice(updated);
      alert("Invoice successfully marked as paid.");
    } catch (e) {
      console.error(e);
      setError("Failed to mark as paid. Please try again.");
      alert("Failed to mark as paid. Please try again.");
    }
  };

  const handleDelete = async () => {
    setIsDeleting(true);
    setError(null);
    try {
      await Invoice.delete(invoice.id);
      navigate(createPageUrl("Invoices"));
    } catch (e) {
      console.error("Failed to delete invoice:", e);
      setError("Failed to delete invoice. Please try again.");
      setIsDeleting(false);
      setDeleteModalOpen(false);
    }
  };

  const invoiceItems = useMemo(() => {
    if (!invoice?.items_json) return [];
    const parsed = safeJsonParse(invoice.items_json);
    return Array.isArray(parsed) ? parsed : [];
  }, [invoice?.items_json]);

  if (loading) return <div className="p-8 text-center"><Loader2 className="w-8 h-8 animate-spin mx-auto text-blue-500" /> Loading…</div>;
  
  if (error) return (
    <div className="p-8 max-w-4xl mx-auto">
      <Alert variant="destructive">
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>{error}</AlertDescription>
      </Alert>
      <Button onClick={() => navigate(createPageUrl('Invoices'))} className="mt-4">Back to Invoices</Button>
    </div>
  );

  if (!invoice) return <div className="p-8 text-center">Invoice not found.</div>;

  const canEdit = ['draft', 'sent'].includes(invoice.status);
  const editUrl = createPageUrl(`NewInvoice?id=${invoice.id}`);
  const canDelete = invoice.status === 'draft';

  return (
    <>
      <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="flex items-center justify-between gap-4">
            <div>
              <Button variant="outline" size="sm" onClick={() => navigate(createPageUrl("Invoices"))} className="mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Invoices
              </Button>
              <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Invoice #{invoice.invoice_number}</h1>
              <p className="text-gray-600 mt-1">
                For: {customer?.full_name || "Unknown Customer"}
              </p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Badge className={`${statusColors[invoice.status]} border text-base`}>
                {invoice.status === "paid" && <CheckCircle className="w-4 h-4 mr-1" />}
                {invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}
              </Badge>
              {canDelete && (
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setDeleteModalOpen(true)}
                  className="text-red-600 border-red-200 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
              )}
              {canEdit && (
                <Link to={editUrl}>
                  <Button variant="secondary" size="sm">
                    <Pencil className="w-4 h-4 mr-2" />
                    Edit
                  </Button>
                </Link>
              )}
              <SendInvoiceModal 
                invoice={invoice} 
                company={company} 
                customer={customer} 
                onSent={loadData}
                portalUrl={portalUrl}
                isReminder={invoice.status === 'sent' || invoice.status === 'overdue'}
              />
              <Button variant="outline" onClick={downloadPdf}><Download className="w-4 h-4 mr-2" /> Download PDF</Button>
              {invoice.status !== "paid" && invoice.status !== "void" && (
                <Button variant="secondary" onClick={markPaid}><CheckCircle className="w-4 h-4 mr-2" /> Mark as Paid</Button>
              )}
            </div>
          </div>

          <Card>
            <CardHeader><CardTitle>Summary</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="border rounded-xl p-3 bg-white">
                <div className="text-sm text-gray-600">Issue Date</div>
                <div className="text-lg font-semibold">{format(new Date(invoice.issue_date), 'd MMM yyyy')}</div>
              </div>
              <div className="border rounded-xl p-3 bg-white">
                <div className="text-sm text-gray-600">Due Date</div>
                <div className="text-lg font-semibold">{format(new Date(invoice.due_date), 'd MMM yyyy')}</div>
              </div>
              <div className="border rounded-xl p-3 bg-white">
                <div className="text-sm text-gray-600">Total (inc. VAT)</div>
                <div className="text-lg font-semibold">{gbp(invoice.total)}</div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle><FileText className="inline w-5 h-5 mr-2" />Line Items</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              {invoiceItems.length > 0 ? (
                invoiceItems.map((it, i) => (
                  <div key={i} className="border rounded-xl p-3 bg-white flex items-center justify-between">
                    <div>
                      <div className="font-medium">{it.description}</div>
                      <div className="text-xs text-gray-600">Qty {it.quantity} at {gbp(it.unit_price)} ex VAT</div>
                    </div>
                    <div className="font-medium">
                      {gbp((Number(it.quantity) || 0) * (Number(it.unit_price) || 0) * (1 + (Number(it.vat_rate) || 0) / 100))}
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center text-gray-500 py-4">No line items to display.</div>
              )}
              
               <div className="border-t pt-4 mt-4">
                  <div className="flex justify-between text-sm">
                    <span>Subtotal:</span>
                    <span>{gbp(invoice.subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>VAT:</span>
                    <span>{gbp(invoice.vat_total)}</span>
                  </div>
                  {invoice.discount_percent > 0 && (
                    <div className="flex justify-between text-sm text-green-600">
                      <span>Discount ({invoice.discount_percent}%):</span>
                      <span>-{gbp((invoice.subtotal + invoice.vat_total) * (invoice.discount_percent / 100))}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold text-lg border-t pt-2 mt-2">
                    <span>Total Due:</span>
                    <span>{gbp(invoice.total)}</span>
                  </div>
                </div>
            </CardContent>
          </Card>
        </div>
      </div>
      <DeleteConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={handleDelete}
        title="Delete Invoice?"
        message={`Are you sure you want to delete invoice ${invoice.invoice_number}? This action cannot be undone.`}
        isDeleting={isDeleting}
      />
    </>
  );
}