
import React, { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom"; // Added Link
import { User } from "@/api/entities";
import { Company } from "@/api/entities";
import { Customer } from "@/api/entities";
import { Invoice } from "@/api/entities";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Mail, Plus, Loader2, Filter, AlertCircle, Download, Search, FileText, User as UserIcon, Calendar, Receipt } from "lucide-react"; // Added new icons
import { format, parseISO, isBefore, addDays, isValid, startOfDay, endOfDay, isAfter } from "date-fns";
import { buildInvoicePdfBrowser } from "../components/invoices/buildInvoicePdf";
import { SendEmail } from "@/api/integrations";
import { UploadFile } from "@/api/integrations";
import { createPageUrl } from "@/utils";

export default function Invoices() {
  const navigate = useNavigate();
  const [me, setMe] = useState(null);
  const [company, setCompany] = useState(null);
  const [customers, setCustomers] = useState([]);
  const [invoices, setInvoices] = useState([]); // Renamed 'rows' to 'invoices'
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState(false);
  const [err, setErr] = useState("");

  // filters
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const [selected, setSelected] = useState({});

  useEffect(() => {
    const load = async () => {
      try {
        const u = await User.me();
        setMe(u);

        if (!u || !u.company_id) {
          setErr("Your user account is not associated with a company. Please contact support.");
          setLoading(false);
          return;
        }

        const [co, custs, invs] = await Promise.all([
            Company.filter({ id: u.company_id }),
            Customer.filter({ company_id: u.company_id }, "-created_date", 500),
            Invoice.filter({ company_id: u.company_id }, "-issue_date", 500)
        ]);

        setCompany(co[0] || null);
        setCustomers(custs || []);
        setInvoices(invs || []); // Updated setRows to setInvoices
        
        // Auto mark overdue when due date has passed and not paid or void
        const today = new Date();
        const toUpdate = (invs || []).filter((i) =>
          i.status !== "paid" &&
          i.status !== "void" &&
          i.due_date &&
          isValid(parseISO(i.due_date)) &&
          isBefore(parseISO(i.due_date), today) &&
          i.status !== "overdue"
        );

        for (const inv of toUpdate) {
          try {
            await Invoice.update(inv.id, { status: "overdue" });
          } catch (e) {
            console.error("Failed to update invoice to overdue:", e);
          }
        }

        if (toUpdate.length) {
          const fresh = await Invoice.filter({ company_id: u.company_id }, "-issue_date", 500);
          setInvoices(fresh || invs || []); // Updated setRows to setInvoices
        }
      } catch (e) {
        console.error(e);
        setErr("Could not load invoices.");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const byId = useMemo(() => {
    const m = {};
    for (const c of customers) m[c.id] = c;
    return m;
  }, [customers]);

  const filteredInvoices = useMemo(() => { // Renamed 'filtered' to 'filteredInvoices'
    const term = q.trim().toLowerCase();
    const fromDate = from && isValid(parseISO(from)) ? startOfDay(parseISO(from)) : null;
    const toDate = to && isValid(parseISO(to)) ? endOfDay(parseISO(to)) : null;

    return invoices.filter((r) => { // Updated 'rows' to 'invoices'
      if (status !== "all" && r.status !== status) return false;
      
      const issueDate = r.issue_date && isValid(parseISO(r.issue_date)) ? parseISO(r.issue_date) : null;
      if (!issueDate) {
        if (fromDate || toDate) return false; // Don't show items without a date if filtering by date
      } else {
        if (fromDate && isBefore(issueDate, fromDate)) return false;
        if (toDate && isAfter(issueDate, toDate)) return false;
      }
      
      if (!term) return true;
      const cust = byId[r.customer_id];
      const hay = [
        r.invoice_number,
        r.status,
        String(r.total),
        cust?.full_name,
        cust?.postcode,
      ].join(" ").toLowerCase();
      return hay.includes(term);
    });
  }, [invoices, status, q, from, to, byId]); // Updated 'rows' to 'invoices'

  const ageing = useMemo(() => {
    const today = new Date();
    const b = { b0: 0, b30: 0, b60: 0, b90: 0, b120: 0 };
    for (const inv of invoices) { // Updated 'rows' to 'invoices'
      if (inv.status === "paid" || inv.status === "void") continue;
      if (!inv.due_date || !isValid(parseISO(inv.due_date))) continue;
      const due = parseISO(inv.due_date);
      const days = Math.floor((today.getTime() - due.getTime()) / (1000 * 60 * 60 * 24));
      const amt = Number(inv.total || 0);
      if (days <= 0) b.b0 += amt;
      else if (days <= 30) b.b30 += amt;
      else if (days <= 60) b.b60 += amt;
      else if (days <= 90) b.b90 += amt;
      else b.b120 += amt;
    }
    return b;
  }, [invoices]); // Updated 'rows' to 'invoices'

  const allOverdueIds = useMemo(
    () => filteredInvoices.filter((i) => i.status === "overdue").map((i) => i.id), // Updated 'filtered' to 'filteredInvoices'
    [filteredInvoices] // Updated 'filtered' to 'filteredInvoices'
  );

  const toggleAllOverdue = (checked) => {
    const next = { ...selected };
    for (const id of allOverdueIds) next[id] = checked;
    setSelected(next);
  };

  const gbp = (n) => new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

  const downloadCsv = () => {
    const header = ["Invoice", "Customer", "Issue date", "Due date", "Status", "Total"];
    const lines = filteredInvoices.map((r) => [ // Updated 'filtered' to 'filteredInvoices'
      r.invoice_number,
      byId[r.customer_id]?.full_name || "",
      r.issue_date || "",
      r.due_date || "",
      r.status,
      String(Number(r.total || 0).toFixed(2)),
    ].join(","));
    const csv = [header.join(","), ...lines].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "invoices.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const sendReminder = async (inv) => {
    const cust = byId[inv.customer_id];
    if (!cust?.email) {
      alert(`No email for ${cust?.full_name || "customer"}.`);
      return;
    }
    
    setWorking(true);
    try {
      // Parse items if they're stored as JSON string
      let invoiceForPdf = { ...inv };
      if (typeof inv.items_json === 'string') {
        try {
          invoiceForPdf.items_json = JSON.parse(inv.items_json);
        } catch (e) {
          invoiceForPdf.items_json = [];
        }
      }

      // Generate PDF
      const blob = await buildInvoicePdfBrowser({ 
        company, 
        customer: cust, 
        invoice: invoiceForPdf 
      });
      
      // Upload PDF to get URL
      const pdfFile = new File([blob], `${inv.invoice_number}.pdf`, { type: 'application/pdf' });
      const { file_url: pdfUrl } = await UploadFile({ file: pdfFile });

      const subject = `Reminder: invoice ${inv.invoice_number} is due`;
      const message =
        `Hi ${cust.full_name || "there"},\n\n` +
        `This is a friendly reminder that invoice ${inv.invoice_number} for ${gbp(inv.total)} is now due.\n` +
        `You can download your invoice here: ${pdfUrl}\n\n` +
        `Please reply if you need anything.\n\n` +
        `Thanks,\n${company?.name || 'CertiFlow Pro'}`;

      await SendEmail({
        to: cust.email,
        from_name: company?.name || "CertiFlow Pro",
        subject,
        body: message,
      });

      alert(`Reminder sent for ${inv.invoice_number}`);
    } catch (e) {
      console.error(e);
      alert("Could not send reminder.");
    } finally {
      setWorking(false);
    }
  };

  const sendBulkReminders = async () => {
    const targets = filteredInvoices.filter((r) => selected[r.id] && r.status === "overdue"); // Updated 'filtered' to 'filteredInvoices'
    if (!targets.length) {
      alert("Select at least one overdue invoice.");
      return;
    }
    
    setWorking(true);
    let successCount = 0;
    try {
      for (const inv of targets) {
        try {
          await sendReminder(inv);
          successCount++;
        } catch (e) {
          console.error(`Failed to send reminder for ${inv.invoice_number}:`, e);
        }
      }
      alert(`Sent ${successCount} of ${targets.length} reminders successfully.`);
    } finally {
      setWorking(false);
    }
  };

  if (loading) return (
    <div className="p-10 flex items-center justify-center">
      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
      Loading invoices…
    </div>
  );

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-6xl mx-auto space-y-6"> {/* Updated max-w-7xl to max-w-6xl */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Invoices</h1>
            <p className="text-gray-600 mt-1">
              Create, send, and track invoices to get paid on time
            </p>
          </div>
          <Link to={createPageUrl("NewInvoice")}>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              New Invoice
            </Button>
          </Link>
        </div>

        {err && (
          <Card className="border-red-200">
            <CardContent className="text-red-700 py-4">{err}</CardContent>
          </Card>
        )}

        {/* Ageing summary */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <AgeTile label="Not yet due" value={gbp(ageing.b0)} color="text-green-600" />
          <AgeTile label="1-30 days" value={gbp(ageing.b30)} color="text-yellow-600" />
          <AgeTile label="31-60 days" value={gbp(ageing.b60)} color="text-orange-600" />
          <AgeTile label="61-90 days" value={gbp(ageing.b90)} color="text-red-600" />
          <AgeTile label="90+ days" value={gbp(ageing.b120)} color="text-red-800" />
        </div>

        {/* Filters */}
        <Card> {/* Wrapped filters in a Card */}
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-4 h-4" /> 
              Filters and Actions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
              <div className="md:col-span-4">
                <Label>Search</Label>
                <Input 
                  placeholder="Invoice number, customer, postcode..." 
                  value={q} 
                  onChange={(e) => setQ(e.target.value)} 
                />
              </div>
              <div className="md:col-span-2">
                <Label>Status</Label>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger><SelectValue placeholder="All" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All statuses</SelectItem>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="sent">Sent</SelectItem>
                    <SelectItem value="overdue">Overdue</SelectItem>
                    <SelectItem value="paid">Paid</SelectItem>
                    <SelectItem value="void">Void</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="md:col-span-2">
                <Label>Date from</Label>
                <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
              </div>
              <div className="md:col-span-2">
                <Label>Date to</Label>
                <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
              </div>
              <div className="md:col-span-2">
                <Button 
                  onClick={() => {
                    setQ("");
                    setStatus("all");
                    setFrom("");
                    setTo("");
                    setSelected({});
                  }}
                  variant="outline"
                >
                  Clear Filters
                </Button>
              </div>
            </div>
            
            {allOverdueIds.length > 0 && (
              <div className="flex items-center gap-4 p-3 bg-red-50 rounded-lg border border-red-200">
                <input
                  type="checkbox"
                  className="h-4 w-4"
                  onChange={(e) => toggleAllOverdue(e.target.checked)}
                  checked={allOverdueIds.every((id) => selected[id]) && allOverdueIds.length > 0}
                  aria-label="Select all overdue"
                />
                <span className="text-sm text-red-700 flex-1">
                  Select all {allOverdueIds.length} overdue invoices in view
                </span>
                <Button 
                  onClick={sendBulkReminders} 
                  disabled={working || !Object.values(selected).some(Boolean)}
                  size="sm"
                  className="bg-red-600 hover:bg-red-700"
                >
                  {working ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Mail className="w-4 h-4 mr-2" />
                  )}
                  Send Bulk Reminders
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Invoice List / Empty State */}
        <div className="space-y-4">
          {invoices.length === 0 && !loading ? (
             <Card className="p-8 text-center">
              <div className="space-y-4 max-w-2xl mx-auto">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                  <Receipt className="w-8 h-8 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">About Invoices</h3>
                  <p className="text-gray-600 mb-4 leading-relaxed">
                    Generate professional invoices from your jobs with just a few clicks. Keeping track of your invoices ensures a healthy cash flow for your business.
                  </p>
                  <div className="bg-blue-50 p-4 rounded-lg mb-4">
                    <p className="text-sm text-blue-800 leading-relaxed">
                      <strong>Example:</strong> Once a job is complete, you can generate an invoice that automatically includes all the quoted items and any approved variations. Send it directly to your customer and track when it's paid.
                    </p>
                  </div>
                   <Link to={createPageUrl("NewInvoice")}>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Create Your First Invoice
                    </Button>
                  </Link>
                </div>
              </div>
            </Card>
          ) : filteredInvoices.length === 0 ? (
            <Card className="p-12 text-center text-gray-500">
              No invoices match your filters.
            </Card>
          ) : (
            filteredInvoices.map((invoice) => {
              const cust = byId[invoice.customer_id];
              return (
                <Card key={invoice.id} className="hover:shadow-md transition-shadow duration-200">
                  <CardContent className="p-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 items-center">
                        {/* Invoice Number */}
                        <div className="col-span-1 md:col-span-2 lg:col-span-1">
                            <p className="text-xs text-gray-500">Invoice #</p>
                            <p className="font-medium text-gray-900">{invoice.invoice_number}</p>
                        </div>
                        {/* Customer */}
                        <div className="col-span-1 md:col-span-2 lg:col-span-1">
                            <p className="text-xs text-gray-500">Customer</p>
                            <p className="text-gray-700">{cust?.full_name || "Unknown Customer"}</p>
                        </div>
                        {/* Issue Date */}
                        <div className="col-span-1">
                            <p className="text-xs text-gray-500">Issued</p>
                            <p className="text-gray-600">{invoice.issue_date ? format(parseISO(invoice.issue_date), "d MMM yyyy") : "-"}</p>
                        </div>
                        {/* Due Date */}
                        <div className="col-span-1">
                            <p className="text-xs text-gray-500">Due</p>
                            <p className="text-gray-600">{invoice.due_date ? format(parseISO(invoice.due_date), "d MMM yyyy") : "-"}</p>
                        </div>
                        {/* Total */}
                        <div className="col-span-1">
                            <p className="text-xs text-gray-500">Total</p>
                            <p className="font-medium">{gbp(invoice.total)}</p>
                        </div>
                        {/* Status */}
                        <div className="col-span-1 flex items-center justify-end">
                            {invoice.status === "overdue" && (
                                <input
                                    type="checkbox"
                                    className="h-4 w-4 text-red-600 mr-2"
                                    checked={!!selected[invoice.id]}
                                    onChange={(e) => setSelected((s) => ({ ...s, [invoice.id]: e.target.checked }))}
                                    aria-label={`Select ${invoice.invoice_number}`}
                                />
                            )}
                            <StatusBadge status={invoice.status} />
                        </div>
                    </div>
                    <div className="flex justify-end gap-2 mt-4">
                        {invoice.status === "overdue" && (
                            <Button 
                                variant="outline" 
                                size="sm" 
                                onClick={() => sendReminder(invoice)} 
                                disabled={working}
                                className="text-red-600 border-red-200 hover:bg-red-50"
                            >
                                {working ? (
                                    <Loader2 className="w-4 h-4 animate-spin" />
                                ) : (
                                    <Mail className="w-4 h-4" />
                                )}
                            </Button>
                        )}
                        <Button 
                            size="sm" 
                            onClick={() => navigate(createPageUrl(`InvoiceDetail?id=${invoice.id}`))}
                        >
                            View
                        </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }) {
  const styles = {
    paid: "bg-green-100 text-green-800 border-green-200",
    overdue: "bg-red-100 text-red-800 border-red-200", 
    sent: "bg-blue-100 text-blue-800 border-blue-200",
    void: "bg-gray-100 text-gray-700 border-gray-200",
    draft: "bg-yellow-100 text-yellow-800 border-yellow-200"
  };

  return (
    <Badge className={`${styles[status] || styles.draft} border flex items-center gap-1`}>
      {status === "overdue" && <AlertCircle className="w-3 h-3" />}
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </Badge>
  );
}

function AgeTile({ label, value, color }) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium text-gray-600">{label}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className={`text-2xl font-bold ${color}`}>{value}</div>
      </CardContent>
    </Card>
  );
}
