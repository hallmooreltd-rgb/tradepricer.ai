
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { Job } from "@/api/entities";
import { Customer } from "@/api/entities";
import { User } from "@/api/entities";
import { Quote } from "@/api/entities";
import { Variation } from "@/api/entities"; // Added Variation import
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Edit, MapPin, Calendar, User as UserIcon, FileText, Receipt, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { createPageUrl } from "@/utils";
import JobTasksCard from "../components/jobs/JobTasksCard";
import TimesheetsCard from "../components/jobs/TimesheetsCard";
import ExpensesCard from "../components/jobs/ExpensesCard";
import JobProfitabilityCard from "../components/jobs/JobProfitabilityCard";
import StagePaymentsCard from "../components/jobs/StagePaymentsCard";
import VariationsCard from "../components/jobs/VariationsCard";

const jobTypeLabels = {
  boiler_install: "Boiler Installation",
  boiler_service: "Boiler Service",
  damp_report: "Damp Report",
  roof_inspection: "Roof Inspection",
  risk_assessment: "Risk Assessment",
  other: "Other",
};

const statusColors = {
  draft: "bg-gray-100 text-gray-700 border-gray-200",
  in_progress: "bg-blue-100 text-blue-700 border-blue-200",
  completed: "bg-green-100 text-green-700 border-green-200",
  cancelled: "bg-red-100 text-red-700 border-red-200",
};

export default function JobPage() {
  const navigate = useNavigate();
  const id = new URLSearchParams(useLocation().search).get("id") || "";

  const [job, setJob] = useState(null);
  const [customer, setCustomer] = useState(null);
  // const [company, setCompany] = useState(null); // Removed company state
  const [assignee, setAssignee] = useState(null);
  const [quote, setQuote] = useState(null);
  const [variations, setVariations] = useState([]); // Added variations state
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // if (!id) { // Removed initial navigation check here, handled by `if (id) load();`
    //   navigate(createPageUrl("Jobs"));
    //   return;
    // }
    const load = async () => {
      setLoading(true);
      try {
        const j = Job.get ? await Job.get(id) : (await Job.filter({ id }))[0];
        setJob(j);

        if (j) {
          const [cust, ass, quo, vars] = await Promise.all([ // Added vars to destructuring
            j.customer_id && Customer.get ? Customer.get(j.customer_id) : Promise.resolve(null),
            // Company.get ? Company.get(j.company_id) : (await Company.filter({ id: j.company_id }))[0], // Removed company fetch
            j.assigned_to_user_id && User.get ? User.get(j.assigned_to_user_id) : Promise.resolve(null),
            j.quote_id && Quote.get ? Quote.get(j.quote_id) : Promise.resolve(null),
            Variation.filter({ job_id: j.id }, "-created_date", 100) // Fetch variations
          ]);
          setCustomer(cust);
          // setCompany(companyData); // Removed setCompany
          setAssignee(ass);
          setQuote(quo);
          setVariations(vars || []); // Set variations state
        }
      } catch (e) {
        console.error("Error loading job details:", e);
      } finally {
        setLoading(false);
      }
    };

    if (id) load();
  }, [id]);

  if (loading) {
    return (
      <div className="p-8 flex justify-center items-center">
        <Loader2 className="w-8 h-8 animate-spin text-gray-500" />
      </div>
    );
  }

  if (!job) {
    return (
      <div className="p-8 text-center text-red-500">
        Job not found.
        {/* Removed "Return to Jobs List" button as per outline */}
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center gap-4 min-w-0"> {/* Added min-w-0 for flex overflow */}
            <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl("Jobs"))}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="flex-1 min-w-0"> {/* Added min-w-0 for flex overflow */}
              <div className="flex items-center gap-3">
                <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 break-words">{job.title}</h1> {/* Added break-words */}
                <Badge className={`${statusColors[job.status]} border text-base flex-shrink-0`}>{job.status.replace("_", " ")}</Badge> {/* Added flex-shrink-0 */}
              </div>
              <p className="text-gray-600 mt-1 break-words"> {/* Added break-words */}
                {jobTypeLabels[job.job_type]}
              </p>
            </div>
          </div>
          <div className="flex gap-2 self-end sm:self-center"> {/* Aligned buttons */}
             <Button variant="outline" onClick={() => navigate(createPageUrl(`NewInvoice?job_id=${job.id}&customer_id=${job.customer_id}`))}>
                <Receipt className="w-4 h-4 mr-2" />
                Make Invoice
             </Button>
             <Button>
                <Edit className="w-4 h-4 mr-2" />
                Edit Job
             </Button>
          </div>
        </div>

        {/* Summary card removed, its details are integrated elsewhere */}
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
          <div className="lg:col-span-2 space-y-6">
            <JobProfitabilityCard job={job} />
            <VariationsCard job={job} variations={variations} />
            <JobTasksCard job={job} variations={variations} /> {/* Pass variations prop */}
            <StagePaymentsCard job={job} />
            <TimesheetsCard job={job} />
            <ExpensesCard job={job} />
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader><CardTitle>Details</CardTitle></CardHeader>
              <CardContent className="space-y-4 text-sm">
                {customer && (
                  <div className="flex items-start gap-3">
                    <UserIcon className="w-4 h-4 mt-1 text-gray-500" />
                    <div>
                      <div className="text-gray-600">Customer</div>
                      <div className="font-medium text-gray-900">{customer.full_name}</div>
                      <div className="text-gray-600">{customer.phone}</div>
                      <div className="text-gray-600">{customer.email}</div>
                    </div>
                  </div>
                )}
                {job.scheduled_date && (
                  <div className="flex items-start gap-3">
                    <Calendar className="w-4 h-4 mt-1 text-gray-500" />
                    <div>
                      <div className="text-gray-600">Scheduled</div>
                      <div className="font-medium text-gray-900">{format(new Date(job.scheduled_date), 'd MMM yyyy')}</div>
                    </div>
                  </div>
                )}
                {assignee && (
                  <div className="flex items-start gap-3">
                    <UserIcon className="w-4 h-4 mt-1 text-gray-500" />
                    <div>
                      <div className="text-gray-600">Assigned To</div>
                      <div className="font-medium text-gray-900">{assignee.full_name || assignee.email}</div>
                    </div>
                  </div>
                )}
                {quote && (
                  <div className="flex items-start gap-3">
                    <FileText className="w-4 h-4 mt-1 text-gray-500" />
                    <div>
                      <div className="text-gray-600">From Quote</div>
                      <Button variant="link" className="p-0 h-auto" asChild>
                        <Link to={createPageUrl(`QuoteDetail?id=${quote.id}`)}>{quote.quote_number}</Link>
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Job Notes card is removed from here */}
          </div>
        </div>
      </div>
    </div>
  );
}
