
import React, { useState, useEffect, useCallback } from "react";
import { Job, Customer, User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Plus, Search, Calendar, User as UserIcon, MapPin, Trash2, Briefcase } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import { batchLoadEntities } from "../components/utils/ApiUtils";
import DeleteConfirmationModal from "../components/shared/DeleteConfirmationModal";

const jobTypeLabels = {
  boiler_install: "Boiler Installation",
  boiler_service: "Boiler Service",
  damp_report: "Damp Report", 
  roof_inspection: "Roof Inspection",
  risk_assessment: "Risk Assessment",
  other: "Other"
};

const statusColors = {
  draft: "bg-gray-100 text-gray-700 border-gray-200",
  in_progress: "bg-blue-100 text-blue-700 border-blue-200",
  completed: "bg-green-100 text-green-700 border-green-200",
  cancelled: "bg-red-100 text-red-700 border-red-200"
};

export default function Jobs() {
  const [jobs, setJobs] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [deleteJobId, setDeleteJobId] = useState(null); // State for delete confirmation
  const [deleting, setDeleting] = useState(false); // State for delete operation

  const getCustomerName = useCallback((customerId) => {
    const customer = customers.find(c => c.id === customerId);
    return customer?.full_name || "Unknown Customer";
  }, [customers]);

  const filterJobs = useCallback(() => {
    let filtered = jobs;
    
    if (searchTerm) {
      filtered = filtered.filter(job => 
        job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        getCustomerName(job.customer_id).toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (statusFilter !== "all") {
      filtered = filtered.filter(job => job.status === statusFilter);
    }
    
    if (typeFilter !== "all") {
      filtered = filtered.filter(job => job.job_type === typeFilter);
    }
    
    setFilteredJobs(filtered);
  }, [jobs, searchTerm, statusFilter, typeFilter, getCustomerName]); // getCustomerName is a dependency because it's used inside filterJobs

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    filterJobs();
  }, [filterJobs]); // filterJobs is now a useCallback, so it's the dependency

  const loadData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      if (userData.company_id) {
        const results = await batchLoadEntities([
          { fn: () => Job.filter({ company_id: userData.company_id }, "-created_date", 100), name: "jobs" },
          { fn: () => Customer.filter({ company_id: userData.company_id }), name: "customers" }
        ]);
        
        const jobData = results.find(r => r.name === 'jobs' && r.success)?.data || [];
        const customerData = results.find(r => r.name === 'customers' && r.success)?.data || [];

        setJobs(jobData);
        setCustomers(customerData);
      }
    } catch (error) {
      console.error("Error loading jobs:", error);
    }
    setLoading(false);
  };

  const handleDeleteJob = async (jobId) => {
    setDeleting(true);
    try {
      await Job.delete(jobId);
      
      // Remove job from local state
      setJobs(prevJobs => prevJobs.filter(job => job.id !== jobId));
      setDeleteJobId(null);
    } catch (error) {
      console.error("Error deleting job:", error);
      alert("Failed to delete job. Please try again.");
    } finally {
      setDeleting(false);
    }
  };

  const getJobForDeletion = (jobId) => {
    const job = jobs.find(j => j.id === jobId);
    const customerName = getCustomerName(job?.customer_id);
    return {
      title: job?.title || "Untitled Job",
      subtitle: `Customer: ${customerName}`,
      warning: job?.status === 'completed' 
        ? "This completed job and all associated data will be permanently deleted."
        : "This job and all associated data will be permanently deleted."
    };
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-48"></div>
            <div className="grid gap-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-24 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Jobs</h1>
            <p className="text-gray-600 mt-1">
              Manage and track all your work orders
            </p>
          </div>
          <Link to={createPageUrl("NewJob")}>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              New Job
            </Button>
          </Link>
        </div>

        <Card className="p-6">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  placeholder="Search jobs or customers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-32">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-full sm:w-40">
                  <SelectValue placeholder="Job Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="boiler_install">Boiler Install</SelectItem>
                  <SelectItem value="boiler_service">Boiler Service</SelectItem>
                  <SelectItem value="damp_report">Damp Report</SelectItem>
                  <SelectItem value="roof_inspection">Roof Inspection</SelectItem>
                  <SelectItem value="risk_assessment">Risk Assessment</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </Card>

        <div className="space-y-4">
          {jobs.length === 0 && !loading ? (
            <Card className="p-8 text-center">
              <div className="space-y-4 max-w-2xl mx-auto">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                  <Briefcase className="w-8 h-8 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">About Jobs</h3>
                  <p className="text-gray-600 mb-4 leading-relaxed">
                    The Jobs section is your central hub for managing all ongoing and completed work. Once a quote is accepted, it becomes a job where you can track progress, assign tasks, log time, and manage expenses.
                  </p>
                  <div className="bg-blue-50 p-4 rounded-lg mb-4">
                    <p className="text-sm text-blue-800 leading-relaxed">
                      <strong>Example scenario:</strong> A customer accepts your quote for a "New Boiler Installation". This automatically creates a job. You can then add tasks like "Remove old boiler" and "Install new flue", log the hours your team works, and record any extra materials purchased.
                    </p>
                  </div>
                  <Link to={createPageUrl("NewJob")}>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Create Your First Job
                    </Button>
                  </Link>
                </div>
              </div>
            </Card>
          ) : filteredJobs.length === 0 ? (
            <Card className="p-12 text-center text-gray-500">
              No jobs match your filters.
            </Card>
          ) : (
            filteredJobs.map((job) => (
              <Card key={job.id} className="hover:shadow-md transition-shadow duration-200">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0 space-y-3">
                      <div className="flex items-center gap-3 flex-wrap">
                        <h3 className="font-semibold text-lg text-gray-900 truncate">
                          {job.title}
                        </h3>
                        <Badge className={`${statusColors[job.status]} border`}>
                          {job.status.replace('_', ' ')}
                        </Badge>
                        <Badge variant="outline">
                          {jobTypeLabels[job.job_type]}
                        </Badge>
                      </div>
                      
                      <div className="flex flex-wrap items-center gap-6 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <UserIcon className="w-4 h-4" />
                          <span>{getCustomerName(job.customer_id)}</span>
                        </div>
                        {job.scheduled_date && (
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4" />
                            <span>{format(new Date(job.scheduled_date), "MMM d, yyyy")}</span>
                          </div>
                        )}
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4" />
                          <span>Created {format(new Date(job.created_date), "MMM d, yyyy")}</span>
                        </div>
                      </div>
                      
                      {job.notes && (
                        <p className="text-gray-600 text-sm truncate">
                          {job.notes}
                        </p>
                      )}
                    </div>
                    
                    <div className="ml-4 flex-shrink-0 flex gap-2">
                      <Link to={createPageUrl(`Job?id=${job.id}`)}>
                        <Button variant="outline" size="sm">
                          View Details
                        </Button>
                      </Link>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setDeleteJobId(job.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Delete Confirmation Modal */}
        {deleteJobId && (
          <DeleteConfirmationModal
            isOpen={!!deleteJobId}
            onClose={() => setDeleteJobId(null)}
            onConfirm={() => handleDeleteJob(deleteJobId)}
            title="Delete Job"
            itemDetails={getJobForDeletion(deleteJobId)}
            isDeleting={deleting}
          />
        )}
      </div>
    </div>
  );
}
