
import React, { useState, useEffect, useCallback, useMemo } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import { Job } from "@/api/entities";
import { Customer } from "@/api/entities";
import { Quote } from "@/api/entities";
import { Certificate } from "@/api/entities";
import { Company } from "@/api/entities";
import ErrorBoundary from "./components/ErrorBoundary";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import {
  LayoutDashboard,
  Briefcase,
  Users,
  FileText,
  Camera,
  Bell,
  Settings,
  LogOut,
  Receipt,
  Sparkles,
  Layers,
  CreditCard,
  Calendar,
} from "lucide-react";
import FloatingAIAssistant from "./components/assistant/FloatingAIAssistant";

const navigationItems = [
  { title: "Dashboard", url: createPageUrl("Dashboard"), icon: LayoutDashboard },
  { title: "Jobs", url: createPageUrl("Jobs"), icon: Briefcase },
  { title: "Customers", url: createPageUrl("Customers"), icon: Users },
  { title: "AI Quotes", url: createPageUrl("Quotes"), icon: Sparkles },
  { title: "Invoices", url: createPageUrl("Invoices"), icon: Receipt },
  { title: "Variations", url: createPageUrl("Variations"), icon: Layers },
  { title: "Certificates", url: createPageUrl("Certificates"), icon: FileText },
  { title: "Site Diaries", url: createPageUrl("Diaries"), icon: Calendar },
  { title: "Photos", url: createPageUrl("Photos"), icon: Camera },
  { title: "Reminders", url: createPageUrl("Reminders"), icon: Bell },
  { title: "AI Assistant", url: createPageUrl("Assistant"), icon: Sparkles },
];

const metaDescriptions = {
  Dashboard: "Manage your trade business with AI-powered pricing, job tracking, and certificate generation in TradePricer.",
  Jobs: "Track and manage all your trade jobs with TradePricer's comprehensive job management system.",
  Customers: "Organize your customer database and manage client relationships with TradePricer.",
  Quotes: "Create professional AI-generated quotes instantly for any trade job with TradePricer.",
  Invoices: "Generate and send professional invoices for your trade business with TradePricer.",
  Certificates: "Issue compliance certificates quickly and professionally with TradePricer's certificate generator.",
  Diaries: "Keep detailed records of daily site activities, progress, and events with TradePricer's site diary module.",
  Assistant: "Get AI-powered help with pricing, scheduling, and business management in TradePricer.",
  StaffSettings: "Manage your team members and staff register effectively with TradePricer's personnel management tools."
};

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = useState(null);
  const [company, setCompany] = useState(null);
  const [contextData, setContextData] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Update page title and meta tags
  useEffect(() => {
    const title = currentPageName 
      ? `${currentPageName} | TradePricer - AI-Powered Pricing for Trades`
      : "TradePricer - AI-Powered Pricing for Trade Professionals";
    
    document.title = title;

    // Update meta description
    let metaDesc = document.querySelector('meta[name="description"]');
    if (!metaDesc) {
      metaDesc = document.createElement('meta');
      metaDesc.name = 'description';
      document.head.appendChild(metaDesc);
    }
    
    metaDesc.content = metaDescriptions[currentPageName] || 
      "TradePricer helps trade professionals create accurate quotes, manage jobs, and issue certificates with AI-powered tools.";

    // Update keywords
    let keywords = document.querySelector('meta[name="keywords"]');
    if (!keywords) {
      keywords = document.createElement('meta');
      keywords.name = 'keywords';
      document.head.appendChild(keywords);
    }
    keywords.content = "trade pricing, AI quotes, job management, certificates, invoices, plumbing quotes, electrical quotes, construction pricing";
  }, [currentPageName]);

  // Load user and company data
  useEffect(() => {
    let mounted = true;
    
    const loadUserData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const userData = await User.me();
        if (!mounted) return;
        
        setUser(userData);

        if (userData?.company_id) {
          try {
            // Try to get company data
            let co = null;
            try {
              const companies = await Company.filter({ id: userData.company_id });
              co = companies?.[0] || null;
            } catch (companyError) {
              console.warn('Could not load company data:', companyError);
            }
            
            if (!mounted) return;
            setCompany(co);

            // Load context data for AI assistant with proper error handling
            try {
              const contextPromises = [
                Job.filter({ company_id: userData.company_id }, "-created_date", 50).catch(() => []),
                Customer.filter({ company_id: userData.company_id }, "-created_date", 100).catch(() => []),
                Quote.filter({ company_id: userData.company_id }, "-created_date", 50).catch(() => []),
                Certificate.filter({ company_id: userData.company_id }, "-created_date", 50).catch(() => [])
              ];

              const [jobs, customers, quotes, certificates] = await Promise.all(contextPromises);
              
              if (!mounted) return;
              
              setContextData({
                company: co,
                jobs: Array.isArray(jobs) ? jobs : [],
                customers: Array.isArray(customers) ? customers : [],
                quotes: Array.isArray(quotes) ? quotes : [],
                certificates: Array.isArray(certificates) ? certificates : []
              });
            } catch (contextError) {
              console.warn('Could not load context data:', contextError);
              if (mounted) {
                setContextData({
                  company: co,
                  jobs: [],
                  customers: [],
                  quotes: [],
                  certificates: []
                });
              }
            }
          } catch (dataError) {
            console.warn('Error loading company and context data:', dataError);
            if (mounted) {
              setCompany(null);
              setContextData({});
            }
          }
        }
      } catch (error) {
        console.warn('User not authenticated or error loading user:', error);
        if (mounted) {
          setError(error);
          setUser(null);
          setCompany(null);
          setContextData({});
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    loadUserData();
    
    return () => {
      mounted = false;
    };
  }, []);

  const handleLogout = useCallback(async () => {
    try {
      await User.logout();
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      window.location.reload();
    }
  }, []);

  const isActive = useCallback((url) => {
    if (!url) return false;
    
    try {
      if (url.includes("?")) {
        const queryPart = url.split("?")[1];
        return location.search.includes(queryPart);
      }
      return location.pathname === url;
    } catch (error) {
      console.warn('Error checking active route:', error);
      return false;
    }
  }, [location.pathname, location.search]);

  const navigationMenu = useMemo(() => (
    navigationItems.map((item) => {
      const active = isActive(item.url);
      return (
        <SidebarMenuItem key={item.title}>
          <SidebarMenuButton
            asChild
            className={`relative transition-all duration-200 rounded-lg ${
              active
                ? "bg-blue-100 text-blue-700 shadow-sm border border-blue-200"
                : "text-gray-600 hover:bg-blue-50 hover:text-blue-700"
            }`}
          >
            <Link to={item.url} className="flex items-center gap-3 px-3 py-2.5">
              <item.icon className="w-5 h-5" />
              <span className="font-medium">{item.title}</span>
              {active && (
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-blue-600 rounded-l-full" />
              )}
            </Link>
          </SidebarMenuButton>
        </SidebarMenuItem>
      );
    })
  ), [isActive]);

  return (
    <ErrorBoundary>
      <SidebarProvider>
        <div className="min-h-screen flex w-full bg-gray-50">
          <Sidebar className="border-r border-gray-200">
            <SidebarHeader className="border-b border-gray-200 p-4">
              <div className="flex items-center gap-3">
                <img
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/b12f0cf12_tradepricer_logo_transparent.png"
                  alt="TradePricer Logo"
                  className="h-10 w-10"
                  loading="lazy"
                />
                <div className="flex-1 min-w-0">
                  <h2 className="font-bold text-lg text-gray-900 truncate">
                    TradePricer
                  </h2>
                  <p className="text-sm text-gray-500 truncate">AI-Powered Pricing</p>
                </div>
              </div>
            </SidebarHeader>

            <SidebarContent className="p-4">
              <SidebarGroup>
                <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
                  Navigation
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu className="space-y-1">
                    {navigationMenu}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            </SidebarContent>

            <SidebarFooter className="border-t border-gray-200 p-4">
              <SidebarGroup>
                <SidebarGroupContent>
                  <SidebarMenu className="space-y-1">
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild className="text-gray-600 hover:bg-gray-100">
                        <Link to={createPageUrl("Billing")} className="flex items-center gap-3 px-3 py-2.5">
                          <CreditCard className="w-5 h-5" />
                          <span className="font-medium">Billing</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild className="text-gray-600 hover:bg-gray-100">
                        <Link to={createPageUrl("StaffSettings")} className="flex items-center gap-3 px-3 py-2.5">
                          <Users className="w-5 h-5" />
                          <span className="font-medium">Staff Register</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild className="text-gray-600 hover:bg-gray-100">
                        <Link to={createPageUrl("Settings")} className="flex items-center gap-3 px-3 py-2.5">
                          <Settings className="w-5 h-5" />
                          <span className="font-medium">Settings</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton onClick={handleLogout} className="text-gray-600 hover:bg-gray-100 w-full">
                        <div className="flex items-center gap-3 px-3 py-2.5">
                          <LogOut className="w-5 h-5" />
                          <span className="font-medium">Logout</span>
                        </div>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
              <div className="md:hidden">
                <SidebarTrigger />
              </div>
            </SidebarFooter>
          </Sidebar>

          <main className="flex-1 w-full overflow-x-hidden relative">
            <ErrorBoundary>
              {children}
            </ErrorBoundary>
            
            {/* Floating AI Assistant */}
            {!loading && !error && (
              <FloatingAIAssistant 
                currentPage={currentPageName}
                contextData={contextData}
              />
            )}
          </main>
        </div>
      </SidebarProvider>
    </ErrorBoundary>
  );
}
