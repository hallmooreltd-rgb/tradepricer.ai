
import React, { useState, useEffect, useMemo, useCallback } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Certificate } from "@/api/entities";
import { Customer } from "@/api/entities";
import { Job } from "@/api/entities";
import { User } from "@/api/entities";
import { Reminder } from "@/api/entities";
import { Photo } from "@/api/entities";
import { canUse, bumpUsage, ensureUsageMonth } from "../components/billing/usage"; // Updated path
import UpsellModal from "../components/billing/UpsellModal";
import { Company } from "@/api/entities";

import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { format, addMonths, parseISO, isValid as isValidDate } from "date-fns";
import { templates, getTemplate } from "../components/certificates/certificateTemplates";
import DynamicCertificateForm from "../components/certificates/DynamicCertificateForm";
import SignatureUpload from "../components/certificates/SignatureUpload";
import ObservationsEditor from "../components/certificates/ObservationsEditor";
import { FileText, Briefcase, User as UserIcon, Save, ArrowLeft, Send, MapPin, Loader2, Camera, ShieldCheck } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function NewCertificatePage() {
  const navigate = useNavigate();
  const location = useLocation();
  const urlParams = new URLSearchParams(location.search);

  const [user, setUser] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [selectedJobId, setSelectedJobId] = useState(urlParams.get("job_id") || "");
  const [selectedJob, setSelectedJob] = useState(null);
  const [customer, setCustomer] = useState(null);

  const [templateKey, setTemplateKey] = useState("");
  const [formData, setFormData] = useState({});
  const [signatures, setSignatures] = useState({
    installer_signature_url: "",
    customer_signature_url: "",
  });
  const [observations, setObservations] = useState([]);


  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState("");
  const [showUpsell, setShowUpsell] = useState(false); // New state for upsell modal

  // Simple local draft so users do not lose work if they navigate away
  const draftKey = useMemo(() => `draft:new-cert:${selectedJobId || "nojob"}`, [selectedJobId]);

  useEffect(() => {
    loadInitialData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadInitialData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);

      if (userData.company_id) {
        const jobData = await Job.filter(
          { company_id: userData.company_id, status: { $ne: "completed" } },
          "-created_date"
        );
        setJobs(jobData);

        // Preselect job from URL and infer template
        const preJobId = urlParams.get("job_id");
        const job = preJobId ? jobData.find(j => j.id === preJobId) : null;
        if (job) {
          setSelectedJobId(job.id);
          setSelectedJob(job);
          autoSelectTemplate(job);
          // Load customer for snapshot
          try {
            const cust = await Customer.get(job.customer_id);
            setCustomer(cust);
          } catch {
            /* ignore */
          }
        }
      }
    } catch (error) {
      console.error("Error loading data:", error);
      setErrorMsg("Could not load data. Please refresh the page.");
    } finally {
      setLoading(false);
    }
  };

  // When job changes, update snapshot and default template
  useEffect(() => {
    if (!selectedJobId || !jobs.length) return;
    const job = jobs.find(j => j.id === selectedJobId);
    setSelectedJob(job || null);
    if (job) {
      autoSelectTemplate(job);
      // fetch customer
      Customer.get(job.customer_id).then(setCustomer).catch(() => setCustomer(null));
    } else {
      setCustomer(null);
    }
    // Try restore draft for this job
    const draft = localStorage.getItem(draftKey);
    if (draft) {
      try {
        const parsed = JSON.parse(draft);
        setFormData(parsed.formData || {});
        setSignatures(parsed.signatures || { installer_signature_url: "", customer_signature_url: "" });
        if (parsed.templateKey) setTemplateKey(parsed.templateKey);
      } catch {
        /* ignore draft parse errors */
      }
    } else {
      // reset when switching jobs
      setFormData({});
      setSignatures({ installer_signature_url: "", customer_signature_url: "" });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedJobId, jobs.length]);

  const autoSelectTemplate = (job) => {
    if (!job) return;
    // Map job_type to template key
    const map = {
      boiler_install: "boiler_install",
      boiler_service: "boiler_install", // same cert family for MVP
      damp_report: "damp_report",
      roof_inspection: "roof_inspection",
      risk_assessment: "risk_assessment",
      electrical_condition_report: "electrical_condition_report",
    };
    const inferred = map[job.job_type] || "";
    if (inferred) setTemplateKey(inferred);
  };

  const handleFormChange = (newFields) => {
    setFormData(prev => {
      const next = { ...prev, ...newFields };
      localStorage.setItem(draftKey, JSON.stringify({ formData: next, signatures, templateKey }));
      return next;
    });
  };

  const handleSignatureChange = (type, url) => {
    setSignatures(prev => {
      const next = { ...prev, [type]: url };
      localStorage.setItem(draftKey, JSON.stringify({ formData, signatures: next, templateKey }));
      return next;
    });
  };

  // Some sensible defaults
  useEffect(() => {
    if (!user) return;
    setFormData(prev => {
      const next = {
        issue_date: format(new Date(), "yyyy-MM-dd"),
        installer_name: prev.installer_name || user.full_name || "",
        installer_credential_type: prev.installer_credential_type || "gas_safe",
        ...prev,
      };
      return next;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  // Default NICEIC for electrical work
  useEffect(() => {
    if (templateKey === "electrical_condition_report" && formData.installer_credential_type !== "niceic") {
      setFormData(prev => ({ ...prev, installer_credential_type: "niceic" }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [templateKey]);

  // when template changes or job changes, reset observations if not EICR
  useEffect(() => {
    if (templateKey !== "electrical_condition_report") {
      setObservations([]); // Clear observations if not EICR
      return;
    }
    // hydrate from existing formData if present
    if (Array.isArray(formData.observations)) {
      setObservations(formData.observations);
    } else {
      setObservations([]);
    }
  }, [templateKey, formData.observations]);

  // keep formData.observations in sync
  useEffect(() => {
    if (templateKey === "electrical_condition_report") {
      handleFormChange({ observations });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [observations, templateKey]);

  // auto derive outcome for EICR
  useEffect(() => {
    if (templateKey !== "electrical_condition_report") return;
    const hasC1 = observations.some(o => o.code === "C1");
    const hasC2 = observations.some(o => o.code === "C2");
    const hasFI = observations.some(o => o.code === "FI");
    const derived = hasC1 || hasC2 || hasFI ? "Unsatisfactory" : "Satisfactory";
    if (formData.outcome !== derived) {
      handleFormChange({ outcome: derived });
    }
  }, [observations, templateKey, formData.outcome]);

  const selectedTemplate = useMemo(() => getTemplate(templateKey), [templateKey]);

  const validateForm = useCallback(() => {
    const errs = [];
    if (!selectedJobId) errs.push("Please select a job.");
    if (!templateKey) errs.push("Please choose a certificate template.");

    // Relaxed validation - only require basic installer info
    if (!formData.installer_name || !formData.installer_name.trim()) {
      errs.push("Installer name is required.");
    }

    // Template dynamic required fields - only validate if they have content
    if (selectedTemplate?.dynamic_fields?.length) {
      selectedTemplate.dynamic_fields.forEach(f => {
        if (f.required) {
          const v = formData[f.name];
          const isEmpty = v === undefined || v === null || (typeof v === "string" && v.trim() === "");
          if (isEmpty) errs.push(`${f.label || f.name} is required.`);
        }
      });
    }

    // Issue date sanity check only if provided
    if (formData.issue_date) {
      const d = parseISO(formData.issue_date);
      if (!isValidDate(d)) errs.push("Issue date is invalid.");
    }

    return errs;
  }, [formData, selectedJobId, templateKey, selectedTemplate]);

  const generateCertificateNumber = async (companyId) => {
    // Try ask backend for a real sequence if available
    try {
      if (Certificate.nextSequence) {
        const seq = await Certificate.nextSequence({ company_id: companyId });
        const datePart = format(new Date(), "yyyyMM");
        return `${seq.prefix || "CERT"}-${datePart}-${String(seq.sequence).padStart(6, "0")}`;
      }
    } catch {
      // fall through
    }
    // Fallback deterministic per month using a simple counter in localStorage per company
    const datePart = format(new Date(), "yyyyMM");
    const key = `seq:${companyId}:${datePart}`;
    const current = Number(localStorage.getItem(key) || "0") + 1;
    localStorage.setItem(key, String(current));
    return `CERT-${datePart}-${String(current).padStart(6, "0")}`;
  };

  const handleSave = async () => {
    setErrorMsg("");
    const errs = validateForm();
    if (errs.length) {
      setErrorMsg(errs.join("\n"));
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }

    setSaving(true);
    try {
      const companyId = user.company_id;

      // Billing integration: Check usage limits
      const co = await Company.get(companyId);
      ensureUsageMonth(co);
      if (!canUse(co, "certs_pm", 1)) {
        setShowUpsell(true);
        setSaving(false);
        return;
      }

      const certificateNumber = await generateCertificateNumber(companyId);
      const issueDate = formData.issue_date && isValidDate(parseISO(formData.issue_date))
        ? formData.issue_date
        : format(new Date(), "yyyy-MM-dd");

      const certificateData = {
        company_id: companyId,
        job_id: selectedJobId,
        template_key: templateKey,
        certificate_number: certificateNumber,
        issue_date: issueDate,
        fields_json: JSON.stringify(formData),
        installer_name: formData.installer_name,
        installer_credential_type: formData.installer_credential_type,
        installer_credential_id: formData.installer_credential_id || "",
        ...signatures,
      };

      const newCertificate = await Certificate.create(certificateData);

      // Billing integration: Bump usage
      await bumpUsage(co, "certs_pm", 1);

      // Reminder logic with smarter channel selection
      const template = getTemplate(templateKey);
      if (template?.reminder_rule?.create_reminder) {
        const dueMonths = Number(template.reminder_rule.due_in_months || 12);
        const dueDate = format(addMonths(new Date(issueDate), dueMonths), "yyyy-MM-dd");

        // Prefer both channels only if we have both contacts
        let channel = "email";
        if (customer?.email && customer?.phone) channel = "email_and_sms";
        else if (customer?.phone && !customer?.email) channel = "sms";

        await Reminder.create({
          company_id: companyId,
          job_id: selectedJobId,
          customer_id: selectedJob?.customer_id,
          certificate_id: newCertificate.id,
          reminder_type: template.reminder_rule.reminder_type,
          due_date: dueDate,
          channel,
          message_template_key: template.reminder_rule.message_template_key,
          status: "scheduled",
        });
      }

      // Clear draft once saved
      localStorage.removeItem(draftKey);

      navigate(createPageUrl(`DeliverCertificate?id=${newCertificate.id}`));
    } catch (error) {
      console.error("Error saving certificate:", error);
      setErrorMsg("Failed to save certificate. Please check your connection and try again.");
    } finally {
      setSaving(false);
    }
  };

  // Risk helper chips for the risk_assessment template
  const commonHazards = [
    {
      label: "Working at height",
      hazards: "Falls from ladders or scaffolds. Falling objects.",
      controls: "Use certified ladders or scaffold. 3-point contact. Toe boards. Exclusion zone. Harness if required.",
      ppe: "Hard hat, safety boots, gloves, eye protection, harness where required."
    },
    {
      label: "Dust and silica",
      hazards: "Respiratory irritation. Silicosis from concrete dust.",
      controls: "Wet cutting. On-tool extraction. FFP3 masks. Damping down. Clean site regularly.",
      ppe: "FFP3 mask, goggles, gloves."
    },
    {
      label: "Manual handling",
      hazards: "Back strain, crush injuries.",
      controls: "Team lifts. Use trolleys. Keep loads close to body. Plan route.",
      ppe: "Safety boots, gloves."
    },
    {
      label: "Hot works",
      hazards: "Burns, fire, fumes.",
      controls: "Hot works permit. Fire watch. Extinguisher on site. Ventilation.",
      ppe: "Gloves, goggles, fire-retardant clothing."
    }
  ];

  if (loading) {
    return (
      <div className="p-12 flex items-center justify-center text-gray-700">
        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
        Loading form…
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => navigate(-1)} aria-label="Go back">
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">New Certificate</h1>
            <p className="text-gray-600 mt-1">Fill in the details to issue a new certificate.</p>
          </div>
        </div>

        {errorMsg && (
          <Card className="border-red-200">
            <CardContent className="text-red-700 py-4 whitespace-pre-line">
              {errorMsg}
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Briefcase className="w-5 h-5" />
              Job and Template
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="job-select">Job</Label>
              <Select value={selectedJobId} onValueChange={setSelectedJobId}>
                <SelectTrigger id="job-select">
                  <SelectValue placeholder="Select a job" />
                </SelectTrigger>
                <SelectContent>
                  {jobs.map(job => (
                    <SelectItem key={job.id} value={job.id}>
                      {job.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedJob && customer && (
                <div className="mt-3 text-sm text-gray-700 flex items-start gap-2">
                  <MapPin className="w-4 h-4 mt-0.5" />
                  <div>
                    <div className="font-medium">{customer.full_name || "Customer"}</div>
                    <div className="text-gray-600">
                      {customer.address_line1} {customer.address_line2 && `, ${customer.address_line2}`}
                      {customer.town_city && `, ${customer.town_city}`} {customer.postcode && `, ${customer.postcode}`}
                    </div>
                    {customer.phone || customer.email ? (
                      <div className="text-gray-600">
                        {customer.phone && <span>Tel: {customer.phone}</span>}
                        {customer.phone && customer.email && "  ·  "}
                        {customer.email && <span>Email: {customer.email}</span>}
                      </div>
                    ) : null}
                  </div>
                </div>
              )}
            </div>

            <div>
              <Label htmlFor="template-select">Certificate template</Label>
              <Select value={templateKey} onValueChange={setTemplateKey}>
                <SelectTrigger id="template-select">
                  <SelectValue placeholder="Select a template" />
                </SelectTrigger>
                <SelectContent>
                  {Object.values(templates).map(t => (
                    <SelectItem key={t.key} value={t.key}>{t.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {selectedTemplate && (
          <>
            {/* Installer details quick strip */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserIcon className="w-5 h-5" />
                  Installer details
                </CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <Label htmlFor="installer_name">Installer name</Label>
                  <Input
                    id="installer_name"
                    value={formData.installer_name || ""}
                    onChange={e => handleFormChange({ installer_name: e.target.value })}
                    placeholder="Full name"
                  />
                </div>
                <div>
                  <Label htmlFor="installer_credential_type">Credential type</Label>
                  <Select
                    value={formData.installer_credential_type || ""}
                    onValueChange={v => handleFormChange({ installer_credential_type: v })}
                  >
                    <SelectTrigger id="installer_credential_type">
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="gas_safe">Gas Safe</SelectItem>
                      <SelectItem value="niceic">NICEIC</SelectItem>
                      <SelectItem value="none">None</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="installer_credential_id">Credential ID</Label>
                  <Input
                    id="installer_credential_id"
                    value={formData.installer_credential_id || ""}
                    onChange={e => handleFormChange({ installer_credential_id: e.target.value })}
                    placeholder="ID or licence number"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Dynamic fields for template */}
            <DynamicCertificateForm
              template={selectedTemplate}
              formData={formData}
              onFormChange={handleFormChange}
            />

            {/* EICR Observations Editor */}
            {templateKey === "electrical_condition_report" && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5" />
                    Observations - EICR
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-700 mb-3">
                    Use codes: C1 danger present, C2 potentially dangerous, FI further investigation, C3 improvement recommended.
                    Outcome is set automatically.
                  </p>
                  <ObservationsEditor value={observations} onChange={setObservations} />
                </CardContent>
              </Card>
            )}

            {/* Risk assessment helpers */}
            {templateKey === "risk_assessment" && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5" />
                    Risk assessment helpers
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-700">
                    Quickly add common hazards and controls. You can edit after inserting.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {commonHazards.map(h => (
                      <Button
                        key={h.label}
                        type="button"
                        variant="secondary"
                        onClick={() => {
                          const hazards = [formData.hazards || "", `• ${h.label}: ${h.hazards}`].filter(Boolean).join("\n");
                          const controls = [formData.controls || "", `• ${h.label}: ${h.controls}`].filter(Boolean).join("\n");
                          const ppe = [formData.ppe_required || "", h.ppe].filter(Boolean).join("  ·  ");
                          handleFormChange({ hazards, controls, ppe_required: ppe });
                        }}
                      >
                        {h.label}
                      </Button>
                    ))}
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="md:col-span-2">
                      <Label htmlFor="hazards">Hazards</Label>
                      <Textarea
                        id="hazards"
                        rows={6}
                        value={formData.hazards || ""}
                        onChange={e => handleFormChange({ hazards: e.target.value })}
                        placeholder="List hazards here"
                      />
                    </div>
                    <div className="md:col-span-1">
                      <Label htmlFor="ppe_required">PPE required</Label>
                      <Textarea
                        id="ppe_required"
                        rows={6}
                        value={formData.ppe_required || ""}
                        onChange={e => handleFormChange({ ppe_required: e.target.value })}
                        placeholder="e.g. Hard hat, boots, gloves"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="controls">Controls</Label>
                    <Textarea
                      id="controls"
                      rows={6}
                      value={formData.controls || ""}
                      onChange={e => handleFormChange({ controls: e.target.value })}
                      placeholder="List control measures"
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Optional: quick photo capture for evidence */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Camera className="w-5 h-5" />
                  Attach job photos
                </CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <PhotoUpload jobId={selectedJobId} label="Before" />
                <PhotoUpload jobId={selectedJobId} label="During" />
                <PhotoUpload jobId={selectedJobId} label="After" />
              </CardContent>
            </Card>

            {/* Signatures */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserIcon className="w-5 h-5" />
                  Signatures
                </CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <SignatureUpload
                  label="Installer signature"
                  onSignatureChange={(url) => handleSignatureChange("installer_signature_url", url)}
                />
                <SignatureUpload
                  label="Customer signature"
                  onSignatureChange={(url) => handleSignatureChange("customer_signature_url", url)}
                />
              </CardContent>
            </Card>

            {/* Actions */}
            <Card>
              <CardFooter className="p-6 flex justify-between">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    localStorage.setItem(draftKey, JSON.stringify({ formData, signatures, templateKey }));
                    navigate(-1);
                  }}
                >
                  Save draft
                </Button>
                <Button onClick={handleSave} disabled={saving} size="lg" className="bg-blue-600 hover:bg-blue-700">
                  {saving ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Saving
                    </>
                  ) : (
                    <>
                      Generate PDF and continue
                      <Send className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </>
        )}
        <UpsellModal
          open={showUpsell}
          onClose={() => setShowUpsell(false)}
          title="Certificate limit reached"
          body="You have used your monthly certificate allowance on the Free plan. Upgrade to Pro for 30 per month and remove watermarks."
        />
      </div>
    </div>
  );
}

/**
 * Simple photo upload tile wired to your Photo entity.
 * Replace storage logic with your actual uploader if needed.
 */
function PhotoUpload({ jobId, label = "Photo" }) {
  const [uploading, setUploading] = useState(false);
  const [ok, setOk] = useState(false);

  const onFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file || !jobId) return;
    setUploading(true);
    try {
      // Assume Photo.create accepts a File via your upload system.
      // If not, swap for your uploader then call Photo.create with returned URL.
      const created = await Photo.create({
        job_id: jobId,
        label: label.toLowerCase(),
        file_url: file, // replace with uploaded URL if your SDK requires it
      });
      if (created) setOk(true);
    } catch (err) {
      console.error("Photo upload failed", err);
      alert("Photo upload failed. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="border rounded-xl p-4 bg-white">
      <Label className="block mb-2">{label}</Label>
      <Input type="file" accept="image/*" onChange={onFile} />
      <div className="text-sm mt-2">
        {uploading ? "Uploading…" : ok ? "Uploaded" : "Choose a photo to attach"}
      </div>
    </div>
  );
}
