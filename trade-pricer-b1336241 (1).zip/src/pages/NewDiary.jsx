import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { format } from "date-fns";
import { User, Job, Customer, Company, SiteDiary } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Plus, Trash2, Calendar, MapPin, Users } from "lucide-react";
import WeatherBadge from "../components/diary/WeatherBadge";
import { geocodePostcode, fetchWeather } from "../components/utils/weather";
import { createPageUrl } from "@/utils";

export default function NewDiary() {
  const navigate = useNavigate();
  const location = useLocation();
  const urlParams = new URLSearchParams(location.search);
  const preselectedJobId = urlParams.get("job_id");

  const [me, setMe] = useState(null);
  const [company, setCompany] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [selectedJobId, setSelectedJobId] = useState(preselectedJobId || "");
  const [date, setDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [postcode, setPostcode] = useState("");
  const [latlon, setLatLon] = useState(null);
  const [weather, setWeather] = useState(null);
  const [labour, setLabour] = useState([{ name: "", role: "", hours: 8 }]);
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadInitialData();
  }, []);

  const loadInitialData = async () => {
    try {
      const userData = await User.me();
      setMe(userData);
      
      if (userData.company_id) {
        const [jobData, customerData, companyData] = await Promise.all([
          Job.filter({ company_id: userData.company_id }, "-created_date", 100),
          Customer.filter({ company_id: userData.company_id }),
          Company.filter({ id: userData.company_id })
        ]);
        
        setJobs(jobData || []);
        setCustomers(customerData || []);
        setCompany(companyData[0] || null);
      }
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  // Auto-fill postcode from selected job
  useEffect(() => {
    if (!selectedJobId || !jobs.length) return;
    const selectedJob = jobs.find(j => j.id === selectedJobId);
    if (selectedJob) {
      // Try to get postcode from customer
      const customer = customers.find(c => c.id === selectedJob.customer_id);
      if (customer?.postcode && !postcode) {
        setPostcode(customer.postcode);
      }
    }
  }, [selectedJobId, jobs, customers, postcode]);

  // Fetch weather when postcode or date changes
  useEffect(() => {
    let mounted = true;
    
    const fetchWeatherData = async () => {
      if (!postcode || !date) {
        setWeather(null);
        return;
      }

      try {
        const coordinates = latlon || await geocodePostcode(postcode);
        if (!coordinates || !mounted) return;
        
        if (!latlon) setLatLon(coordinates);
        
        const weatherData = await fetchWeather(coordinates.lat, coordinates.lon, date);
        if (mounted) setWeather(weatherData);
      } catch (error) {
        console.error("Weather fetch error:", error);
        if (mounted) setWeather(null);
      }
    };

    fetchWeatherData();
    return () => { mounted = false; };
  }, [postcode, date, latlon]);

  const addLabourRow = () => {
    setLabour(prev => [...prev, { name: "", role: "", hours: 8 }]);
  };

  const updateLabourRow = (index, field, value) => {
    setLabour(prev => prev.map((row, i) => 
      i === index ? { ...row, [field]: value } : row
    ));
  };

  const removeLabourRow = (index) => {
    if (labour.length > 1) {
      setLabour(prev => prev.filter((_, i) => i !== index));
    }
  };

  const getCustomerName = (customerId) => {
    const customer = customers.find(c => c.id === customerId);
    return customer?.full_name || "";
  };

  const handleSave = async () => {
    if (!selectedJobId) {
      alert("Please select a job");
      return;
    }
    
    setSaving(true);
    try {
      const selectedJob = jobs.find(j => j.id === selectedJobId);
      const filteredLabour = labour.filter(l => l.name.trim() || l.hours > 0);
      
      const payload = {
        company_id: me.company_id,
        job_id: selectedJobId,
        customer_id: selectedJob?.customer_id,
        date,
        postcode: postcode.trim(),
        lat: latlon?.lat || null,
        lon: latlon?.lon || null,
        weather: weather || {},
        labour: filteredLabour,
        notes: notes.trim(),
      };

      const newDiary = await SiteDiary.create(payload);
      navigate(createPageUrl(`DiaryDetail?id=${newDiary.id}`));
    } catch (error) {
      console.error("Save error:", error);
      alert("Could not save site diary. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const totalHours = labour.reduce((sum, row) => sum + (Number(row.hours) || 0), 0);

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-48"></div>
          <div className="space-y-4">
            <div className="h-64 bg-gray-200 rounded"></div>
            <div className="h-48 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">New Site Diary</h1>
            <p className="text-gray-600 mt-1">
              Daily log of labour and progress with automatic weather data
            </p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Basic Information
            </CardTitle>
          </CardHeader>
          <CardContent className="grid md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="job-select">Job</Label>
              <Select value={selectedJobId} onValueChange={setSelectedJobId}>
                <SelectTrigger id="job-select">
                  <SelectValue placeholder="Select a job" />
                </SelectTrigger>
                <SelectContent>
                  {jobs.map(job => (
                    <SelectItem key={job.id} value={job.id}>
                      {job.title} - {getCustomerName(job.customer_id)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="date-input">Date</Label>
              <Input 
                id="date-input"
                type="date" 
                value={date} 
                onChange={e => setDate(e.target.value)} 
              />
            </div>
            
            <div>
              <Label htmlFor="postcode-input">Site Postcode</Label>
              <Input 
                id="postcode-input"
                placeholder="e.g. SW1A 1AA" 
                value={postcode} 
                onChange={e => setPostcode(e.target.value.toUpperCase())} 
              />
              <p className="text-xs text-gray-500 mt-1">Used to fetch weather data automatically</p>
            </div>
            
            <div className="flex items-end">
              {weather ? (
                <WeatherBadge weather={weather} />
              ) : postcode ? (
                <p className="text-sm text-gray-500">Loading weather...</p>
              ) : (
                <p className="text-sm text-gray-500">Enter postcode for weather</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Labour Record
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {labour.map((row, index) => (
              <div key={index} className="grid grid-cols-12 gap-3 items-end">
                <div className="col-span-5">
                  <Label>Name</Label>
                  <Input 
                    value={row.name} 
                    onChange={e => updateLabourRow(index, 'name', e.target.value)} 
                    placeholder="Worker name" 
                  />
                </div>
                <div className="col-span-4">
                  <Label>Role</Label>
                  <Input 
                    value={row.role} 
                    onChange={e => updateLabourRow(index, 'role', e.target.value)} 
                    placeholder="e.g. Plumber, Electrician" 
                  />
                </div>
                <div className="col-span-2">
                  <Label>Hours</Label>
                  <Input 
                    type="number" 
                    min={0} 
                    step="0.5" 
                    value={row.hours} 
                    onChange={e => updateLabourRow(index, 'hours', Number(e.target.value))} 
                  />
                </div>
                <div className="col-span-1">
                  <Button 
                    variant="outline" 
                    size="icon"
                    onClick={() => removeLabourRow(index)}
                    disabled={labour.length === 1}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
            
            <div className="flex justify-between items-center pt-4 border-t">
              <Button variant="outline" onClick={addLabourRow}>
                <Plus className="w-4 h-4 mr-2" />
                Add Person
              </Button>
              <div className="text-sm font-medium text-gray-700">
                Total Hours: {totalHours}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Daily Notes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              rows={6}
              placeholder="Record progress, delays, deliveries, site conditions, health & safety notes, materials used, visitors, issues encountered, etc."
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="resize-none"
            />
          </CardContent>
          <CardFooter className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => navigate(-1)}>
              Cancel
            </Button>
            <Button 
              onClick={handleSave} 
              disabled={saving || !selectedJobId}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {saving ? "Saving..." : "Save Site Diary"}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}