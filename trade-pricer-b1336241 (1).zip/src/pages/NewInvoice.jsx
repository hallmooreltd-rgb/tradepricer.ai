
import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { User } from "@/api/entities";
import { Company } from "@/api/entities";
import { Customer } from "@/api/entities";
import { Quote } from "@/api/entities";
import { Job } from "@/api/entities"; // Keep Job import for potential future use or if other parts of the app rely on its existence in this file
import { Invoice } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Loader2, FileText } from "lucide-react";
import { format, addDays } from "date-fns";
import QuoteItemsEditor from "../components/quotes/QuoteItemsEditor";
import { createPageUrl } from "@/utils";

export default function NewInvoice() {
  const navigate = useNavigate();
  const location = useLocation();
  const urlParams = new URLSearchParams(location.search);

  // Extract relevant parameters from URL
  const preselectedCustomerId = urlParams.get("customer_id");
  const quoteId = urlParams.get("quote_id");
  const jobId = urlParams.get("job_id"); // Keep jobId as a param, even if logic for it is removed per outline
  const fromQuote = urlParams.get("from_quote") === "true";

  // State declarations
  const [me, setMe] = useState(null);
  const [company, setCompany] = useState(null);
  const [customers, setCustomers] = useState([]);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState("");

  const [customerId, setCustomerId] = useState(preselectedCustomerId || ""); // Initialize customerId from URL param
  const [issueDate, setIssueDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [dueDate, setDueDate] = useState(format(addDays(new Date(), 14), "yyyy-MM-dd"));
  const [items, setItems] = useState([]);
  const [discountPercent, setDiscountPercent] = useState(0);
  const [notes, setNotes] = useState("Thank you for your business."); // Default notes
  const [terms, setTerms] = useState("Payment due within 14 days. Late payments may incur fees."); // Default terms
  const [logoOverride, setLogoOverride] = useState("");

  const invoiceNumber = useMemo(() => {
    const key = "seq:invoice:" + format(new Date(), "yyyyMM");
    const next = Number(localStorage.getItem(key) || "0") + 1;
    localStorage.setItem(key, String(next));
    return `INV-${format(new Date(), "yyyyMM")}-${String(next).padStart(5, "0")}`;
  }, []);

  useEffect(() => {
    const loadData = async () => {
      try {
        const userData = await User.me();
        setMe(userData);

        if (userData.company_id) {
          const [customerData, companyDataArray] = await Promise.all([
            Customer.filter({ company_id: userData.company_id }, "-created_date", 200), // Original limit and sort order retained
            Company.filter({ id: userData.company_id })
          ]);

          setCustomers(customerData || []);
          setCompany(companyDataArray[0] || null); // Company.filter returns an array, take the first one

          // If coming from a quote, pre-fill with quote data
          if (fromQuote && quoteId) {
            const quoteResult = await Quote.filter({ id: quoteId });
            const quote = quoteResult[0]; // Quote.filter returns an array
            if (quote) {
              setCustomerId(quote.customer_id);
              // Ensure items_json is parsed correctly, handling both string and already-parsed array cases
              let quoteItems = [];
              try {
                quoteItems = typeof quote.items_json === 'string'
                  ? JSON.parse(quote.items_json || '[]')
                  : Array.isArray(quote.items_json) ? quote.items_json : [];
              } catch (e) {
                console.error("Failed to parse quote items:", e);
                quoteItems = []; // Fallback to empty array on parse error
              }
              setItems(quoteItems);
              setDiscountPercent(quote.discount_percent || 0); // Retained from original logic
              setNotes(quote.notes || ""); // Set to empty string if notes are null/undefined on quote
              setTerms(quote.terms || ""); // Set to empty string if terms are null/undefined on quote
            }
          }
          // The outline removes jobId handling logic, so it's not included here.
          // The customerId is already initialized from preselectedCustomerId.
        }
      } catch (error) {
        console.error("Error loading invoice data:", error);
        setErrorMsg("Failed to load data. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [preselectedCustomerId, quoteId, fromQuote]); // Add fromQuote to dependencies

  const totals = useMemo(() => {
    const subtotal = items.reduce((acc, it) => acc + (it.quantity || 0) * (it.unit_price || 0), 0);
    const vat_total = items.reduce((acc, it) => {
      const line = (it.quantity || 0) * (it.unit_price || 0);
      return acc + line * ((it.vat_rate || 0) / 100);
    }, 0);
    const beforeDiscount = subtotal + vat_total;
    const discount = beforeDiscount * ((discountPercent || 0) / 100);
    const total = beforeDiscount - discount;
    return { subtotal, vat_total, discount, total };
  }, [items, discountPercent]);

  const validate = () => {
    const errs = [];
    if (!customerId) errs.push("Customer is required.");
    if (!items.length) errs.push("Add at least one line item.");
    if (!issueDate) errs.push("Issue date is required.");
    if (!dueDate) errs.push("Due date is required.");
    return errs;
  };

  const save = async () => {
    setErrorMsg("");
    const errs = validate();
    if (errs.length) {
      setErrorMsg(errs.join("\n"));
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    setSaving(true);
    try {
      const payload = {
        company_id: company.id,
        customer_id: customerId,
        quote_id: quoteId || undefined, // Pass quoteId if available
        job_id: jobId || undefined,     // Pass jobId if available
        invoice_number: invoiceNumber,
        issue_date: issueDate,
        due_date: dueDate,
        status: "draft",
        items_json: JSON.stringify(items),
        discount_percent: discountPercent,
        subtotal: Number(totals.subtotal.toFixed(2)),
        vat_total: Number(totals.vat_total.toFixed(2)),
        total: Number(totals.total.toFixed(2)),
        notes,
        terms,
        logo_url: logoOverride || company?.logo_url || "",
      };
      const created = await Invoice.create(payload);
      navigate(createPageUrl(`InvoiceDetail?id=${created.id}`));
    } catch (e) {
      console.error(e);
      setErrorMsg("Failed to save invoice. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="p-12 text-center">Loading…</div>;

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => navigate(-1)} aria-label="Go back">
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">New Invoice</h1>
            <p className="text-gray-600 mt-1">Create a branded invoice to bill your customer.</p>
          </div>
        </div>

        {errorMsg && (
          <Card className="border-red-200">
            <CardContent className="text-red-700 py-4 whitespace-pre-line">{errorMsg}</CardContent>
          </Card>
        )}

        <Card>
          <CardHeader><CardTitle><FileText className="inline w-5 h-5 mr-2" /> Invoice Details</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              <Label>Customer</Label>
              <Select value={customerId} onValueChange={setCustomerId}>
                <SelectTrigger><SelectValue placeholder="Select customer" /></SelectTrigger>
                <SelectContent>
                  {customers.map(c => (
                    <SelectItem key={c.id} value={c.id}>{c.full_name} {c.postcode ? `· ${c.postcode}` : ""}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Invoice Number</Label>
              <Input value={invoiceNumber} readOnly />
            </div>

            <div>
              <Label>Issue Date</Label>
              <Input type="date" value={issueDate} onChange={e => setIssueDate(e.target.value)} />
            </div>
            <div>
              <Label>Due Date</Label>
              <Input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} />
            </div>

            <div className="md:col-span-3">
              <Label>Logo Override (optional)</Label>
              <div className="flex gap-3">
                <Input
                  placeholder="https://… or leave blank for company logo"
                  value={logoOverride}
                  onChange={e => setLogoOverride(e.target.value)}
                />
                {(logoOverride || company?.logo_url) && (
                  <img src={logoOverride || company.logo_url} alt="Logo preview" className="h-10 object-contain border rounded p-1 bg-white" />
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Line Items</CardTitle></CardHeader>
          <CardContent>
            <QuoteItemsEditor items={items} onChange={setItems} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Notes, Terms & Discount</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <Label>Discount Percent</Label>
              <Input type="number" inputMode="decimal" value={discountPercent} onChange={e => setDiscountPercent(Number(e.target.value))} />
            </div>
            <div className="md:col-span-3">
              <Label>Notes</Label>
              <Textarea rows={3} value={notes} onChange={e => setNotes(e.target.value)} />
            </div>
            <div className="md:col-span-3">
              <Label>Terms</Label>
              <Textarea rows={4} value={terms} onChange={e => setTerms(e.target.value)} />
            </div>
          </CardContent>
          <CardFooter className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => navigate(-1)}>Cancel</Button>
            <Button onClick={save} disabled={saving} className="bg-blue-600 hover:bg-blue-700">
              {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving</> : "Save Invoice"}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
