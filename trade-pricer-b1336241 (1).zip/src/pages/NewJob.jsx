
import React, { useState, useEffect } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { User, Customer, Job } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { ArrowLeft, Loader2, Calendar as CalendarIcon } from "lucide-react";
import { format, parseISO } from "date-fns";
import { createPageUrl } from "@/utils";

export default function NewJob() {
  const navigate = useNavigate();
  const location = useLocation();
  const urlParams = new URLSearchParams(location.search);
  const customerIdFromUrl = urlParams.get("customer_id");
  const jobIdFromUrl = urlParams.get("job_id");

  const [isEditing, setIsEditing] = useState(!!jobIdFromUrl);
  const [me, setMe] = useState(null);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  // Form state
  const [customerId, setCustomerId] = useState(customerIdFromUrl || "");
  const [title, setTitle] = useState("");
  const [jobType, setJobType] = useState("other");
  const [scheduledDate, setScheduledDate] = useState(null);
  const [notes, setNotes] = useState("");
  const [status, setStatus] = useState("draft");

  useEffect(() => {
    const loadInitialData = async () => {
      try {
        const userData = await User.me();
        setMe(userData);

        if (userData.company_id) {
          const customerData = await Customer.filter({ company_id: userData.company_id });
          setCustomers(customerData);

          if (isEditing) {
            const jobData = await Job.get(jobIdFromUrl);
            if (jobData) {
              setTitle(jobData.title || "");
              setCustomerId(jobData.customer_id || "");
              setJobType(jobData.job_type || "other");
              setNotes(jobData.notes || "");
              setStatus(jobData.status || "draft");
              if (jobData.scheduled_date) {
                setScheduledDate(parseISO(jobData.scheduled_date));
              }
            }
          }
        }
      } catch (e) {
        console.error("Failed to load initial data:", e);
        setError("Failed to load necessary data. Please try again.");
      } finally {
        setLoading(false);
      }
    };
    loadInitialData();
  }, [isEditing, jobIdFromUrl]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!customerId || !title) {
      setError("Customer and a job title are required.");
      return;
    }
    setError("");
    setSaving(true);

    const payload = {
      company_id: me.company_id,
      customer_id: customerId,
      title,
      job_type: jobType,
      notes,
      status,
      scheduled_date: scheduledDate ? format(scheduledDate, "yyyy-MM-dd") : null,
    };

    try {
      let savedJob;
      if (isEditing) {
        savedJob = await Job.update(jobIdFromUrl, payload);
      } else {
        savedJob = await Job.create(payload);
      }
      navigate(createPageUrl(`Job?id=${savedJob.id}`));
    } catch (err) {
      console.error("Failed to save job:", err);
      setError("An error occurred while saving. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="p-8 flex justify-center items-center"><Loader2 className="w-8 h-8 animate-spin" /></div>;
  }

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-2xl mx-auto">
        <div className="mb-6">
          <Link to={createPageUrl("Jobs")} className="flex items-center text-sm text-gray-600 hover:text-gray-900">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Jobs
          </Link>
        </div>

        <form onSubmit={handleSubmit}>
          <Card>
            <CardHeader>
              <CardTitle>{isEditing ? "Edit Job" : "Create New Job"}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {error && <p className="text-sm text-red-600 bg-red-50 p-3 rounded-md">{error}</p>}

              <div>
                <Label htmlFor="customer">Customer</Label>
                <Select value={customerId} onValueChange={setCustomerId} required>
                  <SelectTrigger id="customer"><SelectValue placeholder="Select a customer" /></SelectTrigger>
                  <SelectContent>
                    {customers.map((c) => (
                      <SelectItem key={c.id} value={c.id}>{c.full_name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="title">Job Title</Label>
                <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} required />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="jobType">Job Type</Label>
                  <Select id="jobType" value={jobType} onValueChange={setJobType}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="boiler_install">Boiler Install</SelectItem>
                      <SelectItem value="boiler_service">Boiler Service</SelectItem>
                      <SelectItem value="damp_report">Damp Report</SelectItem>
                      <SelectItem value="roof_inspection">Roof Inspection</SelectItem>
                      <SelectItem value="risk_assessment">Risk Assessment</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select id="status" value={status} onValueChange={setStatus}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="scheduledDate">Scheduled Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {scheduledDate
                        ? format(scheduledDate, "PPP")
                        : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={scheduledDate}
                      onSelect={setScheduledDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Add any details about the job..." />
              </div>
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={saving} className="w-full">
                {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                {saving ? 'Saving...' : (isEditing ? 'Save Changes' : 'Create Job')}
              </Button>
            </CardFooter>
          </Card>
        </form>
      </div>
    </div>
  );
}
