import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { User, Company, Customer, Job, Variation } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Loader2 } from "lucide-react";
import { format } from "date-fns";
import QuoteItemsEditor from "../components/quotes/QuoteItemsEditor";
import { createPageUrl } from "@/utils";
import { safeJsonStringify } from "../components/utils/SafeDataUtils";
import { nextVarNo } from "../components/variations/variationUtils";

export default function NewVariation() {
  const navigate = useNavigate();
  const location = useLocation();
  const jobId = new URLSearchParams(location.search).get("job_id");

  const [me, setMe] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [selectedJobId, setSelectedJobId] = useState(jobId || "");
  const [selectedJob, setSelectedJob] = useState(null);
  
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState("");

  const [issueDate, setIssueDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [items, setItems] = useState([]);
  const [notes, setNotes] = useState("");

  useEffect(() => {
    const loadData = async () => {
      try {
        const user = await User.me();
        setMe(user);
        const companyJobs = await Job.filter({ company_id: user.company_id, status: { $ne: "completed" } });
        setJobs(companyJobs);
        if (jobId) {
            const preselectedJob = companyJobs.find(j => j.id === jobId);
            setSelectedJob(preselectedJob);
        }
      } catch (e) {
        setErrorMsg("Failed to load initial data.");
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  useEffect(() => {
    if (selectedJobId) {
      const job = jobs.find(j => j.id === selectedJobId);
      setSelectedJob(job || null);
    } else {
        setSelectedJob(null);
    }
  }, [selectedJobId, jobs]);

  const totals = useMemo(() => {
    const total = items.reduce((acc, it) => {
      const ex = (it.quantity || 0) * (it.unit_price || 0);
      const inc = ex * (1 + (it.vat_rate || 0) / 100);
      return acc + inc;
    }, 0);
    return { total };
  }, [items]);

  const handleSave = async () => {
    if (!selectedJob) {
        setErrorMsg("Please select a job.");
        return;
    }
    setErrorMsg("");
    setSaving(true);
    try {
      const payload = {
        company_id: me.company_id,
        job_id: selectedJob.id,
        customer_id: selectedJob.customer_id,
        variation_number: nextVarNo(me.company_id),
        issue_date: issueDate,
        items_json: safeJsonStringify(items),
        total: totals.total,
        notes,
        status: 'draft',
      };
      const created = await Variation.create(payload);
      navigate(createPageUrl(`VariationDetail?id=${created.id}`));
    } catch (e) {
      console.error(e);
      setErrorMsg("Failed to save variation.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="p-8"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => navigate(-1)}><ArrowLeft className="w-4 h-4" /></Button>
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">New Variation</h1>
        </div>

        {errorMsg && <Card className="border-red-200"><CardContent className="text-red-700 py-4">{errorMsg}</CardContent></Card>}

        <Card>
          <CardHeader><CardTitle>Details</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label>Job</Label>
              <Select value={selectedJobId} onValueChange={setSelectedJobId}>
                <SelectTrigger><SelectValue placeholder="Select a job" /></SelectTrigger>
                <SelectContent>
                  {jobs.map(j => <SelectItem key={j.id} value={j.id}>{j.title}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Issue Date</Label>
              <Input type="date" value={issueDate} onChange={e => setIssueDate(e.target.value)} />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Line Items</CardTitle></CardHeader>
          <CardContent><QuoteItemsEditor items={items} onChange={setItems} /></CardContent>
        </Card>
        <Card>
            <CardHeader><CardTitle>Notes</CardTitle></CardHeader>
            <CardContent>
                <Textarea rows={4} value={notes} onChange={e => setNotes(e.target.value)} placeholder="Notes for the customer about this variation." />
            </CardContent>
            <CardFooter className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => navigate(-1)}>Cancel</Button>
                <Button onClick={handleSave} disabled={saving}>
                    {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving</> : "Save Variation"}
                </Button>
            </CardFooter>
        </Card>
      </div>
    </div>
  );
}