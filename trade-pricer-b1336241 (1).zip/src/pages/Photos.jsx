
import React, { useState, useEffect } from "react";
import { Photo, Job, User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { UploadFile } from "@/api/integrations";
import { Plus, Camera, Upload, Image as ImageIcon } from "lucide-react";
import { format } from "date-fns";

const labelColors = {
  before: "bg-blue-100 text-blue-700",
  during: "bg-yellow-100 text-yellow-700", 
  after: "bg-green-100 text-green-700",
  serial_plate: "bg-purple-100 text-purple-700",
  pressure_gauge: "bg-pink-100 text-pink-700",
  other: "bg-gray-100 text-gray-700"
};

export default function Photos() {
  const [photos, setPhotos] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [user, setUser] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      if (userData.company_id) {
        const [photoData, jobData] = await Promise.all([
          Photo.filter({ company_id: userData.company_id }, "-created_date"),
          Job.filter({ company_id: userData.company_id })
        ]);
        
        setPhotos(photoData);
        setJobs(jobData);
      }
    } catch (error) {
      console.error("Error loading photos:", error);
    }
    setLoading(false);
  };

  const handleFileUpload = async (event) => {
    const files = Array.from(event.target.files);
    if (files.length === 0) return;

    setUploading(true);
    try {
      for (const file of files) {
        const { file_url } = await UploadFile({ file });
        
        await Photo.create({
          company_id: user.company_id,
          job_id: "temp", // In real implementation, user would select job
          file_url: file_url,
          label: "other"
        });
      }
      
      await loadData();
    } catch (error) {
      console.error("Error uploading photos:", error);
    }
    setUploading(false);
  };

  const getJobTitle = (jobId) => {
    const job = jobs.find(j => j.id === jobId);
    return job?.title || "Unknown Job";
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-48"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="h-64 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Photos</h1>
            <p className="text-gray-600 mt-1">
              Manage job photos and documentation
            </p>
          </div>
          <div className="flex gap-3">
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
              id="photo-upload"
              disabled={uploading}
            />
            <label htmlFor="photo-upload">
              <Button 
                className="bg-blue-600 hover:bg-blue-700" 
                disabled={uploading}
                asChild
              >
                <span>
                  {uploading ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  ) : (
                    <Plus className="w-4 h-4 mr-2" />
                  )}
                  {uploading ? 'Uploading...' : 'Upload Photos'}
                </span>
              </Button>
            </label>
          </div>
        </div>

        {photos.length === 0 ? (
          <Card className="p-8 text-center">
            <div className="space-y-4 max-w-2xl mx-auto">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                <Camera className="w-8 h-8 text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">About Job Photos</h3>
                <p className="text-gray-600 mb-4 leading-relaxed">
                  Here is where you can upload and manage photos from your jobs. Photos provide valuable documentation 
                  for warranty purposes, compliance records, and customer transparency.
                </p>
                <div className="bg-green-50 p-4 rounded-lg mb-4">
                  <p className="text-sm text-green-800 leading-relaxed">
                    <strong>Example scenario:</strong> During a boiler installation, you take photos of the old unit before removal, 
                    the new installation in progress, and the completed work. You also photograph the serial plate and pressure 
                    readings. These photos can be attached to certificates and help resolve any future warranty claims.
                  </p>
                </div>
                <p className="text-gray-500 mb-4">No photos uploaded yet.</p>
                <label htmlFor="photo-upload">
                  <Button asChild>
                    <span>
                      <Upload className="w-4 h-4 mr-2" />
                      Upload Your First Photos
                    </span>
                  </Button>
                </label>
              </div>
            </div>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {photos.map((photo) => (
              <Card key={photo.id} className="overflow-hidden group hover:shadow-lg transition-shadow duration-200">
                <div className="aspect-square bg-gray-100 relative overflow-hidden">
                  <img
                    src={photo.file_url}
                    alt="Job photo"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                    loading="lazy"
                  />
                  <div className="absolute top-2 left-2">
                    <Badge className={`${labelColors[photo.label]} border`}>
                      {photo.label.replace('_', ' ')}
                    </Badge>
                  </div>
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-200 flex items-center justify-center">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-white hover:bg-white"
                      onClick={() => window.open(photo.file_url, '_blank')}
                    >
                      <ImageIcon className="w-4 h-4 mr-2" />
                      View Full
                    </Button>
                  </div>
                </div>
                <CardContent className="p-4">
                  <div className="space-y-2">
                    <h3 className="font-medium text-gray-900 truncate">
                      {getJobTitle(photo.job_id)}
                    </h3>
                    <p className="text-sm text-gray-500">
                      {format(new Date(photo.created_date), "MMM d, yyyy 'at' h:mm a")}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
