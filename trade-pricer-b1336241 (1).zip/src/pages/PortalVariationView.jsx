import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { Variation, Customer, Job, Company } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, CheckCircle, AlertCircle } from "lucide-react";
import SignaturePad from "../components/certificates/SignaturePad";
import { UploadFile } from "@/api/integrations";

export default function PortalVariationView() {
  const location = useLocation();
  const urlParams = new URLSearchParams(location.search);
  const variationId = urlParams.get("id");
  const customerToken = location.pathname.split('/')[2]; // Extract from /portal/:token/variation

  const [variation, setVariation] = useState(null);
  const [customer, setCustomer] = useState(null);
  const [job, setJob] = useState(null);
  const [company, setCompany] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [sig, setSig] = useState(null);
  const [reason, setReason] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        // Load customer by token
        const customers = await Customer.filter({ portal_token: customerToken });
        const customerData = customers[0];
        if (!customerData) throw new Error("Invalid access token.");
        setCustomer(customerData);

        // Load variation
        const variations = await Variation.filter({ id: variationId });
        const variationData = variations[0];
        if (!variationData) throw new Error("Variation not found.");
        setVariation(variationData);

        // Load related data
        const [jobData, companyData] = await Promise.all([
          Job.filter({ id: variationData.job_id }).then(jobs => jobs[0]),
          Company.filter({ id: variationData.company_id }).then(companies => companies[0])
        ]);
        
        setJob(jobData);
        setCompany(companyData);

        // Verify customer owns this variation
        if (variationData.customer_id !== customerData.id) {
          throw new Error("You don't have permission to view this variation.");
        }
      } catch(e) {
        console.error("Error loading variation:", e);
        setError(e.message || "Failed to load variation.");
      } finally {
        setLoading(false);
      }
    };
    
    if (variationId && customerToken) load();
  }, [variationId, customerToken]);

  const gbp = (n) => new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

  const handleSignatureUpload = async (blob) => {
    try {
      const { file_url } = await UploadFile({ file: blob });
      return file_url;
    } catch (error) {
      console.error("Error uploading signature:", error);
      throw error;
    }
  };

  const approve = async () => {
    if (!sig) {
      alert("Please provide a signature to approve.");
      return;
    }
    setSubmitting(true);
    try {
      const signature_url = await handleSignatureUpload(sig);
      await Variation.update(variation.id, {
        status: "approved",
        approved_by_signature_url: signature_url,
        approved_by_name: customer.full_name || "Customer",
        approved_at: new Date().toISOString(),
      });
      setVariation(v => ({ ...v, status: 'approved' }));
    } catch (e) {
        console.error("Error approving variation:", e);
        alert("Could not save approval. Please try again.");
    } finally {
        setSubmitting(false);
    }
  };

  const reject = async () => {
    setSubmitting(true);
    try {
      await Variation.update(variation.id, {
        status: "rejected",
        rejection_reason: reason || "No reason provided",
      });
      setVariation(v => ({ ...v, status: 'rejected' }));
    } catch (e) {
        console.error("Error rejecting variation:", e);
        alert("Could not save rejection. Please try again.");
    } finally {
        setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="p-8 flex justify-center">
        <Loader2 className="animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8 text-center text-red-500">
        <AlertCircle className="w-8 h-8 mx-auto mb-2" />
        {error}
      </div>
    );
  }

  const items = Array.isArray(variation.items_json) 
    ? variation.items_json 
    : JSON.parse(variation.items_json || '[]');

  return (
    <div className="p-4 lg:p-8 bg-gray-100 min-h-screen">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-6">
          {company?.logo_url && (
            <img src={company.logo_url} alt={company?.name} className="h-16 mx-auto mb-2" />
          )}
          <h1 className="text-2xl font-bold">{company?.name || "CertiFlow Pro"}</h1>
          <p className="text-gray-600">Variation Approval</p>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Variation {variation.variation_number}</CardTitle>
            <p className="text-sm text-gray-600">Job: {job?.title}</p>
          </CardHeader>
          <CardContent>
            <div className="border rounded-xl overflow-hidden">
              <table className="min-w-full text-sm">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="text-left p-2">Description</th>
                    <th className="text-left p-2">Qty</th>
                    <th className="text-left p-2">Unit ex VAT</th>
                    <th className="text-left p-2">VAT</th>
                    <th className="text-right p-2">Line inc VAT</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((it, i) => {
                    const ex = (Number(it.quantity)||0) * (Number(it.unit_price)||0);
                    const inc = ex * (1 + (Number(it.vat_rate)||0)/100);
                    return (
                      <tr key={i} className="border-t">
                        <td className="p-2">{it.description}</td>
                        <td className="p-2">{it.quantity}</td>
                        <td className="p-2">{gbp(it.unit_price)}</td>
                        <td className="p-2">{it.vat_rate}%</td>
                        <td className="p-2 text-right">{gbp(inc)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <div className="mt-3 text-right text-lg font-bold">Total {gbp(variation.total)}</div>
            
            {variation.notes && (
              <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                <p className="text-sm font-medium text-gray-700 mb-1">Notes:</p>
                <p className="text-sm text-gray-600 whitespace-pre-wrap">{variation.notes}</p>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex flex-col gap-4">
            {variation.status === "approved" && (
              <div className="text-green-700 flex items-center gap-2">
                <CheckCircle className="w-5 h-5" />
                Already approved. Thank you.
              </div>
            )}
            {variation.status === "rejected" && (
              <div className="text-red-700 flex items-center gap-2">
                <AlertCircle className="w-5 h-5" />
                You have rejected this variation.
              </div>
            )}
            {variation.status === "sent" && (
              <>
                <div className="w-full">
                  <Label className="mb-2 block">Sign to approve</Label>
                  <SignaturePad 
                    height={180} 
                    onSignatureChange={setSig} 
                    upload={handleSignatureUpload}
                    label="Customer Signature" 
                  />
                </div>
                <div className="w-full">
                  <Label>Reason if rejecting (optional)</Label>
                  <Textarea 
                    rows={3} 
                    value={reason} 
                    onChange={e => setReason(e.target.value)}
                    placeholder="Please explain why you are rejecting this variation..."
                  />
                </div>
                <div className="flex gap-2 justify-end w-full">
                  <Button variant="outline" onClick={reject} disabled={submitting}>
                    {submitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                    Reject
                  </Button>
                  <Button onClick={approve} className="bg-blue-600 hover:bg-blue-700" disabled={submitting}>
                    {submitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                    Approve Variation
                  </Button>
                </div>
              </>
            )}
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}