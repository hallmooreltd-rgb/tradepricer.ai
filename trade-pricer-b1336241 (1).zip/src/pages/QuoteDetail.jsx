
import React, { useState, useEffect } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import { User, Company, Customer, Quote } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Loader2, ArrowLeft, Pencil, FileText, CheckCircle, Mail, Trash2, AlertCircle, Send, Edit } from "lucide-react";
import { createPageUrl } from "@/utils";
import { safeJsonParse } from "../components/utils/SafeDataUtils";
import SendQuoteModal from "../components/quotes/SendQuoteModal";
import DeleteConfirmationModal from "../components/shared/DeleteConfirmationModal";
import { format } from "date-fns";

const statusColors = {
  draft: "bg-gray-100 text-gray-700 border-gray-200",
  sent: "bg-blue-100 text-blue-700 border-blue-200",
  accepted: "bg-green-100 text-green-700 border-green-200",
  declined: "bg-red-100 text-red-700 border-red-200",
  expired: "bg-yellow-100 text-yellow-700 border-yellow-200",
  default: "bg-gray-100 text-gray-700 border-gray-200"
};

export default function QuoteDetail() {
  const navigate = useNavigate();
  const location = useLocation();
  const quoteId = new URLSearchParams(location.search).get("id");

  const [me, setMe] = useState(null);
  const [company, setCompany] = useState(null);
  const [customer, setCustomer] = useState(null);
  const [quote, setQuote] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [isDeleteModalOpen, setDeleteModalOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isSendModalOpen, setSendModalOpen] = useState(false);
  const [creatingInvoice, setCreatingInvoice] = useState(false);

  // Editable email content
  const [isEditing, setIsEditing] = useState(false);
  const [emailContent, setEmailContent] = useState({
    subject: "",
    greeting: "",
    description: "",
    materials_section: "",
    labour_section: "",
    terms: "",
    closing: ""
  });

  const gbp = (n) => new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

  const loadData = async () => {
    if (!quoteId) {
      setError("No quote ID provided in the URL.");
      setLoading(false);
      return;
    }
    setLoading(true);
    setError("");
    try {
      const user = await User.me();
      setMe(user);

      const quotes = await Quote.filter({ id: quoteId });
      const quoteData = quotes[0];

      if (!quoteData) {
        setError("Quote not found.");
        setLoading(false);
        return;
      }
      
      let parsedQuote = { ...quoteData };
      if (typeof parsedQuote.items_json === 'string') {
        try {
          parsedQuote.items_json = JSON.parse(parsedQuote.items_json);
        } catch (e) {
          console.error("Failed to parse quote items JSON:", e);
          parsedQuote.items_json = [];
        }
      } else if (!Array.isArray(parsedQuote.items_json)) {
        parsedQuote.items_json = [];
      }
      setQuote(parsedQuote);

      const [companyResult, customerResult] = await Promise.all([
        user.company_id ? Company.filter({ id: user.company_id }) : Promise.resolve([]),
        parsedQuote.customer_id ? Customer.filter({ id: parsedQuote.customer_id }) : Promise.resolve([])
      ]);

      setCompany(companyResult[0] || null);
      setCustomer(customerResult[0] || null);

      // Generate default email content
      generateEmailContent(parsedQuote, customerResult[0], companyResult[0]);

    } catch (e) {
      console.error("Failed to load quote details:", e);
      setError("Failed to load quote details. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const generateEmailContent = (quoteData, customerData, companyData) => {
    const items = quoteData.items_json || [];
    
    // Separate materials and labour
    const materialItems = items.filter(item => 
      !(item.category === 'labour' || item.description.toLowerCase().includes('labour') || item.description.toLowerCase().includes('install'))
    );
    
    const labourItems = items.filter(item => 
      item.category === 'labour' || item.description.toLowerCase().includes('labour') || item.description.toLowerCase().includes('install')
    );

    const formatSection = (sectionTitle, sectionItems) => {
        if (!sectionItems || sectionItems.length === 0) return "";

        const sectionTotal = sectionItems.reduce((sum, item) => 
          sum + ((item.quantity || 0) * (item.unit_price || 0) * (1 + (item.vat_rate || 0) / 100)), 0
        );

        const header = `${'Description'.padEnd(40)} ${'Qty'.padStart(5)} ${'x'.padStart(3)} ${'Unit Price'.padStart(12)} ${'='.padStart(3)} ${'Line Total'.padStart(12)}`;
        const separator = '-'.repeat(80);

        const itemLines = sectionItems.map(item => {
            const desc = (item.description || '').length > 38 ? `${item.description.substring(0, 35)}...` : item.description;
            const qty = (item.quantity || 0).toString();
            const unitPrice = gbp((item.unit_price || 0) * (1 + (item.vat_rate || 0) / 100)).padStart(12); // Price including VAT
            const lineTotal = gbp((item.quantity || 0) * (item.unit_price || 0) * (1 + (item.vat_rate || 0) / 100)).padStart(12);

            return `${desc.padEnd(40)} ${qty.padStart(5)} ${'x'.padStart(3)} ${unitPrice} ${'='.padStart(3)} ${lineTotal}`;
        }).join('\n');
        
        const totalLine = `${'Total'.padStart(65)} ${gbp(sectionTotal).padStart(12)}`;

        return `${sectionTitle}\n\n${separator}\n${header}\n${separator}\n${itemLines}\n${separator}\n${totalLine}\n`;
    };

    const materialsSection = formatSection("Materials & Supplies", materialItems);
    const labourSection = formatSection("Labour & Installation", labourItems);

    setEmailContent({
      subject: `Quotation ${customerData?.full_name || 'Your Project'}`,
      greeting: `Dear ${customerData?.full_name || 'Valued Customer'},

Thank you for your enquiry. Please find below our detailed quotation for the work requested.`,
      description: quoteData.scope_of_work || `We are pleased to provide the following quotation for your project:`,
      materials_section: materialsSection,
      labour_section: labourSection,
      terms: quoteData.terms || `Terms & Conditions:\n• All prices include VAT\n• Quote valid for 30 days from issue date\n• 50% deposit required to commence work\n• Payment due within 30 days of completion\n• All work carried out to current British Standards`,
      closing: `Should you have any questions or require clarification on any aspect of this quotation, please don't hesitate to contact us.

We look forward to hearing from you.

Best regards,
${companyData?.name || 'The Team'}
${companyData?.phone ? `Tel: ${companyData.phone}` : ''}
${companyData?.email ? `Email: ${companyData.email}` : ''}`
    });
  };

  useEffect(() => {
    loadData();
  }, [quoteId]);

  const handleSave = async () => {
    // Save the updated email content back to the quote
    try {
      // For simplicity, we are saving description and terms back to quote properties
      // Note: materials_section and labour_section are derived and not directly editable via quote properties
      // If full email content needs to be stored, a new field on Quote would be required.
      const updatedNotes = emailContent.description; // We are only saving description to notes, as sections are generated.
      await Quote.update(quote.id, {
        notes: updatedNotes,
        terms: emailContent.terms
      });
      setIsEditing(false);
      // Reload to get updated data
      await loadData();
    } catch (error) {
      console.error("Error updating quote:", error);
      setError("Failed to save changes. Please try again.");
    }
  };

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      await Quote.delete(quote.id);
      navigate(createPageUrl("Quotes"));
    } catch (e) {
      console.error("Failed to delete quote:", e);
      setError("Failed to delete quote. Please try again.");
      setIsDeleting(false);
      setDeleteModalOpen(false);
    }
  };

  const handleCreateInvoice = async () => {
    if (!quote || !customer) return;
    
    setCreatingInvoice(true);
    try {
      // Navigate to new invoice page with quote data pre-filled
      const queryParams = new URLSearchParams({
        customer_id: customer.id,
        quote_id: quote.id,
        from_quote: 'true'
      });
      
      navigate(createPageUrl(`NewInvoice?${queryParams.toString()}`));
    } catch (error) {
      console.error("Error creating invoice:", error);
    } finally {
      setCreatingInvoice(false);
    }
  };

  const portalUrl = quote && customer ? `${window.location.origin}${createPageUrl(`CustomerPortal?quote_id=${quote.id}&customer_id=${customer.id}`)}` : '';

  if (loading) {
    return (
      <div className="p-8 text-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600 mx-auto mb-4" />
        <p>Loading quote details...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8 text-center">
        <div className="max-w-md mx-auto">
          <div className="bg-red-50 border border-red-200 rounded-lg p-6">
            <h2 className="text-lg font-semibold text-red-800 mb-2">Unable to Load Quote</h2>
            <p className="text-red-700 mb-4">{error}</p>
            <div className="flex gap-3 justify-center">
              <Button onClick={() => navigate(createPageUrl("Quotes"))}>
                Back to Quotes
              </Button>
              {quoteId && (
                <Button variant="outline" onClick={() => window.location.reload()}>
                  Try Again
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!quote) {
    return (
      <div className="p-8 text-center">
        <div className="max-w-md mx-auto">
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
            <h2 className="text-lg font-semibold text-gray-800 mb-2">Quote Not Found</h2>
            <p className="text-gray-600 mb-4">The quote you're looking for doesn't exist or has been deleted.</p>
            <Button onClick={() => navigate(createPageUrl("Quotes"))}>
              Back to Quotes
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const isAiQuote = quote.quote_number?.startsWith('AI-QUO') || false;
  const canEdit = ['draft', 'sent'].includes(quote.status);
  const editUrl = isAiQuote
    ? createPageUrl(`AiQuoteEditor?id=${quote.id}`)
    : createPageUrl(`QuoteEditor?id=${quote.id}`);
  
  const canDelete = quote.status === 'draft';
  const canCreateInvoice = quote.status === 'accepted';

  return (
    <>
      <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
            <div>
              <Button variant="outline" size="sm" onClick={() => navigate(createPageUrl("Quotes"))} className="mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Quotes
              </Button>
              <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Quote #{quote.quote_number}</h1>
              <p className="text-gray-600 mt-1">
                For: {customer?.full_name || "N/A"}
              </p>
            </div>
            <div className="flex items-center gap-2 mt-2 sm:mt-0 flex-wrap">
              <Badge variant="outline" className={`${statusColors[quote.status] || statusColors.default} whitespace-nowrap`}>
                {quote.status === "accepted" && <CheckCircle className="w-4 h-4 mr-1" />}
                {quote.status?.charAt(0).toUpperCase() + quote.status?.slice(1)}
              </Badge>
              {canCreateInvoice && (
                <Button 
                  onClick={handleCreateInvoice}
                  disabled={creatingInvoice}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {creatingInvoice ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <FileText className="w-4 h-4 mr-2" />
                      Create Invoice
                    </>
                  )}
                </Button>
              )}
              {canDelete && (
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setDeleteModalOpen(true)}
                  className="text-red-600 border-red-200 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
              )}
              {canEdit && (
                <Link to={editUrl}>
                  <Button variant="secondary" size="sm">
                    <Pencil className="w-4 h-4 mr-2" />
                    Edit Items
                  </Button>
                </Link>
              )}
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setIsEditing(!isEditing)}
                className={isEditing ? "bg-blue-50 border-blue-200" : ""}
              >
                <Edit className="w-4 h-4 mr-2" />
                {isEditing ? 'Preview' : 'Edit Email'}
              </Button>
            </div>
          </div>

          {quote.status === "accepted" && quote.accepted_at && (
            <Alert className="border-green-200 bg-green-50">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertTitle className="text-green-800">Quote Accepted</AlertTitle>
              <AlertDescription className="text-green-700">
                This quote was accepted on {new Date(quote.accepted_at).toLocaleDateString()}. 
                You can now create an invoice to request payment.
              </AlertDescription>
            </Alert>
          )}

          {/* Email Quotation Format */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Mail className="w-5 h-5" />
                Quotation Email
              </CardTitle>
              {customer && company && quote.status === "draft" && (
                <Button 
                  onClick={() => setSendModalOpen(true)} 
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Send className="w-4 h-4 mr-2" />
                  Send Quote
                </Button>
              )}
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Email Subject */}
              <div>
                <Label>Subject Line</Label>
                {isEditing ? (
                  <Input
                    value={emailContent.subject}
                    onChange={(e) => setEmailContent({...emailContent, subject: e.target.value})}
                    className="mt-1"
                  />
                ) : (
                  <div className="mt-1 p-3 bg-gray-50 rounded border font-medium">
                    {emailContent.subject}
                  </div>
                )}
              </div>

              {/* Email Body */}
              <div className="space-y-4 bg-white border rounded-lg p-6">
                {/* Greeting */}
                <div>
                  {isEditing ? (
                    <Textarea
                      value={emailContent.greeting}
                      onChange={(e) => setEmailContent({...emailContent, greeting: e.target.value})}
                      rows={3}
                      className="mb-4"
                    />
                  ) : (
                    <div className="mb-4 whitespace-pre-wrap text-gray-900">
                      {emailContent.greeting}
                    </div>
                  )}
                </div>

                {/* Project Description */}
                <div>
                  <Label className="text-sm font-medium text-gray-700">Project Description</Label>
                  {isEditing ? (
                    <Textarea
                      value={emailContent.description}
                      onChange={(e) => setEmailContent({...emailContent, description: e.target.value})}
                      rows={4}
                      className="mt-1"
                    />
                  ) : (
                    <div className="mt-1 p-3 bg-blue-50 rounded border whitespace-pre-wrap">
                      {emailContent.description}
                    </div>
                  )}
                </div>

                {/* Materials Section */}
                {emailContent.materials_section && (
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Materials & Supplies</Label>
                    {isEditing ? (
                      <Textarea
                        value={emailContent.materials_section}
                        onChange={(e) => setEmailContent({...emailContent, materials_section: e.target.value})}
                        rows={10}
                        className="mt-1 font-mono text-sm leading-relaxed"
                      />
                    ) : (
                      <div className="mt-1 p-4 bg-green-50 rounded border whitespace-pre-wrap font-mono text-sm leading-relaxed">
                        {emailContent.materials_section}
                      </div>
                    )}
                  </div>
                )}

                {/* Labour Section */}
                {emailContent.labour_section && (
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Labour & Installation</Label>
                    {isEditing ? (
                      <Textarea
                        value={emailContent.labour_section}
                        onChange={(e) => setEmailContent({...emailContent, labour_section: e.target.value})}
                        rows={8}
                        className="mt-1 font-mono text-sm leading-relaxed"
                      />
                    ) : (
                      <div className="mt-1 p-4 bg-orange-50 rounded border whitespace-pre-wrap font-mono text-sm leading-relaxed">
                        {emailContent.labour_section}
                      </div>
                    )}
                  </div>
                )}

                {/* Quote Total */}
                <div className="border-t pt-4">
                  <div className="flex justify-between items-center text-lg font-bold">
                    <span>Total Quote Value:</span>
                    <span className="text-2xl text-blue-600">{gbp(quote.total)}</span>
                  </div>
                  <div className="text-sm text-gray-600 mt-1">
                    Subtotal: {gbp(quote.subtotal)} | VAT: {gbp(quote.vat_total)}
                  </div>
                </div>

                {/* Terms */}
                <div>
                  <Label className="text-sm font-medium text-gray-700">Terms & Conditions</Label>
                  {isEditing ? (
                    <Textarea
                      value={emailContent.terms}
                      onChange={(e) => setEmailContent({...emailContent, terms: e.target.value})}
                      rows={6}
                      className="mt-1"
                    />
                  ) : (
                    <div className="mt-1 p-3 bg-gray-50 rounded border whitespace-pre-wrap text-sm">
                      {emailContent.terms}
                    </div>
                  )}
                </div>

                {/* Closing */}
                <div>
                  {isEditing ? (
                    <Textarea
                      value={emailContent.closing}
                      onChange={(e) => setEmailContent({...emailContent, closing: e.target.value})}
                      rows={6}
                      className="mt-1"
                    />
                  ) : (
                    <div className="mt-1 whitespace-pre-wrap text-gray-900">
                      {emailContent.closing}
                    </div>
                  )}
                </div>
              </div>

              {isEditing && (
                <div className="flex justify-end gap-3">
                  <Button variant="outline" onClick={() => setIsEditing(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700">
                    Save Changes
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Send Quote Modal */}
      <SendQuoteModal
        open={isSendModalOpen}
        onClose={() => setSendModalOpen(false)}
        company={company}
        customer={customer}
        quote={quote}
        portalUrl={portalUrl}
        onMarkSent={loadData}
      />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={handleDelete}
        title="Delete Quote"
        message={`Are you sure you want to delete quote ${quote.quote_number}? This action cannot be undone.`}
        isDeleting={isDeleting}
      />
    </>
  );
}
