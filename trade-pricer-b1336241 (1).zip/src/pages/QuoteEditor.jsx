import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { User, Company, Customer, Quote } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Loader2 } from "lucide-react";
import { format, addDays } from "date-fns";
import QuoteItemsEditor from "../components/quotes/QuoteItemsEditor";
import { createPageUrl } from "@/utils";
import { safeJsonStringify, safeJsonParse } from "../components/utils/SafeDataUtils";

export default function QuoteEditor() {
  const navigate = useNavigate();
  const location = useLocation();
  const quoteId = new URLSearchParams(location.search).get("id");
  const isEditing = !!quoteId;

  const [me, setMe] = useState(null);
  const [company, setCompany] = useState(null);
  const [customers, setCustomers] = useState([]);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState("");

  const [selectedCustomerId, setSelectedCustomerId] = useState(new URLSearchParams(location.search).get("customer_id") || "");
  const [issueDate, setIssueDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [expiryDate, setExpiryDate] = useState(format(addDays(new Date(), 30), "yyyy-MM-dd"));
  const [items, setItems] = useState([]);
  const [discountPercent, setDiscountPercent] = useState(0);
  const [notes, setNotes] = useState("");
  const [terms, setTerms] = useState("All prices include VAT unless stated. Quote valid for 30 days. Work scheduled upon deposit payment.");
  const [logoOverride, setLogoOverride] = useState("");
  const [quoteNumber, setQuoteNumber] = useState('');
  const [quote, setQuote] = useState(null);

  const generateQuoteNumber = useMemo(() => {
    if (isEditing && quote?.quote_number) return quote.quote_number;
    
    const key = "seq:quote:" + format(new Date(), "yyyyMM");
    const next = Number(localStorage.getItem(key) || "0") + 1;
    localStorage.setItem(key, String(next));
    return `QUO-${format(new Date(), "yyyyMM")}-${String(next).padStart(5, "0")}`;
  }, [isEditing, quote?.quote_number]);

  useEffect(() => {
    const loadCommonData = async () => {
      try {
        const user = await User.me();
        setMe(user);

        if (!user || !user.company_id) {
          setErrorMsg("Your user account is not associated with a company. Please contact support.");
          setLoading(false);
          return;
        }

        const [co, custs] = await Promise.all([
          Company.filter({ id: user.company_id }),
          Customer.filter({ company_id: user.company_id }, "-created_date", 200)
        ]);
        
        const fetchedCompany = co[0] || null;
        setCompany(fetchedCompany);
        setCustomers(custs || []);

        if (isEditing) {
          const quotes = await Quote.filter({ id: quoteId });
          const quoteToEdit = quotes[0];
          if (quoteToEdit) {
            setQuote(quoteToEdit);
            setSelectedCustomerId(quoteToEdit.customer_id);
            setIssueDate(format(new Date(quoteToEdit.issue_date), "yyyy-MM-dd"));
            setExpiryDate(format(new Date(quoteToEdit.expiry_date), "yyyy-MM-dd"));
            setItems(safeJsonParse(quoteToEdit.items_json, []));
            setDiscountPercent(quoteToEdit.discount_percent || 0);
            setNotes(quoteToEdit.notes || "");
            setTerms(quoteToEdit.terms || fetchedCompany?.default_terms || "All prices include VAT unless stated. Quote valid for 30 days. Work scheduled upon deposit payment.");
            setLogoOverride(quoteToEdit.logo_url || "");
            setQuoteNumber(quoteToEdit.quote_number);
          } else {
            setErrorMsg("Quote not found for editing.");
          }
        } else {
          setQuoteNumber(generateQuoteNumber);
          setTerms(fetchedCompany?.default_terms || "All prices include VAT unless stated. Quote valid for 30 days. Work scheduled upon deposit payment.");
        }
      } catch (e) {
        console.error(e);
        setErrorMsg("Could not load required data.");
      } finally {
        setLoading(false);
      }
    };
    loadCommonData();
  }, [isEditing, quoteId, generateQuoteNumber]);

  const totals = useMemo(() => {
    const subtotal = items.reduce((acc, it) => acc + (it.quantity || 0) * (it.unit_price || 0), 0);
    const vat_total = items.reduce((acc, it) => {
      const line = (it.quantity || 0) * (it.unit_price || 0);
      return acc + line * ((it.vat_rate || 0) / 100);
    }, 0);
    const beforeDiscount = subtotal + vat_total;
    const discount = beforeDiscount * ((discountPercent || 0) / 100);
    const total = beforeDiscount - discount;
    return { subtotal, vat_total, discount, total };
  }, [items, discountPercent]);

  const gbp = (n) => new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

  const validateForm = () => {
    const errors = [];
    if (!selectedCustomerId) errors.push("Customer is required.");
    if (!items.length) errors.push("Add at least one line item.");
    return errors;
  };

  const handleSave = async () => {
    setErrorMsg("");
    const errors = validateForm();
    if (errors.length > 0) {
      setErrorMsg(errors.join("\n"));
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    setSaving(true);
    try {
      const payload = {
        company_id: me.company_id,
        customer_id: selectedCustomerId,
        quote_number: quoteNumber.trim() || generateQuoteNumber,
        issue_date: issueDate,
        expiry_date: expiryDate,
        items_json: safeJsonStringify(items),
        discount_percent: Number(discountPercent),
        subtotal: Number(totals.subtotal.toFixed(2)),
        vat_total: Number(totals.vat_total.toFixed(2)),
        total: Number(totals.total.toFixed(2)),
        notes,
        terms,
        logo_url: logoOverride || company?.logo_url || "",
      };

      if (isEditing) {
        payload.status = quote?.status || "draft";
        await Quote.update(quoteId, payload);
        navigate(createPageUrl(`QuoteDetail?id=${quoteId}`));
      } else {
        payload.status = "draft";
        const created = await Quote.create(payload);
        navigate(createPageUrl(`QuoteDetail?id=${created.id}`));
      }
    } catch (e) {
      console.error(e);
      setErrorMsg("Failed to save quote. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="p-12 flex items-center justify-center text-gray-700">
        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
        Loading…
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => navigate(-1)} aria-label="Go back">
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">
              {isEditing ? `Edit Quote ${quoteNumber}` : "New Quote"}
            </h1>
            <p className="text-gray-600 mt-1">
              {isEditing ? "Update the details for this quote." : "Create a branded quote for your customer."}
            </p>
          </div>
        </div>

        {errorMsg && (
          <Card className="border-red-200">
            <CardContent className="text-red-700 py-4 whitespace-pre-line">{errorMsg}</CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Quote Details</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2 space-y-4">
                <div>
                  <Label htmlFor="customer-select">Customer</Label>
                  <Select value={selectedCustomerId} onValueChange={setSelectedCustomerId}>
                    <SelectTrigger id="customer-select"><SelectValue placeholder="Select a customer" /></SelectTrigger>
                    <SelectContent>
                      {customers.map(c => (
                        <SelectItem key={c.id} value={c.id}>
                          {c.full_name} {c.postcode ? `· ${c.postcode}` : ""}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="quote-number">Quote Number</Label>
                  <Input 
                    id="quote-number"
                    value={quoteNumber} 
                    onChange={(e) => setQuoteNumber(e.target.value)}
                    placeholder="Quote number"
                  />
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <Label htmlFor="issue-date">Issue Date</Label>
                  <Input 
                    id="issue-date"
                    type="date" 
                    value={issueDate} 
                    onChange={e => setIssueDate(e.target.value)} 
                  />
                </div>
                <div>
                  <Label htmlFor="expiry-date">Expiry Date</Label>
                  <Input 
                    id="expiry-date"
                    type="date" 
                    value={expiryDate} 
                    onChange={e => setExpiryDate(e.target.value)} 
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Line items</CardTitle>
          </CardHeader>
          <CardContent>
            <QuoteItemsEditor items={items} onChange={setItems} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label>Discount percent</Label>
                <Input
                  type="number"
                  inputMode="decimal"
                  value={discountPercent}
                  onChange={e => setDiscountPercent(Number(e.target.value))}
                />
              </div>
              <div className="md:col-span-2 space-y-2 text-right">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>{gbp(totals.subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span>VAT:</span>
                  <span>{gbp(totals.vat_total)}</span>
                </div>
                {discountPercent > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Discount ({discountPercent}%):</span>
                    <span>-{gbp(totals.discount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-lg font-semibold border-t pt-2">
                  <span>Total:</span>
                  <span>{gbp(totals.total)}</span>
                </div>
              </div>
            </div>

            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea id="notes" rows={3} value={notes} onChange={e => setNotes(e.target.value)} placeholder="Additional notes for customer" />
            </div>
            <div>
              <Label htmlFor="terms">Terms</Label>
              <Textarea id="terms" rows={4} value={terms} onChange={e => setTerms(e.target.value)} />
            </div>
          </CardContent>
          <CardFooter className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => navigate(-1)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving} className="bg-blue-600 hover:bg-blue-700">
              {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving</> : (isEditing ? "Update Quote" : "Save Quote")}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}