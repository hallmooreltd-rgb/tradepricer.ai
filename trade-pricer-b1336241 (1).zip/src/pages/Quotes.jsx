
import React, { useState, useEffect, useCallback } from "react";
import { Quote, Customer, User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Plus, Search, FileText, User as UserIcon, Calendar, Trash2, Sparkles } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import { batchLoadEntities } from "../components/utils/ApiUtils";
import DeleteConfirmationModal from "../components/shared/DeleteConfirmationModal";

const statusColors = {
  draft: "bg-gray-100 text-gray-700 border-gray-200",
  sent: "bg-blue-100 text-blue-700 border-blue-200",
  accepted: "bg-green-100 text-green-700 border-green-200",
  declined: "bg-red-100 text-red-700 border-red-200",
  expired: "bg-yellow-100 text-yellow-700 border-yellow-200"
};

const gbp = (n) =>
  new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

export default function Quotes() {
  const [quotes, setQuotes] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [filteredQuotes, setFilteredQuotes] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [deleteQuoteId, setDeleteQuoteId] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const getCustomerName = useCallback((customerId) => {
    const customer = customers.find(c => c.id === customerId);
    return customer?.full_name || "Unknown Customer";
  }, [customers]);

  const filterQuotes = useCallback(() => {
    let filtered = quotes;
    
    if (searchTerm) {
      filtered = filtered.filter(quote => 
        quote.quote_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
        getCustomerName(quote.customer_id).toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter(q => q.status === statusFilter);
    }
    
    setFilteredQuotes(filtered);
  }, [quotes, customers, searchTerm, statusFilter, getCustomerName]);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    filterQuotes();
  }, [filterQuotes]);

  const loadData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      if (userData.company_id) {
        const results = await batchLoadEntities([
          { fn: () => Quote.filter({ company_id: userData.company_id }, "-created_date", 100), name: "quotes" },
          { fn: () => Customer.filter({ company_id: userData.company_id }), name: "customers" }
        ]);

        const quoteData = results.find(r => r.name === 'quotes' && r.success)?.data || [];
        const customerData = results.find(r => r.name === 'customers' && r.success)?.data || [];

        setQuotes(quoteData);
        setCustomers(customerData);
      }
    } catch (error) {
      console.error("Error loading quotes:", error);
    }
    setLoading(false);
  };

  const handleDeleteQuote = async (quoteId) => {
    setDeleting(true);
    try {
      await Quote.delete(quoteId);
      setQuotes(prevQuotes => prevQuotes.filter(q => q.id !== quoteId));
      setDeleteQuoteId(null);
    } catch (error) {
      console.error("Error deleting quote:", error);
      alert("Failed to delete quote. Please try again.");
    } finally {
      setDeleting(false);
    }
  };

  const getQuoteForDeletion = (quoteId) => {
    const quote = quotes.find(q => q.id === quoteId);
    const customer = customers.find(c => c.id === quote?.customer_id);
    return {
      title: `Quote #${quote?.quote_number || "N/A"}`,
      subtitle: `Customer: ${customer?.full_name || "Unknown"}`,
      warning: "This quote will be permanently deleted. This action cannot be undone."
    };
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-48"></div>
            <div className="grid gap-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-24 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Quotes</h1>
            <p className="text-gray-600 mt-1">
              Create and manage all your quotes
            </p>
          </div>
          <Link to={createPageUrl("AiQuoteEditor")}>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              New Quote
            </Button>
          </Link>
        </div>

        <Card className="p-6">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  placeholder="Search quotes or customers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-32">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="sent">Sent</SelectItem>
                  <SelectItem value="accepted">Accepted</SelectItem>
                  <SelectItem value="declined">Declined</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </Card>

        <div className="space-y-4">
          {quotes.length === 0 && !loading ? (
             <Card className="p-8 text-center">
              <div className="space-y-4 max-w-2xl mx-auto">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                  <Sparkles className="w-8 h-8 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">About AI Quotes</h3>
                  <p className="text-gray-600 mb-4 leading-relaxed">
                    Create professional, accurate quotes in minutes using our AI-powered editor. A great quote is the first step to winning a new job.
                  </p>
                  <div className="bg-blue-50 p-4 rounded-lg mb-4">
                    <p className="text-sm text-blue-800 leading-relaxed">
                      <strong>Example:</strong> Type "Supply and fit a new standard combi boiler with a vertical flue and wireless thermostat." Our AI will instantly break this down into a full schedule of rates, including materials and labour, giving you a profitable price.
                    </p>
                  </div>
                  <Link to={createPageUrl("AiQuoteEditor")}>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Create Your First Quote
                    </Button>
                  </Link>
                </div>
              </div>
            </Card>
          ) : filteredQuotes.length === 0 ? (
            <Card className="p-12 text-center text-gray-500">
              No quotes match your filters.
            </Card>
          ) : (
            filteredQuotes.map((quote) => (
              <Card key={quote.id} className="hover:shadow-md transition-shadow duration-200">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0 space-y-3">
                      <div className="flex items-center gap-3 flex-wrap">
                        <h3 className="font-semibold text-lg text-gray-900">
                          Quote #{quote.quote_number}
                        </h3>
                        <Badge className={`${statusColors[quote.status]} border`}>
                          {quote.status}
                        </Badge>
                      </div>
                      
                      <div className="flex flex-wrap items-center gap-6 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <UserIcon className="w-4 h-4" />
                          <span>{getCustomerName(quote.customer_id)}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          <span>Issued {format(new Date(quote.issue_date), "MMM d, yyyy")}</span>
                        </div>
                      </div>
                      
                      <div className="text-gray-800 font-medium">
                        Total: {gbp(quote.total)}
                      </div>
                    </div>
                    
                    <div className="ml-4 flex-shrink-0 flex gap-2">
                      <Link to={createPageUrl(`QuoteDetail?id=${quote.id}`)}>
                        <Button variant="outline" size="sm">
                          View Details
                        </Button>
                      </Link>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setDeleteQuoteId(quote.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {deleteQuoteId && (
          <DeleteConfirmationModal
            isOpen={!!deleteQuoteId}
            onClose={() => setDeleteQuoteId(null)}
            onConfirm={() => handleDeleteQuote(deleteQuoteId)}
            title="Delete Quote"
            itemDetails={getQuoteForDeletion(deleteQuoteId)}
            isDeleting={deleting}
          />
        )}
      </div>
    </div>
  );
}
