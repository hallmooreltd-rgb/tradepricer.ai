
import React, { useState, useEffect } from "react";
import { Reminder, Customer, User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Bell, User as UserIcon, Calendar, Mail, MessageSquare, Phone } from "lucide-react";
import { format, isToday, isTomorrow, isPast } from "date-fns";

const reminderTypeLabels = {
  boiler_service_due: "Boiler Service Due",
  damp_followup: "Damp Follow-up",
  roof_followup: "Roof Follow-up",
  generic: "Generic Reminder"
};

const statusColors = {
  scheduled: "bg-blue-100 text-blue-700 border-blue-200",
  sent: "bg-green-100 text-green-700 border-green-200", 
  failed: "bg-red-100 text-red-700 border-red-200",
  cancelled: "bg-gray-100 text-gray-700 border-gray-200"
};

const channelIcons = {
  email: Mail,
  sms: MessageSquare,
  email_and_sms: Phone
};

export default function Reminders() {
  const [reminders, setReminders] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      if (userData.company_id) {
        const [reminderData, customerData] = await Promise.all([
          Reminder.filter({ company_id: userData.company_id }, "-created_date"),
          Customer.filter({ company_id: userData.company_id })
        ]);
        
        setReminders(reminderData);
        setCustomers(customerData);
      }
    } catch (error) {
      console.error("Error loading reminders:", error);
    }
    setLoading(false);
  };

  const getCustomerName = (customerId) => {
    const customer = customers.find(c => c.id === customerId);
    return customer?.full_name || "Unknown Customer";
  };

  const getDueDateStatus = (dateString) => {
    const date = new Date(dateString);
    if (isPast(date) && !isToday(date)) return "overdue";
    if (isToday(date)) return "today";
    if (isTomorrow(date)) return "tomorrow";
    return "upcoming";
  };

  const getDueDateColor = (status) => {
    switch (status) {
      case "overdue": return "bg-red-100 text-red-700 border-red-200";
      case "today": return "bg-amber-100 text-amber-700 border-amber-200"; 
      case "tomorrow": return "bg-blue-100 text-blue-700 border-blue-200";
      default: return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  const formatDueDate = (dateString) => {
    const date = new Date(dateString);
    if (isToday(date)) return "Today";
    if (isTomorrow(date)) return "Tomorrow";
    return format(date, "MMM d, yyyy");
  };

  const groupedReminders = {
    overdue: reminders.filter(r => getDueDateStatus(r.due_date) === "overdue" && r.status === "scheduled"),
    today: reminders.filter(r => getDueDateStatus(r.due_date) === "today" && r.status === "scheduled"),
    upcoming: reminders.filter(r => ["tomorrow", "upcoming"].includes(getDueDateStatus(r.due_date)) && r.status === "scheduled"),
    sent: reminders.filter(r => r.status === "sent")
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-48"></div>
            <div className="grid gap-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-24 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  const ReminderGroup = ({ title, reminders: groupReminders, priority = false }) => {
    if (groupReminders.length === 0) return null;

    return (
      <Card className={priority ? "border-2 border-amber-200 shadow-md" : "shadow-sm"}>
        <CardHeader className="pb-3">
          <CardTitle className={`text-lg flex items-center gap-2 ${priority ? "text-amber-700" : "text-gray-900"}`}>
            <Bell className="w-5 h-5" />
            {title} ({groupReminders.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-gray-100">
            {groupReminders.map((reminder) => {
              const ChannelIcon = channelIcons[reminder.channel];
              const dueDateStatus = getDueDateStatus(reminder.due_date);
              
              return (
                <div key={reminder.id} className="p-6 hover:bg-gray-50 transition-colors duration-150">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0 space-y-3">
                      <div className="flex items-center gap-3 flex-wrap">
                        <h3 className="font-semibold text-gray-900">
                          {reminderTypeLabels[reminder.reminder_type]}
                        </h3>
                        <Badge className={statusColors[reminder.status]}>
                          {reminder.status}
                        </Badge>
                        {reminder.status === "scheduled" && (
                          <Badge className={`${getDueDateColor(dueDateStatus)} border`}>
                            {formatDueDate(reminder.due_date)}
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex flex-wrap items-center gap-6 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <UserIcon className="w-4 h-4" />
                          <span>{getCustomerName(reminder.customer_id)}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <ChannelIcon className="w-4 h-4" />
                          <span>via {reminder.channel.replace('_', ' & ')}</span>
                        </div>
                        {reminder.last_sent_at && (
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4" />
                            <span>Last sent {format(new Date(reminder.last_sent_at), "MMM d, yyyy")}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    {reminder.status === "scheduled" && (
                      <div className="ml-4 flex-shrink-0">
                        <Button variant="outline" size="sm" disabled>
                          Send Now
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Reminders</h1>
            <p className="text-gray-600 mt-1">
              Manage automated follow-ups and customer communications
            </p>
          </div>
        </div>

        <div className="space-y-6">
          {reminders.length === 0 ? (
            <Card className="p-8 text-center">
              <div className="space-y-4 max-w-2xl mx-auto">
                <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto">
                  <Bell className="w-8 h-8 text-amber-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">About Automated Reminders</h3>
                  <p className="text-gray-600 mb-4 leading-relaxed">
                    Here is where you can view and manage automated follow-up reminders for your customers. 
                    Reminders help maintain compliance schedules and generate repeat business.
                  </p>
                  <div className="bg-amber-50 p-4 rounded-lg mb-4">
                    <p className="text-sm text-amber-800 leading-relaxed">
                      <strong>Example scenario:</strong> After completing a boiler service, the system automatically 
                      creates a reminder to contact the customer in 12 months for their next annual service. 
                      This keeps you compliant with manufacturer warranties and ensures regular income from repeat customers.
                    </p>
                  </div>
                  <p className="text-gray-500">
                    Reminders will be automatically created when you issue certificates with follow-up requirements.
                  </p>
                </div>
              </div>
            </Card>
          ) : (
            <>
              <ReminderGroup
                title="Overdue Reminders"
                reminders={groupedReminders.overdue}
                priority={true}
              />
              <ReminderGroup
                title="Due Today"
                reminders={groupedReminders.today}
                priority={true}
              />
              <ReminderGroup
                title="Upcoming Reminders"
                reminders={groupedReminders.upcoming}
              />
              <ReminderGroup
                title="Sent Reminders"
                reminders={groupedReminders.sent}
              />
            </>
          )}
        </div>
      </div>
    </div>
  );
}
