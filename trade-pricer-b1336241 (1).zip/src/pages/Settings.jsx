
import React, { useState, useEffect } from "react";
import { User, Company, Invitation } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { User as UserIcon } from "lucide-react";
import CompanyProfile from "../components/settings/CompanyProfile";
import TeamManagement from "../components/settings/TeamManagement";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils"; // Import the correct utility

export default function Settings() {
  const [user, setUser] = useState(null);
  const [company, setCompany] = useState(null);
  const [team, setTeam] = useState([]);
  const [invitations, setInvitations] = useState([]);
  const [loading, setLoading] = useState(true);

  const navigate = useNavigate();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);

      if (userData.company_id) {
        const [companies, teamData, invitationData] = await Promise.all([
          Company.filter({ id: userData.company_id }),
          User.filter({ company_id: userData.company_id }),
          Invitation.filter({ company_id: userData.company_id })
        ]);

        if (companies.length > 0) {
          const companyInfo = companies[0];
          setCompany(companyInfo);
        }
        setTeam(teamData || []);
        setInvitations(invitationData || []);
      }
    } catch (error) {
      console.error("Error loading settings:", error);
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-48"></div>
            <div className="h-64 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  // The incorrect local createPageUrl function has been removed.

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Settings</h1>
          <p className="text-gray-600 mt-1">
            Manage your company profile and account settings
          </p>
        </div>

        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserIcon className="w-5 h-5" />
                Account Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Full Name</Label>
                  <Input value={user?.full_name || ""} disabled />
                </div>
                <div>
                  <Label>Email Address</Label>
                  <Input value={user?.email || ""} disabled />
                </div>
              </div>
              <p className="text-sm text-gray-500">
                Account information is managed through your authentication provider.
              </p>
            </CardContent>
          </Card>

          {company && <CompanyProfile company={company} setCompany={setCompany} />}
          
          {/* Staff Management Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserIcon className="w-5 h-5" />
                Staff Management
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Manage your team members and their daily wage rates. These rates will be used by the AI when generating quotes to ensure accurate labour costing.
              </p>
              <Button onClick={() => navigate(createPageUrl("StaffSettings"))} variant="outline">
                <UserIcon className="w-4 h-4 mr-2" />
                Manage Staff & Rates
              </Button>
            </CardContent>
          </Card>

          {company && <TeamManagement company={company} team={team} invitations={invitations} setInvitations={setInvitations} />}

        </div>
      </div>
    </div>
  );
}
