import React, { useEffect, useMemo, useState } from "react";
import { Staff } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, CheckCircle2, Users, ArrowLeft, Loader2 } from "lucide-react";
import { createPageUrl } from "@/utils";
import { useNavigate } from "react-router-dom";

export default function StaffSettings() {
  const navigate = useNavigate();
  const [me, setMe] = useState(null);
  const [rows, setRows] = useState([]);
  const [q, setQ] = useState("");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const u = await User.me();
        setMe(u);
        const list = await Staff.filter({ company_id: u.company_id, active: { $ne: false } }, "name", 500);
        setRows(list);
      } catch (error) {
        console.error("Error loading staff:", error);
      }
      setLoading(false);
    };
    load();
  }, []);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return rows;
    return rows.filter(r =>
      [r.name, r.role].filter(Boolean).join(" ").toLowerCase().includes(needle)
    );
  }, [rows, q]);

  const startCreate = () => { setEditing(null); setDrawerOpen(true); };
  const startEdit = (rec) => { setEditing(rec); setDrawerOpen(true); };
  const onSaved = (rec, isNew) => {
    setDrawerOpen(false);
    setEditing(null);
    setRows(prev => {
      if (isNew) return [rec, ...prev].sort((a,b)=>a.name.localeCompare(b.name));
      return prev.map(r => (r.id === rec.id ? rec : r)).sort((a,b)=>a.name.localeCompare(b.name));
    });
  };

  if (loading) {
    return (
      <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-2 text-gray-700">
            <Loader2 className="w-5 h-5 animate-spin" />
            Loading staff...
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl("Settings"))}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex-1">
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 flex items-center gap-2">
              <Users className="w-8 h-8" />
              Staff Register
            </h1>
            <p className="text-gray-600 mt-1">Add your team and daily rates so AI quotes use your real costs.</p>
          </div>
          <Button className="bg-blue-600 hover:bg-blue-700" onClick={startCreate}>
            <Plus className="w-4 h-4 mr-2" /> Add staff
          </Button>
        </div>

        <Card className="shadow-sm">
          <CardContent className="p-6">
            <div className="flex gap-3 mb-6">
              <Input placeholder="Search name or role..." value={q} onChange={e=>setQ(e.target.value)} />
            </div>

            {filtered.length === 0 ? (
              <div className="p-8 text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">No staff members yet</h3>
                <p className="text-gray-600 mb-4">
                  Add your team members with their daily wages so the AI can price jobs using your actual labor costs.
                </p>
                <Button onClick={startCreate} className="bg-blue-600 hover:bg-blue-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Add your first staff member
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {filtered.map((r) => (
                  <div key={r.id} className="flex items-center justify-between border rounded-lg p-4 bg-white hover:bg-gray-50 transition">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold">
                        {r.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">{r.name}</div>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          {r.role && <Badge variant="secondary">{r.role}</Badge>}
                          <span>Daily wage: <span className="font-semibold">£{Number(r.daily_rate_gbp || 0).toFixed(2)}</span> ex VAT</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {r.active !== false && (
                        <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200">
                          <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Active
                        </Badge>
                      )}
                      <Button variant="outline" size="sm" onClick={() => startEdit(r)}>
                        <Pencil className="w-4 h-4 mr-1" /> Edit
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {drawerOpen && (
          <StaffDrawer
            open={drawerOpen}
            onClose={() => setDrawerOpen(false)}
            companyId={me?.company_id}
            record={editing}
            onSaved={onSaved}
          />
        )}
      </div>
    </div>
  );
}

/* ---------- Drawer ---------- */
function StaffDrawer({ open, onClose, companyId, record, onSaved }) {
  const [name, setName] = useState(record?.name || "");
  const [role, setRole] = useState(record?.role || "");
  const [rate, setRate] = useState(record?.daily_rate_gbp?.toString() || "");
  const [active, setActive] = useState(record?.active !== false);
  const [saving, setSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const save = async () => {
    setErrorMsg("");
    if (!name.trim()) {
      setErrorMsg("Name is required");
      return;
    }
    if (!rate || Number(rate) <= 0) {
      setErrorMsg("Daily rate must be greater than 0");
      return;
    }

    const payload = {
      company_id: companyId,
      name: name.trim(),
      role: role.trim() || undefined,
      daily_rate_gbp: Number(rate),
      active,
    };
    
    setSaving(true);
    try {
      let rec;
      if (record?.id) {
        rec = await Staff.update(record.id, payload);
        onSaved(rec, false);
      } else {
        rec = await Staff.create(payload);
        onSaved(rec, true);
      }
    } catch (e) {
      console.error(e);
      setErrorMsg("Could not save staff member. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md" onClick={e=>e.stopPropagation()}>
        <div className="p-6 border-b">
          <h2 className="text-xl font-semibold">{record ? "Edit staff member" : "Add staff member"}</h2>
          <p className="text-sm text-gray-500 mt-1">Daily wages drive the AI Job Pricer accuracy.</p>
        </div>
        
        <div className="p-6 space-y-4">
          {errorMsg && (
            <div className="text-red-600 text-sm bg-red-50 p-3 rounded border border-red-200">
              {errorMsg}
            </div>
          )}
          
          <div>
            <Label htmlFor="staff-name">Full Name *</Label>
            <Input 
              id="staff-name"
              value={name} 
              onChange={e=>setName(e.target.value)} 
              placeholder="e.g. Alex Smith" 
            />
          </div>
          
          <div>
            <Label htmlFor="staff-role">Role/Trade</Label>
            <Input 
              id="staff-role"
              value={role} 
              onChange={e=>setRole(e.target.value)} 
              placeholder="e.g. Electrician, Plumber, Labourer" 
            />
          </div>
          
          <div>
            <Label htmlFor="staff-rate">Daily wage (ex VAT) *</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">£</span>
              <Input 
                id="staff-rate"
                type="number" 
                min="0" 
                step="1" 
                value={rate} 
                onChange={e=>setRate(e.target.value)} 
                placeholder="180"
                className="pl-8"
              />
            </div>
            <p className="text-xs text-gray-500 mt-1">Most trades £120-£280/day</p>
          </div>
          
          <div className="flex items-center gap-2">
            <input 
              id="staff-active" 
              type="checkbox" 
              checked={active} 
              onChange={e=>setActive(e.target.checked)}
              className="rounded border-gray-300"
            />
            <Label htmlFor="staff-active">Active (available for work)</Label>
          </div>
        </div>
        
        <div className="p-6 border-t flex justify-end gap-3">
          <Button variant="outline" onClick={onClose} disabled={saving}>
            Cancel
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-700" onClick={save} disabled={saving}>
            {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Saving...</> : "Save staff member"}
          </Button>
        </div>
      </div>
    </div>
  );
}