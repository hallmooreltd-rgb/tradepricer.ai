import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { User, Company, Customer, Job, Variation } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Loader2, ArrowLeft, Download, AlertCircle, CheckCircle } from "lucide-react";
import { createPageUrl } from "@/utils";
import SendVariationModal from "../components/variations/SendVariationModal";
import { buildVariationPdf } from "../components/variations/buildVariationPdf";
import { format } from 'date-fns';

const statusColors = {
  draft: "bg-gray-100 text-gray-700",
  sent: "bg-blue-100 text-blue-700",
  approved: "bg-green-100 text-green-700",
  rejected: "bg-red-100 text-red-700",
};

export default function VariationDetail() {
  const navigate = useNavigate();
  const variationId = new URLSearchParams(useLocation().search).get("id");

  const [variation, setVariation] = useState(null);
  const [job, setJob] = useState(null);
  const [customer, setCustomer] = useState(null);
  const [company, setCompany] = useState(null);
  const [loading, setLoading] = useState(true);

  const gbp = (n) => new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

  const loadData = async () => {
    try {
      const v = (await Variation.filter({ id: variationId }))[0];
      setVariation(v);
      const [j, c, co] = await Promise.all([
        Job.get(v.job_id),
        Customer.get(v.customer_id),
        Company.get(v.company_id),
      ]);
      setJob(j); setCustomer(c); setCompany(co);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [variationId]);
  
  const downloadPdf = async () => {
    const blob = await buildVariationPdf({ company, customer, job, variation });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${variation.variation_number}.pdf`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) return <div className="p-8"><Loader2 className="animate-spin" /></div>;
  if (!variation) return <div className="p-8">Variation not found.</div>;

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex justify-between items-start">
          <div>
            <Button variant="outline" size="sm" onClick={() => navigate(createPageUrl(`Job?id=${variation.job_id}`))} className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" /> Back to Job
            </Button>
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Variation #{variation.variation_number}</h1>
            <p className="text-gray-600 mt-1">Job: {job?.title}</p>
          </div>
          <Badge className={`${statusColors[variation.status]}`}>{variation.status}</Badge>
        </div>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Summary</CardTitle>
            <div className="flex gap-2">
                <Button variant="outline" onClick={downloadPdf}><Download className="w-4 h-4 mr-2" /> Download PDF</Button>
                {variation.status === "draft" && <SendVariationModal {...{ variation, company, customer, job }} onSent={loadData} />}
                {variation.status === "sent" && <SendVariationModal {...{ variation, company, customer, job }} onSent={loadData} isReminder={true} />}
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 text-sm">
                <div><span className="font-medium text-gray-600">Customer:</span> {customer?.full_name}</div>
                <div><span className="font-medium text-gray-600">Issue Date:</span> {variation.issue_date}</div>
                <div className="col-span-2"><span className="font-medium text-gray-600">Total:</span> <span className="font-semibold text-lg">{gbp(variation.total)}</span></div>
            </div>
            {variation.notes && <p className="mt-4 text-sm text-gray-600 whitespace-pre-wrap">{variation.notes}</p>}
          </CardContent>
        </Card>

        {variation.status === "approved" && (
            <Card className="border-green-300 bg-green-50">
                <CardHeader><CardTitle className="text-green-800 flex items-center gap-2"><CheckCircle/> Approved</CardTitle></CardHeader>
                <CardContent className="flex gap-8">
                    <div>
                        <div className="text-sm text-green-700">Approved by: {variation.approved_by_name}</div>
                        <div className="text-sm text-green-700">Date: {format(new Date(variation.approved_at), 'd MMM yyyy, h:mm a')}</div>
                    </div>
                    {variation.approved_by_signature_url && <img src={variation.approved_by_signature_url} alt="Signature" className="h-16 w-auto border rounded bg-white" />}
                </CardContent>
            </Card>
        )}
        {variation.status === "rejected" && (
            <Card className="border-red-300 bg-red-50">
                <CardHeader><CardTitle className="text-red-800 flex items-center gap-2"><AlertCircle/> Rejected</CardTitle></CardHeader>
                <CardContent>
                    <div className="text-sm text-red-700">Reason: {variation.rejection_reason || "No reason provided."}</div>
                </CardContent>
            </Card>
        )}

        <Card>
            <CardHeader><CardTitle>Line Items</CardTitle></CardHeader>
            <CardContent>
                <div className="border rounded-xl overflow-hidden">
                    <Table>
                        <TableHeader className="bg-gray-50">
                            <TableRow>
                                <TableHead>Description</TableHead><TableHead>Qty</TableHead><TableHead>Unit ex. VAT</TableHead><TableHead>VAT</TableHead><TableHead className="text-right">Line Total</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {(JSON.parse(variation.items_json || '[]')).map((it, i) => {
                                const ex = (it.quantity || 0) * (it.unit_price || 0);
                                const inc = ex * (1 + (it.vat_rate || 0) / 100);
                                return (<TableRow key={i}><TableCell>{it.description}</TableCell><TableCell>{it.quantity}</TableCell><TableCell>{gbp(it.unit_price)}</TableCell><TableCell>{it.vat_rate}%</TableCell><TableCell className="text-right">{gbp(inc)}</TableCell></TableRow>);
                            })}
                        </TableBody>
                    </Table>
                </div>
            </CardContent>
        </Card>
      </div>
    </div>
  );
}