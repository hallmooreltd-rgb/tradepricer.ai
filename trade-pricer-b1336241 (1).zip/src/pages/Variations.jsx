
import React, { useState, useEffect, useMemo } from "react";
import { Variation, Customer, Job, User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Plus, Search, FileText, Loader2, Layers } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { format } from "date-fns";

const statusColors = {
  draft: "bg-gray-100 text-gray-700",
  sent: "bg-blue-100 text-blue-700",
  approved: "bg-green-100 text-green-700",
  rejected: "bg-red-100 text-red-700",
};

export default function Variations() {
  const navigate = useNavigate();
  const [variations, setVariations] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const userData = await User.me();
        if (userData.company_id) {
          const [vars, custs, jbs] = await Promise.all([
            Variation.filter({ company_id: userData.company_id }, "-created_date"),
            Customer.filter({ company_id: userData.company_id }),
            Job.filter({ company_id: userData.company_id }),
          ]);
          setVariations(vars);
          setCustomers(custs);
          setJobs(jbs);
        }
      } catch (error) {
        console.error("Error loading data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const dataMap = useMemo(() => {
      const jm = new Map(jobs.map(j => [j.id, j]));
      const cm = new Map(customers.map(c => [c.id, c]));
      return { jobs: jm, customers: cm };
  }, [jobs, customers]);

  const filteredVariations = useMemo(() => {
    return variations.filter(v => {
        if (!searchTerm) return true;
        const term = searchTerm.toLowerCase();
        const job = dataMap.jobs.get(v.job_id);
        const customer = dataMap.customers.get(v.customer_id);
        return (
            v.variation_number.toLowerCase().includes(term) ||
            job?.title.toLowerCase().includes(term) ||
            customer?.full_name.toLowerCase().includes(term)
        );
    });
  }, [variations, searchTerm, dataMap]);

  const gbp = (n) => new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(n || 0);

  return (
    <div className="p-4 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Variations</h1>
          <Button onClick={() => navigate(createPageUrl("NewVariation"))}>
            <Plus className="w-4 h-4 mr-2" /> New Variation
          </Button>
        </div>
        <Card>
          <CardContent className="p-4">
            <Input placeholder="Search variations..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
          </CardContent>
        </Card>
        <div className="space-y-4">
          {loading ? (
            <div className="flex justify-center p-8"><Loader2 className="animate-spin" /></div>
          ) : variations.length === 0 ? (
            <Card className="p-8 text-center">
              <div className="space-y-4 max-w-2xl mx-auto">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                  <Layers className="w-8 h-8 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">About Variations</h3>
                  <p className="text-gray-600 mb-4 leading-relaxed">
                    Here is where you can add any variations throughout the job once the quote has been accepted. 
                    Variations are changes or additions to the original scope of work that require customer approval.
                  </p>
                  <div className="bg-blue-50 p-4 rounded-lg mb-4">
                    <p className="text-sm text-blue-800 leading-relaxed">
                      <strong>Example scenario:</strong> You're installing a new boiler and discover the existing pipework 
                      needs replacing due to corrosion. This wasn't visible during the original quote, so you create a 
                      variation for "Replace corroded pipework - 5 meters" for £350. The customer can review and 
                      approve this additional work through their customer portal.
                    </p>
                  </div>
                  <Button onClick={() => navigate(createPageUrl("NewVariation"))}>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Your First Variation
                  </Button>
                </div>
              </div>
            </Card>
          ) : filteredVariations.length === 0 ? (
            <Card className="p-12 text-center text-gray-500">
              No variations match your search criteria.
            </Card>
          ) : (
              filteredVariations.map(v => {
                  const job = dataMap.jobs.get(v.job_id);
                  const customer = dataMap.customers.get(v.customer_id);
                  return (
                      <Card key={v.id} className="hover:shadow-md">
                          <CardContent className="p-4 flex justify-between items-center">
                              <div>
                                  <Link to={createPageUrl(`VariationDetail?id=${v.id}`)} className="font-bold text-blue-600">{v.variation_number}</Link>
                                  <p className="text-sm text-gray-600">{job?.title}</p>
                                  <p className="text-sm text-gray-500">{customer?.full_name}</p>
                              </div>
                              <div className="text-right">
                                  <div className="font-semibold">{gbp(v.total)}</div>
                                  <Badge className={statusColors[v.status]}>{v.status}</Badge>
                              </div>
                          </CardContent>
                      </Card>
                  )
              })
          )}
        </div>
      </div>
    </div>
  );
}
