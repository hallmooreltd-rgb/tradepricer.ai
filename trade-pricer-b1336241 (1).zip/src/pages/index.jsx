import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Jobs from "./Jobs";

import Customers from "./Customers";

import Certificates from "./Certificates";

import Photos from "./Photos";

import Reminders from "./Reminders";

import Settings from "./Settings";

import NewCertificate from "./NewCertificate";

import DeliverCertificate from "./DeliverCertificate";

import NewJob from "./NewJob";

import Quotes from "./Quotes";

import CustomerPortal from "./CustomerPortal";

import QuoteDetail from "./QuoteDetail";

import Job from "./Job";

import Invoices from "./Invoices";

import NewInvoice from "./NewInvoice";

import InvoiceDetail from "./InvoiceDetail";

import Assistant from "./Assistant";

import NewCustomer from "./NewCustomer";

import QuoteEditor from "./QuoteEditor";

import AiQuoteEditor from "./AiQuoteEditor";

import NewVariation from "./NewVariation";

import VariationDetail from "./VariationDetail";

import PortalVariationView from "./PortalVariationView";

import Variations from "./Variations";

import Billing from "./Billing";

import Customer from "./Customer";

import Home from "./Home";

import NewDiary from "./NewDiary";

import DiaryDetail from "./DiaryDetail";

import Diaries from "./Diaries";

import StaffSettings from "./StaffSettings";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Jobs: Jobs,
    
    Customers: Customers,
    
    Certificates: Certificates,
    
    Photos: Photos,
    
    Reminders: Reminders,
    
    Settings: Settings,
    
    NewCertificate: NewCertificate,
    
    DeliverCertificate: DeliverCertificate,
    
    NewJob: NewJob,
    
    Quotes: Quotes,
    
    CustomerPortal: CustomerPortal,
    
    QuoteDetail: QuoteDetail,
    
    Job: Job,
    
    Invoices: Invoices,
    
    NewInvoice: NewInvoice,
    
    InvoiceDetail: InvoiceDetail,
    
    Assistant: Assistant,
    
    NewCustomer: NewCustomer,
    
    QuoteEditor: QuoteEditor,
    
    AiQuoteEditor: AiQuoteEditor,
    
    NewVariation: NewVariation,
    
    VariationDetail: VariationDetail,
    
    PortalVariationView: PortalVariationView,
    
    Variations: Variations,
    
    Billing: Billing,
    
    Customer: Customer,
    
    Home: Home,
    
    NewDiary: NewDiary,
    
    DiaryDetail: DiaryDetail,
    
    Diaries: Diaries,
    
    StaffSettings: StaffSettings,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Jobs" element={<Jobs />} />
                
                <Route path="/Customers" element={<Customers />} />
                
                <Route path="/Certificates" element={<Certificates />} />
                
                <Route path="/Photos" element={<Photos />} />
                
                <Route path="/Reminders" element={<Reminders />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/NewCertificate" element={<NewCertificate />} />
                
                <Route path="/DeliverCertificate" element={<DeliverCertificate />} />
                
                <Route path="/NewJob" element={<NewJob />} />
                
                <Route path="/Quotes" element={<Quotes />} />
                
                <Route path="/CustomerPortal" element={<CustomerPortal />} />
                
                <Route path="/QuoteDetail" element={<QuoteDetail />} />
                
                <Route path="/Job" element={<Job />} />
                
                <Route path="/Invoices" element={<Invoices />} />
                
                <Route path="/NewInvoice" element={<NewInvoice />} />
                
                <Route path="/InvoiceDetail" element={<InvoiceDetail />} />
                
                <Route path="/Assistant" element={<Assistant />} />
                
                <Route path="/NewCustomer" element={<NewCustomer />} />
                
                <Route path="/QuoteEditor" element={<QuoteEditor />} />
                
                <Route path="/AiQuoteEditor" element={<AiQuoteEditor />} />
                
                <Route path="/NewVariation" element={<NewVariation />} />
                
                <Route path="/VariationDetail" element={<VariationDetail />} />
                
                <Route path="/PortalVariationView" element={<PortalVariationView />} />
                
                <Route path="/Variations" element={<Variations />} />
                
                <Route path="/Billing" element={<Billing />} />
                
                <Route path="/Customer" element={<Customer />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/NewDiary" element={<NewDiary />} />
                
                <Route path="/DiaryDetail" element={<DiaryDetail />} />
                
                <Route path="/Diaries" element={<Diaries />} />
                
                <Route path="/StaffSettings" element={<StaffSettings />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}